import af from './af.json'
import ar from './ar.json'
import cn from './cn.json'
import de from './de.json'
import el from './el.json'
import en from './en.json'
import es from './es.json'
import fr from './fr.json'
import hi from './hi.json'
import id from './id.json'
import it from './it.json'
import ja from './ja.json'
import ko from './ko.json'
import ms from './ms.json'
import ph from './ph.json'
import pt from './pt.json'
import ru from './ru.json'
import th from './th.json'
import tr from './tr.json'
import tw from './tw.json'
import vi from './vi.json'
export default {
	af,
	ar,
	cn,
	de,
	el,
	en,
	es,
	fr,
	hi,
	id,
	it,
	ja,
	ko,
	ms,
	ph,
	pt,
	ru,
	th,
	tr,
	tw,
	vi
}
