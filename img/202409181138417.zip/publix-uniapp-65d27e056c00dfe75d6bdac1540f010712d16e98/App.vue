<script>
	import { mapState, mapActions,mapGetters } from "vuex";
	// import APPUpdate from './common/APPUpdate'
	import { imgUrl,mobileUrl,apiUrl,socketUrl } from '@/config.js';
	import { ACCESS_TOKEN, USER_ID } from '@/store/mutation-types'
	import { checkLogin } from '@/core/app'
	import * as Api from '@/api/common'
	import storage from '@/utils/storage'
	import store from '@/store'
	export default {

    /**
     * 全局变量
     */
    globalData: {
		isPop:false,
		langeuage:'en',
		imgUrl:imgUrl,
		mobileUrl:mobileUrl,
		apiUrl:apiUrl,
		socketUrl:socketUrl,
		name:'Publix',
		versionCode:'1.0.0',
		messageNumber:0,//消息中心未读消息
		chatNumber:0,//在线客服未读消息
		//状态栏参数
		statusBar:0,// 状态栏高度
		customBar:0,  // 状态栏高度 + 导航栏高度  
		navbar:0, // 自定义标题与胶囊对齐高度
		capsuleWidth:0, //微信胶囊
		capsuleHeight:0, //微信胶囊
    },

    /**
     * 初始化完成时触发
     */
    onLaunch(options) {
		if (options.query.token) {
			// this.$store.state.token =options.query.token
			// this.$store.state.userId = 1
			store.dispatch('LoginToken', {
				token:options.query.token,
				usercode: 1
			})
		}
		if (options.query.lang) {
			uni.setLocale(options.query.lang);
		}
		// 获取基础信息
		this.getSystemInfo()
		// 小程序主动更新
		this.updateManager()
		// #ifdef APP-PLUS
		// APPUpdate();
		// #endif
		//uni.getStorageSync('langeuage'):'zh-Tw'
		this.globalData.langeuage = 'en';
		uni.setStorageSync('UNI_LOCALE',this.globalData.langeuage)
		console.log(this.globalData.langeuage)
		
		if(this.globalData.langeuage){
			 uni.setLocale(this.globalData.langeuage);
		}
		var isLogin = checkLogin()
		if(!isLogin){
			this.$navTo('pages/login/index')
			return
		}
		
    },
	
    methods: {
		getSystemInfo(){
			var that = this
			var statusBar = 0  //状态栏高度
			var customBar = 0  // 状态栏高度 + 导航栏高度  
			var navbar = 0 // 自定义标题与胶囊对齐高度
			var custom = null
			uni.getSystemInfo({
			    success: (e) => {
			      // #ifdef MP
			      statusBar = e.statusBarHeight
			      customBar = e.statusBarHeight + 45
			      if (e.platform === 'android') {
			        customBar = e.statusBarHeight + 50
			      }
			      // #endif
			      
			      
			      // #ifdef MP-WEIXIN
			      statusBar = e.statusBarHeight
			      custom = wx.getMenuButtonBoundingClientRect()
			      customBar = custom.bottom + custom.top - e.statusBarHeight
			      navbar = (custom.top - e.statusBarHeight) * 2 + custom.height
			      // #endif
			 
			 
			      // #ifdef MP-ALIPAY
			      statusBar = e.statusBarHeight
			      customBar = e.statusBarHeight + e.titleBarHeight
			      // #endif
			 
			      // #ifdef APP-PLUS
			      statusBar = e.statusBarHeight
			      customBar = e.statusBarHeight + 45
				  navbar = 45
			      // #endif
				  
			    }
			})
			// #ifdef H5
			statusBar = 0
			customBar = 45
			navbar = 45
			// #endif
				
			// #ifdef MP
			if(custom){
				that.globalData.capsuleWidth = custom.width
				that.globalData.capsuleHeight = custom.height
			}
			// #endif
			that.globalData.statusBar = statusBar  //状态栏高度
			that.globalData.customBar = customBar  // 状态栏高度 + 导航栏高度  
			that.globalData.navbar = navbar // 自定义标题与胶囊对齐高度
		},
		/**
		* 小程序主动更新
		*/
		updateManager() {
			const updateManager = uni.getUpdateManager();
			updateManager.onCheckForUpdate(res => {
			  // 请求完新版本信息的回调
			  // console.log(res.hasUpdate)
			})
			updateManager.onUpdateReady(() => {
				uni.showModal({
					title: this.$t('toast.reminder'),
					content: this.$t('toast.rDownloadA'),
					confirmText: this.$t('toast.ok'),
					showCancel: false,
					success(res) {
					  if (res.confirm) {
						// 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
						updateManager.applyUpdate()
					  }
					}
				})
			})
			updateManager.onUpdateFailed(() => {
				// 新的版本下载失败
				uni.showModal({
					title: this.$t('toast.reminder'),
					content: this.$t('toast.rDownloadB'),
					confirmText: this.$t('toast.ok'),
					showCancel: false
				})
			})
		},
		//获取订单数
		getOrderNoPushNum() {
			var that = this;
			return new Promise((resolve, reject) => {
				Api.orderNoPushNum().then(result => {
					if(result.code==0){
						if(result.data.noPushNum){
							uni.setTabBarBadge({
							  index: 2,
							  text: JSON.stringify(result.data.noPushNum)
							})
						}else{
							uni.removeTabBarBadge({
							  index: 2
							})
						}
					}else{
						uni.removeTabBarBadge({
						  index: 2
						})
					}
					
				});
			})
		},
    }

  }
</script>

<style lang="scss">
/* 引入uView库样式 */
@import "uview-ui/index.scss";

@import "uview-ui/index.scss";
@import './common/styles/common.scss';
@import './uni.scss';
@import './common/styles/iconfont.scss';
</style>

<style>
/* 项目基础样式 */
@import "./app.scss";
.uni-app--showlayout+uni-tabbar.uni-tabbar-bottom,
.uni-app--showlayout+uni-tabbar.uni-tabbar-bottom .uni-tabbar,
.uni-app--showlayout+uni-tabbar.uni-tabbar-top,
.uni-app--showlayout+uni-tabbar.uni-tabbar-top .uni-tabbar {
	left: var(--window-left);
	right: var(--window-right);
}
</style>
