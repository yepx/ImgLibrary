<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view>
			<view v-for="(item,index) in list.data" :key="index" class="a-bg-white a-p-2 a-mt-2">
				<view class="a-flex a-align-center a-justify-between">
					<view class="a-flex a-flex-1 a-align-center">
						<view>
							<image class="a-w-90 a-h-90 a-rounded-circle" mode="aspectFill" :src="`/static/images/avatar/${item.avatar}.png`"></image>
						</view>
						<text class="a-font a-text-ellipsis-1 a-ml-2 a-flex-1">{{item.userName}}</text>
					</view>
					<u-rate :count="5" :value="item.rating" size="40" active-color="rgb(255, 201, 62)"></u-rate>
				</view>
				<view class="a-mb-2">
					<text class="a-font a-opacity-8">{{item.content}}</text>
					<view class="a-flex a-flex-wrap a-mt-2">
						<image v-if="item.imgUrl1" @click="previewImage(item.imgUrl1)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl1"></image>
						<image v-if="item.imgUrl2" @click="previewImage(item.imgUrl2)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl2"></image>
						<image v-if="item.imgUrl3" @click="previewImage(item.imgUrl3)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl3"></image>
						<image v-if="item.imgUrl4" @click="previewImage(item.imgUrl4)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl4"></image>
						<image v-if="item.imgUrl5" @click="previewImage(item.imgUrl5)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl5"></image>
						<image v-if="item.imgUrl6" @click="previewImage(item.imgUrl6)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl6"></image>
						<image v-if="item.imgUrl7" @click="previewImage(item.imgUrl7)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl7"></image>
						<image v-if="item.imgUrl8" @click="previewImage(item.imgUrl8)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl8"></image>
						<image v-if="item.imgUrl9" @click="previewImage(item.imgUrl9)" class="a-w-200 a-h-300 a-mr-2 a-mb-2" mode="aspectFill" :src="item.imgUrl9"></image>
					</view>
				</view>
				<view class="a-bg-white a-rounded a-p-2 a-flex" style="box-shadow: 0px 0px 10px 1px rgba(0,0,0,0.1)">
					<view class="a-mr-1">
						<image class="a-w-180 a-h-180 a-rounded" mode="aspectFill" :src="item.goodsVo.imgUrl1"></image>
					</view>
					<view class="a-flex-column a-justify-center">
						<view class="a-flex a-justify-between">
							<text class="a-font a-text-ellipsis-2 a-font-weight-bold">{{item.goodsVo.name}}</text>
						</view>
						<view class="a-flex a-align-center a-justify-between a-mt-1">
							<view class="a-flex a-align-center">
								<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.goodsVo.systemPrice" :currency="true"/>
							</view>
							<text class="a-font-sm a-text-gray">{{getTime(item.goodsVo.upTime)}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
			}
		},
		onShow() {
			this.onRefreshList()
		},
		methods: {
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						pageNum:pageNo,
						pageSize:pageSize
					};
					Api.sellerComment(params).then(result =>{
						const newList = result.data
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			previewImage(image){
				uni.previewImage({
					urls: [image],
					longPressActions: {
						// itemList: ['发送给朋友', '保存图片', '收藏'],
						success: function(data) {
							console.log('选中了第' + (data.tapIndex + 1) + '个按钮,第' + (data.index + 1) + '张图片');
						},
						fail: function(err) {
							console.log(err.errMsg);
						}
					}
				});
			},
			getTime(time){
				let date = new Date(time);
				 //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				let y = date.getFullYear();
				let MM = date.getMonth() + 1;
				MM = MM < 10 ? ('0' + MM) : MM;//月补0
				let d = date.getDate();
				d = d < 10 ? ('0' + d) : d;//天补0
				let h = date.getHours();
				h = h < 10 ? ('0' + h) : h;//小时补0
				let m = date.getMinutes();
				m = m < 10 ? ('0' + m) : m;//分钟补0
				let s = date.getSeconds();
				s = s < 10 ? ('0' + s) : s;//秒补0
				let nowTime = y + '-' + MM + '-' + d + ' ' + h + ':' + m+ ':' + s;
				return nowTime;
			},
		}
	}
</script>

<style>

</style>
