<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="a-mx-3">
			<view v-for="(item,index) in list.data" :key="index" @click="$navTo('pages/product/detail',item)" class="a-bg-white a-rounded a-mt-3 a-p-2 a-flex">
				<view class="a-mr-3">
					<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="item.imgUrl1"></image>
				</view>
				<view class="a-flex-column a-justify-between">
					<text class="a-font a-text-ellipsis-2">{{item.name}}</text>
					<view class='a-flex a-align-center'>
						<text class="a-font-sm a-text-gray">{{$t('浏览')}}:</text>
						<FormatNumberShow class="a-font-sm a-text-gray a-mr-2" :data="item.viewsNum"/>
						<text class="a-font-sm a-text-gray">{{$t('销量')}}:</text>
						<FormatNumberShow class="a-font-sm a-text-gray a-mr-2" :data="item.soldNum"/>
					</view>
					<view class="a-flex a-align-center a-mt">
						<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.sellingPrice" :currency="true"/>
					</view>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 10
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				options:{},
				
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
			}
		},
		onLoad(options) {
			uni.setNavigationBarTitle({
				title:options.name
			})
			delete options.name
			this.options = options
		},
		methods: {
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						pageNum:pageNo,
						pageSize:pageSize,
						...that.options
					};
					Api.sellerGoods(params).then(result =>{
						const newList = result.data
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
		}
	}
</script>

<style>

</style>
