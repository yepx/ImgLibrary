<template>
	<view>
		<view class="a-p-3">
			<view class="a-mb-2">
				<view class="a-mb-2">
					<text class="a-font">{{$t('当前售价')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1"
					 disabled=""
					 type="number" v-model="updateInfo.sellingPrice" @input="changeSellingPrice" :placeholder="$t('当前售价')"/>
					<view class="a-ml-2">
						<text class="a-font-sm a-text-green">{{$t('利润')}} {{updateInfo.discountPrice ? getResult(updateInfo.discountPrice,updateInfo.systemPrice) : updateInfo.profit}}</text>
					</view>
				</view>
			</view>
			<view class="a-flex a-align-center a-justify-between a-mb-2">
							<text class="a-font">{{$t('是否上架')}}</text>
							<switch color="#1552f0" :checked="isShelf" @change="changeIsShelf"></switch>
						</view>
			<view class="a-flex a-align-center a-justify-between a-mb-2">
				<text class="a-font">{{$t('是否推荐')}}</text>
				<switch color="#1552f0" :checked="recTime" @change="changeRecTime"></switch>
			</view>
			<view class="a-flex a-align-center a-justify-between a-mb-2">
				<text class="a-font">{{$t('直通车')}}</text>
				<switch color="#1552f0" :checked="isCombo" @change="changeIsCombo"></switch>
			</view>
			<view class="a-mb-2">
							<view class="a-mb-2 a-flex a-align-center a-justify-between">
								<text class="a-font">{{$t('百分比')}}</text>
								<view v-if="updateInfo.profitRatio>0" class="a-ml-2">
									<text class="a-font-sm a-text-green">{{$t('利润')}} {{updateInfo.discountPrice ? getResult(updateInfo.discountPrice,updateInfo.systemPrice) : updateInfo.profit}}</text>
								</view>
							</view>
							<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
								<input class="a-font a-flex-1" type="number" v-model="updateInfo.profitRatio" @input="changeProfitRatio" :placeholder="$t('百分比')"/>
								<view class="a-ml-2">
									<text class="a-font-sm">%</text>
								</view>
							</view>
							<view>
								<text class="a-font-sm">{{$t('将选中的商品发布到你的店铺，并填写商品利润比例，推荐比例:')}}<span class="a-text-primary">{{ sysParaProductInfo.sysParaMin }}% — {{ sysParaProductInfo.sysParaMax }}%</span></text>
							</view>
						</view>
			
			<view class="a-mb-2">
				<view class="a-mb-2">
					<text class="a-font">{{$t('折扣开始日期')}}</text>
				</view>
				<picker mode="date" :value="updateInfo.discountStartTime" :start="startDate" :end="endDate" @change="changeDate($event,1)">
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<text class="a-font a-flex-1" :class="updateInfo.discountStartTime?'':'a-text-gray'">{{updateInfo.discountStartTime?updateInfo.discountStartTime:$t('折扣开始日期')}}</text>
				</view>
				</picker>
			</view>
			<view class="a-mb-2">
				<view class="a-mb-2">
					<text class="a-font">{{$t('折扣结束日期')}}</text>
				</view>
				<picker mode="date" :value="updateInfo.discountEndTime" :start="startDate" :end="endDate" @change="changeDate($event,2)">
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<text class="a-font a-flex-1" :class="updateInfo.discountEndTime?'':'a-text-gray'">{{updateInfo.discountEndTime?updateInfo.discountEndTime:$t('折扣结束日期')}}</text>
				</view>
				</picker>
			</view>
			<view class="a-mb-2">
				<view class="a-mb-2 a-flex a-align-center a-justify-between">
					<text class="a-font">{{$t('折扣比例')}}</text>
					<view v-if="updateInfo.discountPrice" class="a-ml-2">
						<text class="a-font-sm a-text-green">{{$t('当前折扣价')}} {{updateInfo.discountPrice}}</text>
					</view>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="number" :disabled="!updateInfo.discountStartTime && !updateInfo.discountEndTime" v-model="updateInfo.discountRatio" @input="changeDiscountRatio" :placeholder="$t('折扣比例')"/>
					<view class="a-ml-2">
						<text class="a-font-sm">%</text>
					</view>
				</view>
			</view>
			
			<view @click="onSubmit" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('保存')}}</text>
			</view>
			<view @click="onDelete" class="a-mb-3 a-bg-red a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
							<text class="a-font-lg a-text-white">{{$t('删除')}}</text>
						</view>
		
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				updateInfo:{},
				sysParaProductInfo:{},
				isShelf:false,
				recTime:false,
				isShelf:false,
			}
		},
		onLoad(options){
			for(var i in options){
				if(options[i] == "null"){
					options[i] = null
				}else if(options[i] == "0"){
					options[i] = 0
				}else if(options[i] == "1"){
					options[i] = 1
				}
			}
			options.profitRatio = options.profitRatio * 100
			options.discountRatio = options.discountRatio ? this.$bigDecimal.multiply(options.discountRatio, 100) : ''
			this.updateInfo = options
			this.isShelf = this.updateInfo.isShelf?true:false
			this.recTime = this.updateInfo.recTime?true:false
			this.isCombo = this.updateInfo.isCombo?true:false
			if (this.updateInfo.discountStartTime && this.updateInfo.discountEndTime) {
				this.updateInfo.discountStartTime = this.removeTime(this.updateInfo.discountStartTime)
				this.updateInfo.discountEndTime = this.removeTime(this.updateInfo.discountEndTime)
			} else {
			    this.discountRatio = null
			}
			
			// this.updateInfo.sellingPrice && this.changeSellingPrice({detail:{value:this.updateInfo.sellingPrice}})
			this.getSellerSysParaProduct()
			this.getSellerGoodsEdit()
			this.getProfit()
		},
		computed: {
		  startDate() {
			return this.getDate('start');
		  },
		  endDate() {
			return this.getDate('end');
		  }
		},
		watch: {
		  'updateInfo.sellingPrice'(val){
		    if (val && this.updateInfo.discountRatio) {
		      this.updateInfo.discountPrice = (this.$bigDecimal.multiply(val, (1 - (this.updateInfo.discountRatio || 0) / 100)) * 1).toFixed(2)
				console.log(this.updateInfo.discountPrice)
			} else {
		      this.updateInfo.discountPrice = 0
		    }
		  },
		},
		methods: {
			removeTime(time){
				var newDate =/\d{4}-\d{1,2}-\d{1,2}/g.exec(time)
				return newDate[0]
			},
			getDate(type) {
				const date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth() + 1;
				let day = date.getDate();
				
				if (type === 'start') {
					year = year - 60;
				} else if (type === 'end') {
					year = year + 2;
				}
				month = month > 9 ? month : '0' + month;
				day = day > 9 ? day : '0' + day;
				return `${year}-${month}-${day}`;
			},
			getSellerSysParaProduct() {
				const that = this
				Api.sellerSysParaProduct().then(result =>{
					that.sysParaProductInfo = result.data
				})
			},
			getSellerGoodsEdit() {
				const that = this
				var params = {
					
				}
				return
				Api.sellerGoodsEdit(params).then(result =>{
					that.sysParaProductInfo = result.data
				})
			},
			
			getResult(a,b){
			  var num = a-b
			  return num.toFixed(2)
			},
			changeSellingPrice(e) {
			  var value = this.toDecimal(JSON.stringify(e.detail.value))
			  this.updateInfo.sellingPrice = value
			  // 根据当前售价改变利润比例
			  this.updateInfo.profitRatio = ((this.$bigDecimal.divide(this.$bigDecimal.subtract(value, this.updateInfo.systemPrice), this.updateInfo.systemPrice) * 1) * 100).toFixed(2)
			  // 根据当前售价改变利润
			  this.getProfit()
			},
			changeProfitRatio(e) {
			  var value = this.toDecimal(JSON.stringify(e.detail.value))
			  this.updateInfo.profitRatio = value
			
			  // if (this.type === '编辑产品') {
			  //   // 根据当前利润比例改变售价
			  //   this.updateInfo.sellingPrice = (this.$bigDecimal.multiply(this.updateInfo.systemPrice, (1 + value / 100)) * 1).toFixed(2)
			  // }
			  this.updateInfo.sellingPrice = (this.$bigDecimal.multiply(this.updateInfo.systemPrice, (1 + value / 100)) * 1).toFixed(2)
			  if(this.updateInfo.discountPrice){
			    this.changeDiscountRatio({detail:{value:this.updateInfo.discountRatio}})
			  }
			  this.getProfit()
			},
			changeDiscountRatio(e) {
			  //只能输入整数
			  if(e.detail.value){
				  var value = parseInt(e.detail.value)
			  }else{
				  var value = 0
			  }
			  this.updateInfo.discountRatio = value
			  console.log(this.updateInfo.discountRatio)
			  // if (this.type === '编辑产品') {
			  //   // 根据当前折扣比例改变折扣价
			  //   this.updateInfo.discountPrice = (this.$bigDecimal.multiply(this.updateInfo.sellingPrice, (1 - value / 100)) * 1).toFixed(2)
			  // }
			  this.updateInfo.discountPrice = (this.$bigDecimal.multiply(this.updateInfo.sellingPrice, (1 - value / 100)) * 1).toFixed(2)
			},
			getProfit() {
			  this.updateInfo.profit = (this.$bigDecimal.subtract(this.updateInfo.sellingPrice, this.updateInfo.systemPrice) * 1).toFixed(2)
			},
			// 保留小数
			toDecimal(value) {
			  if (value >= 10000 * 10000) {
			    value = 10000 * 10000 + ''
			  }
			  value = value.replace(/[^\d.]/g, "");// 清除"数字"和"."以外的字符
			  value = value.replace(/^\./g, "");// 验证第一个字符是数字而不是字符
			  value = value.replace(/\.{2,}/g, ".");// 只保留第一个.清除多余的
			  value = value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
			  value = value.replace(/^(\\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');// 只能输入2个小数
			  return value
			},
			
			changeIsShelf(e){
				if(e.detail.value){
					this.updateInfo.isShelf=1
					this.isShelf = true
				}else{
					this.updateInfo.isShelf=0
					this.isShelf = false
				}
				this.onSubmit()
			},
			changeRecTime(e){
				if(e.detail.value){
					this.updateInfo.recTime=1
					this.recTime = true
				}else{
					this.updateInfo.recTime=0
					this.recTime = false
				}
				this.onSubmit()
			},
			changeIsCombo(e){
				if(e.detail.value){
					this.updateInfo.isCombo=1
					this.isCombo = false
				}else{
					this.updateInfo.isCombo=0
					this.isCombo = false
				}
				this.onSubmit()
			},
			changeDate(e,type){
				if(type==1){
					this.updateInfo.discountStartTime = e.detail.value
				}else{
					this.updateInfo.discountEndTime = e.detail.value
				}
			},
			onSubmit(){
				var that = this
				if(parseFloat(that.updateInfo.profitRatio) >parseFloat(that.sysParaProductInfo.sysParaMax) || parseFloat(that.updateInfo.profitRatio)<parseFloat(that.sysParaProductInfo.sysParaMin)){
					that.$toast(that.$t('建议利润比例：'))
					return
				}
				if (that.updateInfo.profitRatio === '' || that.updateInfo.profitRatio === null) {
				  that.$toast(this.$t('请输入利润比例'))
				  return
				}
				let params = {
				  percent: that.updateInfo.profitRatio ? that.updateInfo.profitRatio / 100 : 0,
				  isShelf: that.updateInfo.isShelf,
				  recTime: that.updateInfo.recTime,
				  isCombo: that.updateInfo.isCombo ?? 0,
				  discount: that.updateInfo.discountRatio ? that.updateInfo.discountRatio / 100 : 0,
				  startTime: that.updateInfo.discountStartTime + ' 00:00:00',
				  endTime: that.updateInfo.discountEndTime + ' 00:00:00',
				  sellerGoodsId: that.updateInfo.id
				}
				console.log(params)
				Api.sellerGoodsEdit(params).then((result) => {
					that.$toast(this.$t(result.msg))
					if(result.code == 0){
						setTimeout(()=>{
							uni.navigateBack()
						},1000)
					}
				})
			},
			onDelete(){
				var that = this
				uni.showModal({
					title: this.$t('提示'),
					content: this.$t('确认删除吗'),
					success(res) {
					  if (res.confirm) {
					  	that.sureOnDelete()
					  }else if (res.cancel) {
					  						
					  }
					}
				})
			},
			sureOnDelete(id){
				var that = this
				Api.sellerGoodsDelete({sellerGoodsId:that.updateInfo.id}).then((result) => {
					that.$toast(this.$t(result.msg))
					if(result.code == 0){
						setTimeout(()=>{
							uni.navigateBack()
						},1000)
					}
				})
			}
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
</style>
