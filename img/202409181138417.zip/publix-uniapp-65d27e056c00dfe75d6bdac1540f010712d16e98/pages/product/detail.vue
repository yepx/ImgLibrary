<template>
	<view>
		<view class="a-p-3">
			<view class="a-bg-white a-rounded a-p-3 a-flex a-align-center">
				<view class="a-mr-2">
					<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="detail.imgUrl1"></image>
				</view>
				<view class="a-flex-column a-justify-between">
					<view class="a-flex a-justify-between">
						<text class="a-font a-text-ellipsis-2">{{detail.name}}</text>
					</view>
					<view class='a-flex a-align-center a-mt-1'>
						<text class="a-font-sm a-text-gray a-mr-2">{{detail.categoryName}}</text>
						<text class="a-font-sm a-text-gray a-mr-2">{{$t('销量')}}:{{detail.soldNum}}</text>
					</view>
					<view class="a-flex a-align-center a-mt-1">
						<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="detail.sellingPrice" :currency="true"/>
					</view>
				</view>
			</view>
			<view class="a-bg-white a-mt a-px-3">
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('销售量')}}</text>
					<FormatNumberShow class="a-font" :data="detail.soldNum"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('单价')}}</text>
					<FormatNumberShow class="a-font" :data="detail.sellingPrice" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('购买价格')}}</text>
					<FormatNumberShow class="a-font" :data="detail.systemPrice" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('预期利润')}}</text>
					<FormatNumberShow class="a-font" :data="detail.sellingPrice - detail.systemPrice" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('是否上架')}}</text>
					<text class="a-font">{{detail.isShelf?$t('是'):$t('否')}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('是否推荐')}}</text>
					<text class="a-font">{{detail.recTime?$t('是'):$t('否')}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				detail:{}
			}
		},
		onLoad(options) {
			for(var i in options){
				if(options[i] == "null"){
					options[i] = null
				}else if(options[i] == "0"){
					options[i] = 0
				}else if(options[i] == "1"){
					options[i] = 1
				}
			}
			this.detail = options
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
