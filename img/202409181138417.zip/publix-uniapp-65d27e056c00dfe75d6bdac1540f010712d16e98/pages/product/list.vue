<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		
		<view class="a-flex a-align-center a-justify-between a-mx-3 a-py-3">
			<picker class="a-flex-1" :range="category" range-key="name" :value="indexCategory" @change="changeCategory">
			<view class="a-flex a-align-center a-justify-between a-flex-1 a-px-2 a-rounded a-bg-white a-mr-1 a-h-80">
				<text class="a-font">{{category[indexCategory].categoryId?category[indexCategory].name:$t('一级分类')}}</text>
				<text class="iconfonts icon-xiajiantou a-font"></text>
			</view>
			</picker>
			<picker class="a-flex-1" :range="categorySub" range-key="name" :value="indexCategorySub" @change="changeCategorySub">
			<view class="a-flex a-align-center a-justify-between a-flex-1 a-px-2 a-rounded a-bg-white a-ml-1 a-h-80">
				<text class="a-font">{{categorySub[indexCategorySub].categoryId?categorySub[indexCategorySub].name:$t('二级分类')}}</text>
				<text class="iconfonts icon-xiajiantou a-font"></text>
			</view>
			</picker>
		</view>
		
	
		<view class="a-mx-3">
			<checkbox-group @change="changeCheck">
			
				
			<view v-for="(item,index) in list.data" :key="index" class="a-mb-3 a-flex a-align-center a-justify-between">
				
				<view class="a-w-60 a-flex a-align-center a-justify-center">
					<checkbox  :value="item.id" :checked="item.checked" color="#1552f0" style="transform:scale(0.8)"></checkbox>
				</view>
				<view class="a-bg-white a-rounded a-flex-1 a-p-2 a-flex">
					<view class="a-mr-1">
						<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="item.imgUrl1"></image>
					</view>
					<view class="a-flex-column a-justify-between">
						<view class="a-flex a-justify-between">
							<text class="a-font a-text-ellipsis-2">{{item.name}}</text>
						</view>
						<view class='a-flex a-align-center'>
							<text class="a-font-sm a-text-gray a-mr-2">{{item.categoryName}}</text>
						</view>
						<view class="a-flex a-align-center">
							<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.systemPrice" :currency="true"/>
						</view>
					</view>
				</view>
			</view>
			</checkbox-group>
		</view>
		
		<view class="a-w-750 a-h-100"></view>
		<view class="a-w-750 safeHeight"></view>
        <view class="a-position-fixed a-bottom-0 safePadding a-bg-white">
			<view class="a-w-750 a-h-100 a-flex a-align-center a-justify-between">
				<view class="a-pl-2">
					<label>
					<checkbox-group @change="changeCheckAll" >
						<view class="a-flex a-align-center">
							<checkbox :checked="checkAll" color="#1552f0" style="transform:scale(0.8)"></checkbox>
							<text class="a-font a-text-gray">{{$t('已选')}}:{{checkIndex.length}}</text>
						</view>
					</checkbox-group>
					</label>
				</view>
				<view class="a-flex a-align-center">
					<view @click="onSubmit" class="a-w-200 a-h-100 a-flex a-align-center a-justify-center a-bg-primary" style="margin-right: 5px;">
						<text class="a-font a-text-white">{{$t('加入店铺')}}</text>
					</view>
					<view v-if="false" @click="onAddall" class="a-w-200 a-h-100 a-flex a-align-center a-justify-center a-bg-primary">
						<text class="a-font a-text-white">{{$t('Oneclicklisting')}}</text>
					</view>
				</view>
			</view>
		</view>
		 <!--<view v-else class="a-position-fixed a-bottom-0 safePadding a-bg-black-light">
			<view class="a-w-750 a-h-100 a-flex a-align-center a-justify-center a-bg-black-light">
				<text class="a-font a-text-white">{{$t('店铺认证尚未通过')}}</text>
			</view>
		</view> -->
		<u-popup v-model="popupAdd" mode="center" zIndex="998" width="700" height="850" border-radius="20" closeable>
			<view class="a-p-3">
				<view class="a-flex a-align-center a-justify-center">
					<text class="a-font-lg a-font-weight-bold">{{$t('添加商品')}}</text>
				</view>
				<view class="a-mb-2">
					<view class="a-mb-2 a-flex a-align-center a-justify-between">
						<text class="a-font">{{$t('利润')}}</text>
					</view>
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1"  v-show="sysParaProductInfo.sysParaMax"
						 :value="0"
						type="number" v-model="form.percent"
						
												 :placeholder="$t('百分比')"/>
						<view class="a-ml-2">
							<text class="a-font-sm">%</text>
						</view>
					</view>
					<view>
						<text class="a-font-sm">{{$t('将选中的商品发布到你的店铺，并填写商品利润比例，推荐比例:')}}<span class="a-text-primary">{{ sysParaProductInfo.sysParaMin }}% — {{ sysParaProductInfo.sysParaMax }}%</span></text>
					</view>
				</view>
				<view class="a-mb-2">
					<view class="a-mb-2">
						<text class="a-font">{{$t('折扣开始日期')}}</text>
					</view>
					<picker mode="date" :value="form.startTime" :start="startDate" :end="endDate" @change="changeDate($event,1)">
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<text class="a-font a-flex-1" :class="form.startTime?'':'a-text-gray'">{{form.startTime?form.startTime:$t('折扣开始日期')}}</text>
					</view>
					</picker>
				</view>
				<view class="a-mb-2">
					<view class="a-mb-2">
						<text class="a-font">{{$t('折扣结束日期')}}</text>
					</view>
					<picker mode="date" :value="form.endTime" :start="startDate" :end="endDate" @change="changeDate($event,2)">
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<text class="a-font a-flex-1" :class="form.endTime?'':'a-text-gray'">{{form.endTime?form.endTime:$t('折扣结束日期')}}</text>
					</view>
					</picker>
				</view>
				<view class="a-mb-2">
					<view class="a-mb-2 a-flex a-align-center a-justify-between">
						<text class="a-font">{{$t('折扣比例')}}</text>
					</view>
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1" type="number" :disabled="!form.startTime && !form.endTime" v-model="form.discount" :placeholder="$t('折扣比例')"/>
						<view class="a-ml-2">
							<text class="a-font-sm">%</text>
						</view>
					</view>
				</view>
				
				<view @click="sureOnSubmit" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
					<text class="a-font-lg a-text-white">{{$t('添加')}}</text>
				</view>
			</view>
		</u-popup>
		
		
		<u-popup v-model="popupAddall" mode="center" zIndex="998" width="700" height="850" border-radius="20" closeable>
			<view class="a-p-3">
				<view class="a-flex a-align-center a-justify-center">
					<text class="a-font-lg a-font-weight-bold">{{$t('Oneclicklisting')}}</text>
				</view>
				<view class="a-mb-2">
					<view class="a-mb-2 a-flex a-align-center a-justify-between">
						<text class="a-font">{{$t('利润')}}</text>
					</view>
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1"  v-show="sysParaProductInfo.sysParaMax"
						 :value="0"
						type="number" v-model="allpercent"
						
												 :placeholder="$t('百分比')"/>
						<view class="a-ml-2">
							<text class="a-font-sm">%</text>
						</view>
					</view>
					<view>
						<text class="a-font-sm">{{$t('将选中的商品发布到你的店铺，并填写商品利润比例，推荐比例:')}}<span class="a-text-primary">{{ sysParaProductInfo.sysParaMin }}% — {{ sysParaProductInfo.sysParaMax }}%</span></text>
					</view>
				</view>
			<view class="a-mb-2">
					
					
				</view>
				
				<view @click="sureOnSubmit2" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
					<text class="a-font-lg a-text-white">{{$t('Oneclicklisting')}}</text>
				</view>
			</view>
		</u-popup>
		
		
		
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				allpercent:0,
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				sellerInfo:{},
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
				options:{
					categoryId:''
				},
				indexCategory:0,
				category:[
					{
						categoryId:'',
						name:this.$t('全部分类')
					}
				],
				indexCategorySub:0,
				categorySub:[
					{
						categoryId:'',
						name:this.$t('全部分类')
					}
				],
				
				checkAll:false,
				checkIndex:[],
				popupAddall:false,
				popupAdd:false,
				sysParaProductInfo:{},
				form:{
					goodsIds:null,
					startTime:'',
					endTime:'',
					discount:'',
					percent:'',
					profit:'',
				}
			}
		},
		onShow() {
			this.getSellerInfo()
			this.getSellerGoodsCate()
			this.getSellerSysParaProduct()
		},
		computed: {
		  startDate() {
			return this.getDate('start');
		  },
		  endDate() {
			return this.getDate('end');
		  }
		},
		
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.$navTo(`pages/search/product`)
			}
		},
		methods: {
			sureOnSubmit2(e){
				if (this.allpercent==''||this.allpercent==0||this.allpercent==undefined){
					this.$toast(this.$t('建议利润比例：'))
					return
				}
				
				if(parseFloat(this.allpercent) >parseFloat(this.sysParaProductInfo.sysParaMax) || parseFloat(this.allpercent)<parseFloat(this.sysParaProductInfo.sysParaMin)){
					this.$toast(this.$t('建议利润比例：'))
					return
				}
				let that=this;
				let maxprice=this.allpercent/100
				
				
				console.log(maxprice)
				if (maxprice==''||maxprice==0||maxprice==undefined){
					this.$toast(this.$t('建议利润比例：'))
					return ;
				}
				uni.showModal({
					title: this.$t('Oneclicklisting'),
					content: this.$t('One-click listing'),
				//	confirmText: this.$t('认证'),
					success(res) {
					  if (res.confirm) {
						  
						  let postdata={
						  	profit:maxprice
						  	
						  }
						  
						  Api.addProAll(postdata).then(res => {
						  	const {status,message,data} = res;
						  	if (res.code==0){
						  		that.$toast(that.$t('proAdd'))
								that.popupAddall=false;
						  	}else{
						  		that.$toast(that.$t('error'))
						  	}
						  	
						  });
						  
					//	that.$navTo('pages/mine/personalInfo')
					  }
					}
				})
				
			},
			onAddall(){
				
				let that=this;
				that.popupAddall=true;
				return 
				let maxprice=this.sysParaProductInfo.sysParaMax;
				console.log(maxprice)
				if (maxprice==''||maxprice==0){
					this.$toast(this.$t('建议利润比例：'))
					return ;
				}
				uni.showModal({
					title: this.$t('Oneclicklisting'),
					content: this.$t('One-click listing'),
				//	confirmText: this.$t('认证'),
					success(res) {
					  if (res.confirm) {
						  
						  let postdata={
						  	profit:maxprice
						  	
						  }
						  
						  Api.addProAll(postdata).then(res => {
						  	const {status,message,data} = res;
						  	if (res.code==0){
						  		that.$toast(that.$t('proAdd'))
						  	}else{
						  		that.$toast(that.$t('error'))
						  	}
						  	
						  });
						  
					//	that.$navTo('pages/mine/personalInfo')
					  }
					}
				})
				
				
				
			},
			getDate(type) {
				const date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth() + 1;
				let day = date.getDate();
				
				if (type === 'start') {
					year = year - 60;
				} else if (type === 'end') {
					year = year + 2;
				}
				month = month > 9 ? month : '0' + month;
				day = day > 9 ? day : '0' + day;
				return `${year}-${month}-${day}`;
			},
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
				});
			},
			getSellerSysParaProduct() {
				const that = this
				Api.sellerSysParaProduct().then(result =>{
					that.sysParaProductInfo = result.data
				})
			},
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						pageNum:pageNo,
						pageSize:pageSize,
					};
					if(that.options.secondaryCategoryId){
						params.secondaryCategoryId = that.options.secondaryCategoryId
					}else if(that.options.categoryId){
						params.categoryId = that.options.categoryId
					}
					Api.sellerGoodsSys(params).then(result =>{
						const newList = result.data
						newList.data = result.data.pageList
						for(var i in newList.data){
							newList.data[i].checked = false
						}
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			// 分类
			getSellerGoodsCate() {
				const that = this
				Api.sellerGoodsCate().then(result =>{
					this.category =[...this.category,...result.data]
				})
			},
			changeCategory(e){
				this.indexCategory = e.detail.value
				this.options.categoryId = this.category[this.indexCategory].categoryId
				if(this.category[this.indexCategory].categoryId){
					this.categorySub = [
						{
							categoryId:'',
							name:this.$t('全部分类')
						}
					]
					this.categorySub = [...this.categorySub,...this.category[this.indexCategory].subList]
				}else{
					this.categorySub = [
						{
							categoryId:'',
							name:this.$t('全部分类')
						}
					]
				}
				this.indexCategorySub = 0
				this.options.secondaryCategoryId =''
				this.onRefreshList()
				
			},
			changeCategorySub(e){
				this.indexCategorySub = e.detail.value
				this.options.secondaryCategoryId = this.categorySub[this.indexCategorySub].categoryId
				if(this.categorySub[this.indexCategorySub].categoryId){
					this.options.categoryId = ''
				}
				this.onRefreshList()
			},
			changeCheck(e){
				this.checkIndex = e.detail.value
				console.log(this.checkIndex)
			},
			changeCheckAll(){
			    if(this.checkAll){
			        this.checkAll = false
			        for(var i in this.list.data){
			            this.list.data[i].checked = false
			        }
			    }else{
			        this.checkAll = true
			        for(var i in this.list.data){
			            this.list.data[i].checked = true
			        }
			    }
				
			    if(this.checkAll){
			        let index = []
			        for(var i in this.list.data){
			            index.push(this.list.data[i].id)
			        }
			        this.checkIndex = index
			    }else{
					let index = []
			        this.checkIndex = index
			    }
			},
			
			
			changeDate(e,type){
				if(type==1){
					this.form.startTime = e.detail.value
				}else{
					this.form.endTime = e.detail.value
				}
			},
			onSubmit(){
								var that = this
								if(this.sellerInfo.status == 2 || this.sellerInfo.status == 1){
									
								}else{
									uni.showModal({
										title: this.$t('认证'),
										content: this.$t('店铺认证尚未通过'),
										confirmText: this.$t('认证'),
										success(res) {
										  if (res.confirm) {
											that.$navTo('pages/mine/personalInfo')
										  }
										}
									})
									// this.$toast(this.$t('店铺认证尚未通过'))
									return
								}

				if(!this.checkIndex.length){
					this.$toast(this.$t('请选择商品'))
					return
				}
				this.form = {
					goodsIds:null,
					startTime:'',
					endTime:'',
					discount:'',
					percent:'',
					profit:'',
				}
				this.form.goodsIds = ''
				for(var i in this.checkIndex){
					if(i==0){
						this.form.goodsIds = this.checkIndex[i]
					}else{
						this.form.goodsIds = this.form.goodsIds+','+this.checkIndex[i]
					}
				}
				this.popupAdd = true
			},
			sureOnSubmit(){
				console.log(this.form.percent)
				console.log(parseFloat(this.sysParaProductInfo.sysParaMax))
				if (this.form.percent==''){
					this.$toast(this.$t('建议利润比例：'))
					return
				}
				
				if(parseFloat(this.form.percent) >parseFloat(this.sysParaProductInfo.sysParaMax) || parseFloat(this.form.percent)<parseFloat(this.sysParaProductInfo.sysParaMin)){
					this.$toast(this.$t('建议利润比例：'))
					return
				}
				//if (this.form.percent==0){
				  //  this.form.percent=this.sysParaProductInfo.sysParaMax
				//	debugger
			//	}
				this.form.profit = this.form.percent
				
				
				const that = this
				var params = {
					goodsIds:this.form.goodsIds,
					startTime:this.form.startTime + ' 00:00:00',
					endTime:this.form.endTime + ' 00:00:00',
					discount:this.form.discount?this.form.discount/100:0,
					percent:this.form.percent?this.form.percent/100:0,
					profit:this.form.percent?this.form.percent/100:0,
				}
				Api.sellerGoodsAdd(params).then(result =>{
					this.$toast(this.$t(result.msg))
					this.$toast(this.$t(result.msg))
					if(result.code == 0){
						this.popupAdd = false
						this.form = {
							goodsIds:null,
							startTime:'',
							endTime:'',
							discount:'',
							percent:'',
							profit:'',
						}
						this.onRefreshList()
					}
				})
			}
		}
	}
</script>

<style>

</style>
