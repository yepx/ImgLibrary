<template>
	<view>
		<view class="a-p-3">
			<view class="a-bg-white a-rounded a-p-3">
				<view v-for="(item,index) in orderLog" :key="index" class="item a-pb-5 a-pl-3 a-position-relative">
					<view class="a-mb-2">
						<text class="a-font">{{$t('订单')}}</text>
						<text class="a-font a-text-primary">#{{ item.orderId }}#</text>
						<text class="a-font">{{ $t(item.tipsTxt) }}</text>
					</view>
					<text class="a-font">{{item.createTime}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				orderLog:[],
				
				
			}
		},
		onLoad(options) {
			this.getOrderLog(options.id)
		},
		methods: {
			getOrderLog(id) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						orderId:id
					};
					Api.orderLog(params).then(result =>{
						const data = result.data.map(item => {
						  const arr = item.log.split(item.orderId)
						  return {
						    ...item,
						    tipsTxt: arr[1]
						  }
						}).reverse()
						this.orderLog = data
						console.log(this.orderLog)
					})
				})
			},
			
		}
	}
</script>

<style lang="scss">
.item:before {
    content: "";
    display: block;
    width: 4rpx;
    height: 100%;
    background-color: #1552f0;
    position: absolute;
    top: 5rpx;
    left: 8rpx;
}
.item:after {
    content: "";
    display: block;
    width: 20rpx;
    height: 20rpx;
    border-radius: 50%;
    background-color: #1552f0;
    position: absolute;
    top: 4rpx;
    left: 0;
}
.item:last-child:before {
    height: 15rpx;
}
</style>
