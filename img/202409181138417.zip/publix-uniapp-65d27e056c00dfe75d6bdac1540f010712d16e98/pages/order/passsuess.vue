<template>
	<view>
		<view class="a-w-750 a-flex-column a-align-center a-justify-center a-py-10">
			<view class="a-bg-green a-w-110 a-h-110 a-rounded-circle a-flex a-align-center a-justify-center">
				<text class="iconfonts icon-dagou a-font-max-two a-text-white"></text>
			</view>
			<view class="a-mt-3">
				<text class="a-font-lg">{{$t('支付成功')}}</text>
			</view>
			<view class="a-mt-5">
				<text class="a-font a-text-gray a-mr-1">{{$t('如有任何疑问，请立即联系我们')}}</text>
				<text @click="$navTo('pages/customerService/index')" class="a-font a-text-primary">{{$t('联系客服')}}</text>
			</view>
		</view>
		
		<view @click="$navTo('pages/main/home')" class="a-mx-2 a-bg-primary a-w-710 a-rounded a-py-2 a-flex a-align-center a-justify-center">
			<text class="a-font-lg a-text-white">{{$t('回到首页')}}</text>
		</view>
		<view  @click="$navTo('pages/order/detail?id='+id+'&title='+$t('订单详情'))" class="a-mx-2 a-border a-border-primary a-w-710 a-rounded a-py-2 a-flex a-align-center a-justify-center a-mt-2">
			<text class="a-font-lg a-text-primary">{{$t('查看订单')}}</text>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				id:0,
				
			}
		},
		onLoad(options) {
			this.id=options.id
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
