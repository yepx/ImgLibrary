<template>
	<view>
		<view class="a-p-3">
			<view class="a-bg-white a-rounded a-px-3 a-mb-3">
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('订单号')}}</text>
					<view>
						<text class="a-font a-text-gray">{{detailInfo.id}}</text>
						<text @click.stop="copy(detailInfo.id)" class="iconfonts icon-fuzhi1 a-font-lg a-text-gray a-ml-1"></text>
					</view>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('下单时间')}}</text>
					<text class="a-font ">{{detailInfo.createTime}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('采购时间')}}</text>
					<text class="a-font ">{{detailInfo.pushTime}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('付款方式')}}</text>
					<text class="a-font ">{{$t('钱包')}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('支付状态')}}</text>
					<text class="a-font">{{detailInfo.payStatus?$t('已支付'):$t('未支付')}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('物流状态')}}</text>
					<text class="a-font">{{getOrderStatus(detailInfo.status)}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('采购金额')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.systemPrice" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('销售金额')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.prizeOriginal" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('姓名')}}</text>
					<text class="a-font">{{detailInfo.username}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('邮箱')}}</text>
					<text class="a-font">{{detailInfo.email}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('手机')}}</text>
					<text class="a-font">{{detailInfo.phone}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('国家')}}</text>
					<text class="a-font">{{detailInfo.country}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('州')}}</text>
					<text class="a-font">{{detailInfo.province}}</text>
				</view><view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('城市')}}</text>
					<text class="a-font">{{detailInfo.city}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between" v-if="false">
					<text class="a-font a-text-gray">{{$t('邮编')}}</text>
					<text class="a-font">{{detailInfo.postcode}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('收货地址')}}</text>
					<text class="a-font">{{detailInfo.address}}</text>
				</view>
			</view>
			<view v-for="(item,index) in detailGoods" class="a-bg-white a-rounded a-mb-3">
				<view class="a-flex a-align-center a-justify-between a-border-bottom a-border-light a-p-2">
					<text class='a-font'>{{$t('产品编号')}}</text>
					<view class="a-flex a-align-center">
						<text class="a-font a-font-weight-bold">{{item.goodsId}}</text>
						<text @click.stop="copy(item.goodsId)" class="iconfonts icon-fuzhi1 a-font-lg a-text-gray a-ml-1"></text>
					</view>
				</view>
				<view :key="index" class="a-p-3 a-flex a-align-center">
					<view class="a-mr-2">
						<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="item.goodsIcon"></image>
					</view>
					<view class="a-flex-column a-justify-between">
						<view class="a-flex a-justify-between">
							<text class="a-font-lg a-font-weight-bold a-text-ellipsis-3">{{item.goodsName}}</text>
						</view>
						<view v-for="(items,indexs) in item.attributes" class='a-flex a-align-center  a-mt-1'>
							<text class="a-font-sm a-text-gray a-mr-1">{{items.attrName}}:</text>
							<text class="a-font-sm a-mr-2">{{items.attrValue}}</text>
						</view>
						<view class="a-flex a-align-center a-justify-between a-mt-1">
							<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.systemPrice" :currency="true"/>
							<text class="a-font a-text-primary">x{{item.goodsNum}}</text>
						</view>
					</view>
				</view>
			</view>
			<view class="a-bg-white a-rounded a-px-3 a-mb-5">
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('小计')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.prizeOriginal" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('税')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.tax" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('运费')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.fees" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('合计')}}</text>
					<FormatNumberShow class="a-font a-text-primary" :data="detailInfo.prizeReal" :currency="true"/>
				</view>
			</view>
			
			<!-- <view @click="onBuy(detailInfo.id)" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white a-mr-1">{{$t('立即支付')}}</text>
				<FormatNumberShow class="a-font-lg a-text-white" :data="detailInfo.sellerDiscountPrice" :currency="true"/>
			</view> -->
		</view>
		<view class="a-position-fixed a-right-2" style="bottom:300rpx;">
			<view @click="$navTo('pages/order/logistics?id='+detailInfo.id)" class="a-w-90 a-h-90 a-rounded-circle a-bg-primary a-flex a-align-center a-justify-center">
				<image class="a-w-50 a-h-40" :src="globalData.imgUrl+'/images/ico-wl.png'"></image>
			</view>
			<view @click="$navTo('pages/chat/index?partyid='+detailInfo.partyId+'&username='+detailInfo.username)" class="a-mt-3 a-w-90 a-h-90 a-rounded-circle a-bg-primary a-flex a-align-center a-justify-center">
				<image class="a-w-50 a-h-50" :src="globalData.imgUrl+'/images/ico-c.png'"></image>
			</view>
		</view>
		<cc-defineKeyboard ref="CodeKeyboard" :passwordArr="passwordArr" passwrdType="pay" @KeyInfo="KeyInfo"></cc-defineKeyboard>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				detailGoods:{},
				detailInfo:{},
				
				buyId:null,
				passwordArr:[],
				popupPassword:false,
				
			}
		},
		onLoad(options) {
			if(options.title){
				uni.setNavigationBarTitle({
					title:options.title
				})
			}
			this.getOrderDetailGoods(options.id)
			this.getOrderDetailInfo(options.id)
		},
		methods: {
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			},
			getOrderStatus(status) {
			  let obj = {
			    '-1': "订单已取消",
			    0: "等待买家付款",
			    1: "买家已付款",
			    2: "供应商已接单",
			    3: "物流运输中",
			    4: "买家已签收",
			    5: "订单已完成",
			    6: "已退款"
			  };
			
			  return this.$t(obj[status]);
			},
			getOrderDetailGoods(id) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						orderId:id
					};
					Api.orderDetailGoods(params).then(result =>{
						this.detailGoods = result.data.pageList
					})
				})
			},
			getOrderDetailInfo(id) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						orderId:id,
						
					};
					Api.orderDetailInfo(params).then(result =>{
						this.detailInfo = result.data.orderInfo
					})
				})
			},
			
			onBuy(id){
				this.buyId = id
				this.popupPassword = true
				this.passwordArr = []
				this.$refs.CodeKeyboard.keyIndex = -1
				this.$refs.CodeKeyboard.show();
			},
			KeyInfo(val) {
				if (val.index >= 6) {
					return;
				}
				// 判断是否输入的是删除键
				if (val.keyCode === 8) {
					// 删除最后一位
					this.passwordArr.splice(val.index + 1, 1)
				}
				// 判断是否输入的是.
				else if (val.keyCode == 190) {
					this.$refs.CodeKeyboard.hide();
				} else {
					this.passwordArr.push(val.key);
				}
				// uni.showModal({
				// 	title: '温馨提示',
				// 	content: '输入密码是 = ' + JSON.stringify(this.passwordArr)
				// })
				if(val.index >= 5){
					this.promotionalBuy()
				}
			},
			// 
			promotionalBuy(id) {
				const that = this
				var password = ''
				for(var i in this.passwordArr){
					password = password + this.passwordArr[i] 
				}
				var params = {
					safeword:password,
					orderId:that.buyId,
				}
				Api.orderBuy(params).then(result =>{
					if(result.code == 0){
						that.$refs.CodeKeyboard.hide();
						that.$toast(that.$t('成功'))
					}else{
						that.$toast(this.$t(result.msg))
					}
					
				})
			},
		}
	}
</script>

<style>

</style>
