<template>
	<view>
		<view class="a-p-3">
			<view v-for="(item,index) in detailGoods" :key="index" class="a-bg-white a-rounded a-p-3 a-flex a-align-center a-mb-3">
				<view class="a-mr-2">
					<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="item.goodsIcon"></image>
				</view>
				<view class="a-flex-column a-justify-between">
					<view class="a-flex a-justify-between">
						<text class="a-font-lg a-font-weight-bold a-text-ellipsis-3">{{item.goodsName}}</text>
					</view>
					<view class='a-flex a-align-center a-justify-between a-mt-1'>
						<text class="a-font-sm a-text-gray a-mr-2">{{$t('采购数量')}}</text>
						<text class="a-font a-text-primary">x{{item.goodsNum}}</text>
					</view>
					<view class="a-flex a-align-center a-mt-1">
						<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.systemPrice" :currency="true"/>
					</view>
				</view>
			</view>
			<view class="a-bg-white a-rounded a-px-3 a-mb-5">
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('买家付款')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.prizeReal" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('采购金额')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.systemPrice" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-end" v-if="false">
					<text class="a-font">{{$t('优惠价')}}</text>
					<FormatNumberShow class="a-font a-text-primary" :data="detailInfo.sellerDiscountPrice" :currency="true"/>
					<text class="a-font">,</text>
					<text class="a-font">{{$t('采购优惠')}}</text>
					<FormatNumberShow class="a-font a-text-primary" :data="detailInfo.sellerDiscount *100" />
					<text class="a-font">%</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('采购数量')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.goodsCount"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('利润')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.profit" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('运费')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.fees" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('税')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.tax" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between" v-if="false">
					<text class="a-font a-text-gray">{{$t('合计')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.sellerDiscountPrice" :currency="true"/>
				</view>
			</view>
			
			<view @click="onBuy(detailInfo.id)" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white a-mr-1">{{$t('立即支付')}}</text>
				<FormatNumberShow class="a-font-lg a-text-white" :data="detailInfo.systemPrice" :currency="true"/>
			</view>
		</view>
		
		<cc-defineKeyboard ref="CodeKeyboard" :passwordArr="passwordArr" passwrdType="pay" @KeyInfo="KeyInfo"></cc-defineKeyboard>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				detailGoods:{},
				detailInfo:{},
				
				buyId:null,
				passwordArr:[],
				popupPassword:false,
				
			}
		},
		onLoad(options) {
			if(options.title){
				uni.setNavigationBarTitle({
					title:options.title
				})
			}
			this.getOrderDetailGoods(options.id)
			this.getOrderDetailInfo(options.id)
		},
		methods: {
			getOrderDetailGoods(id) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						orderId:id
					};
					Api.orderDetailGoods(params).then(result =>{
						this.detailGoods = result.data.pageList
					})
				})
			},
			getOrderDetailInfo(id) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						orderId:id
					};
					Api.orderDetailInfo(params).then(result =>{
						this.detailInfo = result.data.orderInfo
						
					})
				})
			},
			
			onBuy(id){
				this.buyId = id
				this.popupPassword = true
				this.passwordArr = []
				this.$refs.CodeKeyboard.keyIndex = -1
				this.$refs.CodeKeyboard.show();
			},
			KeyInfo(val) {
				if (val.index >= 6) {
					return;
				}
				// 判断是否输入的是删除键
				if (val.keyCode === 8) {
					// 删除最后一位
					this.passwordArr.splice(val.index + 1, 1)
				}
				// 判断是否输入的是.
				else if (val.keyCode == 190) {
					this.$refs.CodeKeyboard.hide();
				} else {
					this.passwordArr.push(val.key);
				}
				// uni.showModal({
				// 	title: '温馨提示',
				// 	content: '输入密码是 = ' + JSON.stringify(this.passwordArr)
				// })
				if(val.index >= 5){
					this.promotionalBuy()
				}
			},
			// 
			promotionalBuy(id) {
				const that = this
				var password = ''
				for(var i in this.passwordArr){
					password = password + this.passwordArr[i] 
				}
				var params = {
					safeword:password,
					orderId:that.buyId,
				}
				Api.orderBuy(params).then(result =>{
					if(result.code == 0){
						that.$refs.CodeKeyboard.hide();
						that.$toast(that.$t('成功'))
						that.$navTo('pages/order/passsuess?id='+that.buyId)
					}else{
						that.$toast(this.$t(result.msg))
					}
					
				})
			},
		}
	}
</script>

<style>

</style>
