<template>
	<view>
		<view class="a-mb-3 a-px-3 a-bg-white a-px-2 a-rounded">
			<view class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font-sm">{{$t('清除缓存')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="a-font">0MB</text>
				</view>
			</view>
			<view class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font-sm">{{$t('检查更新')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="a-font">V1.0.2</Var></text>
				</view>
			</view>
			
		</view>
		
		<view @click="Logout" class="a-m-3 a-bg-red a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
			<text class="a-font-lg a-text-white">{{$t('退出')}}</text>
		</view>
		
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import store from '@/store'
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
			}
		},
		onShow() {
		},
		methods: {
			Logout(){
				store.dispatch('Logout', {})
				  .then(result => this.$navTo('pages/login/index'))
			}
		}
	}
</script>

<style>

</style>
