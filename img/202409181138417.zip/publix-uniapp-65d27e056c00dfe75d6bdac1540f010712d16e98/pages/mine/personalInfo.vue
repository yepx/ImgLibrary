<template>
	<view>
		<view class="a-mb-3 a-px-3 a-bg-white a-px-2 a-rounded">
			<view @click="$navTo('pages/mine/avatar?avatar='+userInfo.avatar)" class="a-py-2 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('头像')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<image class="a-w-130 a-h-130 a-rounded-circle" mode="aspectFill" :src="`/static/images/avatar/${userInfo.avatar}.png`"></image>
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/auth')" class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('真实姓名')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<view class="a-flex a-align-center">
						<text class="a-font-sm a-text-gray a-mr-1">{{userInfo.name}}</text>
						<text class="iconfonts a-font-lg a-mr-1" :class="userInfo.kyc_status==1?'icon-shenhezhong2 a-text-orange':userInfo.kyc_status==2?'icon-dagou1 a-text-green':'icon-guanbixiao a-text-red'"></text>
						<text class="a-font-sm a-text-gray a-mr-1">{{userInfo.kyc_status==1?$t('审核中'):userInfo.kyc_status==2?$t('已认证'):userInfo.kyc_status==3?$t('审核失败'):$t('未认证')}}</text>
					</view>
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/verify?type=1')" class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('手机验证')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<view v-if="userInfo.phone" class="a-flex a-align-center">
						<text class="a-font-sm a-text-gray a-mr-1">{{getPhone(userInfo.phone)}}</text>
						<text class="iconfonts a-font-lg a-mr-1" :class="userInfo.phoneverif?'icon-dagou1 a-text-green':'icon-guanbixiao a-text-red'"></text>
						<text class="a-font-sm a-text-gray a-mr-1">{{userInfo.phoneverif?$t('已认证'):$t('未认证')}}</text>
					</view>
					<text v-else class="a-font-sm a-text-gray a-mr-1">{{$t('未设置')}}</text>
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/verify?type=2')" class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('邮箱验证')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<view v-if="userInfo.email" class="a-flex a-align-center">
						<text class="a-font-sm a-text-gray a-mr-1">{{getEmail(userInfo.email)}}</text>
						<text class="iconfonts a-font-lg a-mr-1" :class="userInfo.emailverif?'icon-dagou1 a-text-green':'icon-guanbixiao a-text-red'"></text>
						<text class="a-font-sm a-text-gray a-mr-1">{{userInfo.emailverif?$t('已认证'):$t('未认证')}}</text>
					</view>
					<text v-else class="a-font-sm a-text-gray a-mr-1">{{$t('未设置')}}</text>
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/password?type=2&isHave='+userInfo.safeword)" class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('修改资金密码')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text v-if="!userInfo.safeword" class="a-font-sm a-text-gray a-mr-1">{{$t('未设置')}}</text>
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/password?type=1&isHave=1')" class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('修改登录密码')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			
		</view>
		
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				userInfo:{},
				kycInfo:{}
				
			}
		},
		onShow() {
			this.getUserInfo()
			this.getKycInfo()
		},
		methods: {
			getEmail(email){
				if(email){
					return utils.emailHide(email)
				}else{
					return ''
				}
				
			},
			getPhone(phone){
				if(phone){
				    return utils.phoneHide(phone)
				}else{
					return ''
				}
				
			},
			// 个人信息
			getUserInfo() {
				const that = this
				Api.info().then(result =>{
					that.userInfo = result.data
				})
			},
			getKycInfo() {
				var that = this;
				Api.kycInfo().then(res => {
					const {status,message,data} = res;
					that.kycInfo = res.data
				});
			},
			
		}
	}
</script>

<style>

</style>
