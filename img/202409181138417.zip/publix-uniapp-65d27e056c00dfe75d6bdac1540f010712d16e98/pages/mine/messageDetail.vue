<template>
	<view>
		<view class="a-p-3">
			<view class="">
				<text class="a-font-lg a-font-weight-bold">{{detail.title}}</text>
			</view>
			<view class="a-border-bottom a-border-light a-py-2">
				<text class="a-font-min a-text-gray">{{time}}</text>
			</view>
			<view class="a-mt-2">
				<text class="a-font">{{detail.content}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from '@/utils/util'
	export default {
		data() {
			return {
				globalData: App.globalData,
				isMP: false,
				isLogin: false,
				time:'',
				detail:{}
				
			}
		},
		onLoad(options) {
			this.getList(options.id)
			this.time = options.time
		},
		methods: {
			getTime(time){
				return utils.getTime(time)
			},
			// 获取订单列表
			getList(id) {
				var that = this
				Api.notificationDetail({id:id}).then(result =>{
					this.detail = this.getElementsI18n([result.data])
				})
			},
			getElementsI18n(list) {
				console.log(list)
			  list.forEach(item => {
			    // i18n支持通配符
			    let varInfo = JSON.parse(item.varInfo)
			    let varObj = {}
			    varInfo.forEach((item, index) => {
			      varObj[item.code] = item.value
			    })
			    switch (item.title) {
			      case 'One order finished':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Freeze seller because of violation':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'New Order':
			        item.content = this.$t(item.content)
			        break;
			      case 'Order overtime':
			        item.content = this.$t(item.content)
			        break;
			      case 'Buyer Consult from Customer Service':
			        item.content = this.$t(item.content)
			        break;
			      case 'Your Seller-Credit updated':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'UnFreeze seller':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Withdraw Success Notify':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Recharge Pass Notify':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Store certification passed':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Store authentication failed':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Order purchase overtime':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			    }
			    item.title = this.$t(item.title)
			  })
			  return list[0]
			},
		}
	}
</script>

<style lang="scss">
page {
	background-color: #ffffff;
}
</style>