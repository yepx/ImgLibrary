<template>
	<view>
		<view class="a-p-3">
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">{{$t('店铺横幅')}} 1(1920X300)</text>
				</view>
				<view v-if="form.banner1" @click="setImage(1)" class="a-w-690 a-border a-bg-white a-rounded a-h-110 a-flex-column a-align-center a-justify-center a-px-2 ">
					<image class="a-w-690 a-h-110" :src="form.banner1"></image>
				</view>
				<view v-else @click="setImage(1)" class="a-w-690 a-border a-bg-white a-rounded a-h-110 a-flex-column a-align-center a-justify-center a-px-2 ">
					<text class="iconfonts icon-xiangji a-font-max a-text-gray-light "></text>
					<text class="a-font-sm a-text-gray">{{$t('添加横幅')}}</text>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">{{$t('店铺横幅')}} 2(1920X300)</text>
				</view>
				<view v-if="form.banner2" @click="setImage(2)" class="a-w-690 a-border a-bg-white a-rounded a-h-110 a-flex-column a-align-center a-justify-center a-px-2 ">
					<image class="a-w-690 a-h-110" :src="form.banner2"></image>
				</view>
				<view v-else @click="setImage(2)" class="a-w-690 a-border a-bg-white a-rounded a-h-110 a-flex-column a-align-center a-justify-center a-px-2 ">
					<text class="iconfonts icon-xiangji a-font-max a-text-gray-light "></text>
					<text class="a-font-sm a-text-gray">{{$t('添加横幅')}}</text>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">{{$t('店铺横幅')}} 3(1920X300)</text>
				</view>
				<view v-if="form.banner3" @click="setImage(3)" class="a-w-690 a-border a-bg-white a-rounded a-h-110 a-flex-column a-align-center a-justify-center a-px-2 ">
					<image class="a-w-690 a-h-110" :src="form.banner3"></image>
				</view>
				<view v-else @click="setImage(3)" class="a-w-690 a-border a-bg-white a-rounded a-h-110 a-flex-column a-align-center a-justify-center a-px-2 ">
					<text class="iconfonts icon-xiangji a-font-max a-text-gray-light "></text>
					<text class="a-font-sm a-text-gray">{{$t('添加横幅')}}</text>
				</view>
			</view>
			
			
			<view @click="onSubmit" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('保存')}}</text>
			</view>
		</view>
		
		<cropper ref="cropper" :aspectRatio="aspectRatio" @complete="complete" @cancel="cancel" ></cropper>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as UploadApi from '@/api/upload'
	import * as utils from "@/utils/util";
	import Cropper from '@/components/Cropper/cropper.vue';
	export default {
		components:{
			Cropper
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				sellerInfo:{},
				aspectRatio:6.4,
				type:1,
				form:{
					banner1:'',
					banner2:'',
					banner3:''
				}
			}
		},
		onLoad() {
			this.getSellerInfo()
		},
		methods: {
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
					for(var i in that.sellerInfo){
					  for(var ii in that.form){
						if(ii==i){
							that.form[ii] = that.sellerInfo[i]
						}
					  }
					}
				});
			},
			setImage(type){
				this.type = type
			    uni.chooseImage({
			        count: 1, 
			        mediaType:['image'],
			        sourceType:['album', 'camera'],
			        success: function (res) {
						this.$refs.cropper.init(res.tempFilePaths[0]);
			        }.bind(this)
			    });
			},
			complete(object){
				var blob = this.dataURLtoBlob(object.path);
				var file = this.blobToFile(blob, 'shopAvatar',object.path);
				this.uploadImg([file])
				this.$refs.cropper.close();
			},
			cancel(){
				this.$refs.cropper.close();
			},
			//将base64转换为blob
			dataURLtoBlob(dataurl) { 
			    var arr = dataurl.split(','),
			    mime = arr[0].match(/:(.*?);/)[1],
			    bstr = atob(arr[1]),
			    n = bstr.length,
			    u8arr = new Uint8Array(n);
			    while (n--) {
			        u8arr[n] = bstr.charCodeAt(n);
			    }
			    return new Blob([u8arr], { type: mime });
			},
			//将blob转换为file
			blobToFile(theBlob, fileName,path){
			   theBlob.lastModifiedDate = new Date();
			   theBlob.name = fileName;
			   theBlob.path = path;
			   return theBlob;
			},
			uploadImg(array){
				UploadApi.image(array,'shopAvatar').then(result => {
					  if(this.type==1){
					  	this.form.banner1 = result[0]
					  }else if(this.type==2){
					  	this.form.banner2 = result[0]
					  }else if(this.type==3){
					  	this.form.banner3 = result[0]
					  }
				  })
			},
			onSubmit() {
				var that = this;
				Api.sellerUpdate(that.form).then(res => {
					that.$toast(this.$t(res.msg))
				});
			},
		}
	}
</script>

<style lang="scss">
</style>
