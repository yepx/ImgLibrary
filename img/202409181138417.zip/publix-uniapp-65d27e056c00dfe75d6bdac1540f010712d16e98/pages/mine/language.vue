<template>
	<view>
		<view class="a-flex a-align-center a-justify-between a-h-100 a-px-3 a-border-top a-border-light" v-for="(item, index) in language" :key="index" @click="setLanguage(index)">
		    <view class="a-flex a-align-center">
				<image :src="globalData.imgUrl+item.icon" class="a-w-40 a-h-40 a-mr-3" ></image>
		        <view class="title">{{ item.title }}</view>
		    </view>
		    <text v-if="item.checked"  class="iconfonts icon-dagou a-font-sm a-text-primary" ></text>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import languages from "@/common/js/language.js"
	import store from '@/store'
	export default {
		components: {
		},
		data() {
			return {
				globalData:App.globalData,
				language:languages
			}
		},
		onShow() {
			this.isLanguage()
		},
		methods: {
			getLanguageIcon(){
				return utils.languageIcon()
			},
			isLanguage(){
				var language = uni.getLocale() || "en";
				
				if (language == 'en-US' || language == '"en-US"') {
					language = 'en'
				} else if (language == 'zh-CN' || language == "'zh-CN'") {
					language = 'cn'
				} else if (language == 'zh-TW' || language == "'zh-TW'") {
					language = 'tw'
				}
				
				let index = this.language.findIndex((ele) => {
				    return ele.key === language;
				});
				this.language[index].checked= true
			},
			setLanguage(index) {
				for(var i in this.language){
					this.language[i].checked = false
				}
				this.language[index].checked = true
				this.$toast(this.$t('设置成功'))
				
				uni.setLocale(this.language[index].key);
				this.$i18n.locale = this.language[index].key;
				
				uni.navigateBack()
			},
			
			
		}
	}
</script>

<style lang="scss">
page{
	background-color: #FFFFFF;
}
</style>
