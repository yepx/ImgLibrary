<template>
	<view>
		<view class="a-p-3">
			<image class="a-w-690 a-h-300" mode="aspectFill" :src="globalData.imgUrl+'/images/bg-mine-recharge.png'"></image>
		</view>
		<view class="a-mx-3 a-bg-gray a-p-2">
			<text class="a-font a-text-gray a-text-center">{{$t('请如实填写实际转账金额，否则可能导致系统审核无法通过，影响充值进度')}}</text>
		</view>
		
		<view class="a-mx-3 a-pt-5">
			<view @click="$navTo('pages/customerService/index')" class="a-flex a-align-center a-justify-between a-mb-5">
				<view class="a-flex a-align-center">
					<image class="a-w-60 a-h-60" mode="aspectFill" :src="globalData.imgUrl+'/images/ico-usdt.png'"></image>
					<text class="a-font a-ml-2">USDT</text>
				</view>
				<text class="iconfonts icon-ai-arrow-down a-font a-text-gray"></text>
			</view>
			
			<view @click="$navTo('pages/customerService/index')" class="a-flex a-align-center a-justify-between a-mb-5">
				<view class="a-flex a-align-center">
					<image class="a-w-60 a-h-60" mode="aspectFill" :src="globalData.imgUrl+'/images/ico-btc.png'"></image>
					<text class="a-font a-ml-2">BTC</text>
				</view>
				<text class="iconfonts icon-ai-arrow-down a-font a-text-gray"></text>
			</view>
			
			<view @click="$navTo('pages/customerService/index')" class="a-flex a-align-center a-justify-between a-mb-5">
				<view class="a-flex a-align-center">
					<image class="a-w-60 a-h-60" mode="aspectFill" :src="globalData.imgUrl+'/images/ico-eth.png'"></image>
					<text class="a-font a-ml-2">ETH</text>
				</view>
				<text class="iconfonts icon-ai-arrow-down a-font a-text-gray"></text>
			</view>
			
			<view @click="$navTo('pages/customerService/index')" class="a-flex a-align-center a-justify-between a-mb-5">
				<view class="a-flex a-align-center">
					<image class="a-w-60 a-h-60" mode="aspectFill" :src="globalData.imgUrl+'/images/ico-bank.png'"></image>
					<text class="a-font a-ml-2">{{$t('银行卡')}}</text>
				</view>
				<text class="iconfonts icon-ai-arrow-down a-font a-text-gray"></text>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
			}
		},
		onShow() {
			
		},
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.$navTo(`pages/mine/rechargeRecord`)
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
</style>
