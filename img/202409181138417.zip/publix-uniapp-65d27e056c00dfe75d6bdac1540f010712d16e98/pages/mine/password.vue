<template>
	<view>
		<view class="a-p-3">
			
			<view v-if="isHave" class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{type==1?$t('旧密码'):$t('原资金密码')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" :type="oldShow?'text':'password'" v-model="form.old" :placeholder="type==1?$t('请输入密码'):$t('请输入6位数数字密码')" style="border:none;"/>
					<text @click="oldShow = !oldShow" class="iconfonts a-font a-text-gray" :class="oldShow?'icon-eye':'icon-eye-disable'"></text>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{type==1?$t('新密码'):isHave?$t('新资金密码'):$t('资金密码')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" :type="newShow?'text':'password'" v-model="form.new" :placeholder="type==1?$t('请输入密码'):$t('请输入6位数数字密码')" style="border:none;"/>
					<text @click="newShow = !newShow" class="iconfonts a-font a-text-gray" :class="newShow?'icon-eye':'icon-eye-disable'"></text>
				</view>
				<text v-if="type==1" class="a-font-sm a-text-gray">{{$t('请输入6-12个字符，包括数字或字母')}}</text>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{type==1?$t('确认新密码'):$t('再次输入资金密码')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" :type="reNewShow?'text':'password'" v-model="form.reNew" :placeholder="type==1?$t('请输入密码'):$t('请再次输入6位数数字密码')" style="border:none;"/>
					<text @click="reNewShow = !reNewShow" class="iconfonts a-font a-text-gray" :class="reNewShow?'icon-eye':'icon-eye-disable'"></text>
				</view>
				<text v-if="type==1" class="a-font-sm a-text-gray">{{$t('请输入6-12个字符，包括数字或字母')}}</text>
			</view>
			
			
			
			<view @click="onSubmit" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('确定')}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				type:1,
				isHave:false,
				oldShow:false,
				newShow:false,
				reNewShow:false,
				form:{
					old:'',
					new:'',
					reNew:'',
				}
			}
		},
		onLoad(options) {
			this.type = options.type
			this.isHave = parseInt(options.isHave)
		},
		methods: {
			onSubmit() {
				var that = this;
				if(!that.isHave){
					if(that.form.new != that.form.reNew){
						that.$toast('两次密码不一致！')
						return
					}
				}
				if(that.type==1){
					var params = {
						old_password:that.form.old,
						password:that.form.new,
						re_password:that.form.reNew,
					}
					var api = 'updateOldAndNewPsw'
				}else{
					if(that.isHave){
						var params = {
							old_safeword:that.form.old,
							safeword:that.form.new,
							re_safeword:that.form.reNew,
						}
						var api = 'updateOldAndNewSafeword'
					}else{
						var params = {
							safeword:that.form.new,
						}
						var api = 'setSafewordReg'
					}
					
				}
				Api[api](params).then(res => {
					if(res.code==0){
						that.$toast(that.$t('设置成功'))
						setTimeout(res=>{
							uni.navigateBack()
						},1000)
					}else{
						that.$toast(this.$t(res.msg))
					}
				});
			},
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
</style>
