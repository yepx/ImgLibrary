<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="a-bg-white">
			<view v-for="(item,index) in list.data" :key="index" @click="setNotificationRead(item)" class="a-p-3 a-border-top a-border-light">

				<view class="a-flex a-align-center a-justify-between">
					<view class="a-flex a-align-center a-flex-1">
						<view v-if="item.status ==1" class="a-w-15 a-h-15 a-bg-red a-rounded-circle a-mr-2"></view>
						<text class="a-font a-text-ellipsis-1 a-flex-1">{{item.title}}</text>
					</view>
					<text class="a-font-min a-text-gray">{{item.reserveSendTime}}</text>
				</view>
				<view class="a-flex a-align-center a-justify-between a-mt-2">
					<text class="a-font-sm a-text-ellipsis-2">{{item.content}}</text>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	export default {
		components: {
		  MescrollBody,
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData: App.globalData,
				isMP: false,
				isLogin: false,
				
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: false,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
			}
		},
		onShow() {
			this.onRefreshList()
		},
		methods: {
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				var count = app.list.data.length
				if(count){
					var index = count-1
					var location = app.list.data[index].location
				}else{
					var location = 0
				}
				// 设置列表数据
				app.getList(location).then(list => {
					const curPageLen = list.data.length
					const totalSize = list.count
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			
			// 获取订单列表
			getList(location) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
					  pageSize:pageSize,
					  lastLocation:location,
					  type:3,
					  status:0,
					  module:0
					};
					Api.notificationList(params).then(result =>{
						const newList = result.data
						
						newList.data = this.getElementsI18n(result.data)
						
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			setNotificationRead(object) {
				var that = this;
				if(object.status == 1){
					Api.notificationRead({ids:object.id}).then(res => {
						const {status,message,data} = res;
						// that.messageNumber = res.data.count
					});
				}
				that.$navTo('pages/mine/messageDetail?id='+object.id+'&time='+object.reserveSendTime)
			},
			getElementsI18n(list) {
			  list.forEach(item => {
			    // i18n支持通配符
			    let varInfo = JSON.parse(item.varInfo)
			    let varObj = {}
			    varInfo.forEach((item, index) => {
			      varObj[item.code] = item.value
			    })
			    switch (item.title) {
			      case 'One order finished':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Freeze seller because of violation':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'New Order':
			        item.content = this.$t(item.content)
			        break;
			      case 'Order overtime':
			        item.content = this.$t(item.content)
			        break;
			      case 'Buyer Consult from Customer Service':
			        item.content = this.$t(item.content)
			        break;
			      case 'Your Seller-Credit updated':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'UnFreeze seller':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Withdraw Success Notify':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Recharge Pass Notify':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Store certification passed':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Store authentication failed':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Order purchase overtime':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			    }
			    item.title = this.$t(item.title)
			  })
			  return list
			},
		}
	}
</script>

<style lang="scss">
</style>