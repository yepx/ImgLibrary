<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="a-px-3 a-py-3 a-bg-white a-mb-2">

			<view class="a-mb-3">
				<view class="a-mb-2">
					<text class="a-font">{{$t('邀请链接')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<view class="a-border a-bg-white a-flex-1 a-rounded-left a-h-80 a-flex a-align-center a-px-2 ">
						<text class="a-font">{{alliance.download}}</text>
					</view>
					<view @click.stop="copy(alliance.download)" class="a-h-80 a-w-150 a-rounded-right a-bg-primary a-flex a-align-center a-justify-center">
						<text class="a-font-sm a-text-white">{{$t('复制')}}</text>
					</view>
				</view>
			</view>

			<view class="">
				<view class="a-mb-2">
					<text class="a-font">{{$t('邀请码')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<view class="a-border a-bg-white a-flex-1 a-rounded-left a-h-80 a-flex a-align-center a-px-2 ">
						<text class="a-font">{{alliance.code}}</text>
					</view>
					<view @click.stop="copy(alliance.code)" class="a-h-80 a-w-150 a-rounded-right a-bg-primary a-flex a-align-center a-justify-center">
						<text class="a-font-sm a-text-white">{{$t('复制')}}</text>
					</view>
				</view>
			</view>

		</view>

		<view class="a-bg-white a-p-3 a-mb-2">
			<view>
				<text class="a-font-sm">
					{{$t('成为创业联盟会员后，您可以邀请好友通过您的邀请码进行注册。每当您的好友在我们平台上完成一笔订单，您就能获得相应的佣金奖励。根据您邀请的好友层数，您可以获得不同比例的分成。一级好友的商品销售利润将给您')}}
					<span class="a-text-primary">{{getFixedNone(alliance.promoRate1)}}%</span>
					{{$t('的分成，二级好友的商品销售利润将给您')}}
					<span class="a-text-primary">{{getFixedNone(alliance.promoRate2)}}%</span>
					{{$t('的分成，三级好友的商品销售利润将给您')}}
					<span class="a-text-primary">{{getFixedNone(alliance.promoRate3)}}%</span>
					{{$t('的分成。')}}
				</text>
			</view>
			<view class="a-mt-1">
				<text class="a-font-sm">
					{{$t('以下是分成计算公式：')}}
				</text>
			</view>
			<view class="a-mt-1">
				<text class="a-font-sm">
					{{$t('一级 好友分成计算公式：佣金 = 商品销售利润')}} x
					<span class="a-text-primary">{{getFixedNone(alliance.promoRate1)}}%</span>
				</text>
			</view>
			<view class="a-mt-1">
				<text class="a-font-sm">
					{{$t('二级 好友分成计算公式：佣金 = 商品销售利润')}} x
					<span class="a-text-primary">{{getFixedNone(alliance.promoRate2)}}%</span>
				</text>
			</view>
			<view class="a-mt-1">
				<text class="a-font-sm">
					{{$t('三级 好友分成计算公式：佣金 = 商品销售利润')}} x
					<span class="a-text-primary">{{getFixedNone(alliance.promoRate3)}}%</span>
				</text>
			</view>
			<view class="a-mt-1">
				<text class="a-font-sm">
					{{$t('我们提供详细的分成计算公式，以便您清晰了解佣金的计算方式。我们鼓励您了解平台的邀请制度规则，以便更好地管理和规划您的佣金收入。我们感谢您的参与，并期待与您共同发展。')}}
				</text>
			</view>
		</view>
		
		<view class="a-bg-white">
			<view class="autoFixed">
				<u-tabs ref="tabs" :list="tabs" :is-scroll="false" :current="curTab" bar-height="6" bar-width="40" active-color="#1552f0" inactive-color="" bg-color="#ffffff" @change="onChangeTab"></u-tabs>
			</view>
			<view>
				<view v-for="(item,index) in list.data" class="a-flex a-p-3 a-border-top a-border-light">
					<view>
						<image class="a-w-90 a-h-90 a-rounded-circle" :src="item.avatar"></image>
					</view>
					<view class="a-ml-2 a-flex-1">
						<text class="a-font a-text-gray">{{item.name}}</text>
						<view class="a-mt-2">
							<text class="a-font-sm">{{$t('收益')}}:</text>
							<FormatNumberShow class="a-font-sm" :data="item.income" :decimalPlaces="6"/>
						</view>
						<view class="a-flex a-align-center a-justify-between a-mt-1">
							<text class="a-font-sm">{{$t('订单')}}:{{item.orderCount}}</text>
							<text class="a-font-sm a-text-gray">{{$t('注册时间')}}：{{item.createTime}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
		</mescroll-body>
		
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData: App.globalData,
				isMP: false,
				isLogin: false,
				alliance:{},
				//
				tabs:[{
					name: this.$t('一级盟友'),
					value: 1
				}, {
					name: this.$t('二级盟友'),
					value: 2
				}, {
					name: this.$t('三级盟友'),
					value: 3
				}],
				// 当前标签索引
				curTab: 0,
				
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
			}
		},
		onLoad() {
			this.getAlliance()
		},
		methods: {
			getFixedNone(number){
				if(number){
					var numbers= number *100
					return numbers.toFixed(0)
				}else{
					return 0
				}
			},
			// 个人信息
			getAlliance() {
				const that = this
				Api.alliance().then(result =>{
					that.alliance = result.data
				})
			},
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			},
			// 切换标签项
			onChangeTab(index) {
				const that = this
				// 设置当前选中的标签
				that.curTab = index
				// 刷新订单列表
				that.onRefreshList()
			},
			// 获取当前标签项的值
			getTabValue() {
			  const that = this
			  return that.tabs.length ? that.tabs[that.curTab].value : ''
			},
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.data.length
					const totalSize = list.data.length
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						pageNo:pageNo,
						pageSize:pageSize,
						level:that.getTabValue(),
					};
					Api.allianceLevel(params).then(result =>{
						if(result.data){
							var newList = result
							newList.data = result.data
						}else{
							
							var newList = {}
							newList.data = []
						}
						
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
		}
	}
</script>

<style lang="scss">
</style>