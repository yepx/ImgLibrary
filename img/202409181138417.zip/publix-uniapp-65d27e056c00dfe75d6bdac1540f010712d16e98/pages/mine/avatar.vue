<template>
	<view>
		<view class="a-flex a-flex-wrap a-align-center a-mx-1-5">
			<view v-for="(item,index) in 21" :key="index" v-if="index" @click="changeAvatar(index)" class="a-w-180 a-h-180 a-flex a-align-center a-justify-center" >
				<view class="a-w-130 a-h-130 a-position-relative">
					<image class="a-w-130 a-h-130 a-rounded-circle" mode="aspectFill" :src="`/static/images/avatar/${index}.png`"></image>
					<view v-if="avatar == index" class="a-w-40 a-h-40 a-flex a-align-center a-justify-center a-bg-primary a-rounded-circle a-position-absolute a-right-0 a-bottom-0">
						<text class="iconfonts icon-dagou a-font-tiny a-text-white a-mt a-ml"></text>
					</view>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				avatar:null
			}
		},
		onLoad(options) {
			this.avatar = options.avatar
		},
		methods: {
			// 个人信息
			getUserInfo() {
				const that = this
				Api.info().then(result =>{
					that.userInfo = result.data
				})
			},
			getKycInfo() {
				var that = this;
				Api.kycInfo().then(res => {
					const {status,message,data} = res;
					that.kycInfo = res.data
				});
			},
			changeAvatar(index){
				this.avatar = index
				this.refreshAvatar()
			},
			refreshAvatar(index) {
				var that = this;
				Api.refreshAvatar({idx:this.avatar}).then(res => {
					const {status,message,data} = res;
					that.kycInfo = res.data
				});
			},
			
		}
	}
</script>

<style lang="scss">
page{
	background-color: #ffffff;
}
</style>
