<template>
	<view>
		<view class="a-mb-2 a-px-3 a-bg-white a-px-2 a-rounded">
			<view class="a-py-2 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('店铺LOGO')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<image @click="setImage" class="a-w-100 a-h-100 a-rounded-circle a-mr-2" mode="aspectFill" :src="form.avatar?form.avatar:globalData.imgUrl+'/default-avatar.png'"></image>
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('店铺名称')}}</text>
				</view>
				<view class="a-flex a-align-center a-w-450">
					<input class="a-font a-flex-1" v-model="form.name" :placeholder="$t('请输入')+$t('店铺名称')">
				</view>
			</view>
			<view class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('联系人')}}</text>
				</view>
				<view class="a-flex a-align-center a-w-450">
					<input class="a-font a-flex-1" v-model="form.contact" :placeholder="$t('请输入')+$t('联系人')">
				</view>
			</view>
			<view class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('店铺电话')}}</text>
				</view>
				<view class="a-flex a-align-center a-w-450">
					<input class="a-font a-flex-1" v-model="form.shopPhone" :placeholder="$t('请输入')+$t('店铺电话')">
				</view>
			</view>
			<view class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('店铺地址')}}</text>
				</view>
				<view class="a-flex a-align-center a-w-450">
					<input class="a-font a-flex-1" v-model="form.shopAddress" :placeholder="$t('请输入')+$t('店铺地址')">
				</view>
			</view>
		</view>
		
		<view class="a-mb-2 a-px-3 a-bg-white a-px-2 a-rounded">
			<view class="a-py-2 a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('店铺简介')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<textarea class="a-font a-flex-1 a-mt-2 a-h-200" v-model="form.shopRemark" :placeholder="$t('请输入')+$t('店铺简介')"></textarea>
				</view>
			</view>
		</view>
		
		<view class="a-mb-2 a-px-3 a-bg-white a-px-2 a-rounded">
			<view class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('进店欢迎语')}}</text>
				</view>
				<view class="a-flex a-align-center a-w-450">
					<input class="a-font a-flex-1" v-model="form.imInitMessage" :placeholder="$t('请输入')+$t('进店欢迎语')">
				</view>
			</view>
		</view>
		
		<view class="a-py-5 a-px-3">
			<view @click="onSubmit" class=" a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('保存')}}</text>
			</view>
		</view>
		<cropper ref="cropper" :aspectRatio="aspectRatio" @complete="complete" @cancel="cancel" ></cropper>
	</view>
	
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as UploadApi from '@/api/upload'
	import * as utils from "@/utils/util";
	import Cropper from '@/components/Cropper/cropper.vue';
	export default {
		components:{
			Cropper
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				sellerInfo:{},
				isShow:false,
				avatar:'',
				aspectRatio:1,
				form:{
					name:'',
					contact:'',
					shopPhone:'',
					shopAddress:'',
					shopRemark:'',
					imInitMessage:'',
					avatar:'',
				}
			}
		},
		onLoad() {
			this.getSellerInfo()
		},
		methods: {
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
					for(var i in that.sellerInfo){
					  for(var ii in that.form){
						if(ii==i){
							console.log(that.form[ii])
							console.log(that.sellerInfo[i])
							if (that.sellerInfo[i]=='null'){
								that.sellerInfo[i]=''
							}
							that.form[ii] = that.sellerInfo[i]
						}
					  }
					}
				});
			},
			setImage(){
			    uni.chooseImage({
			        count: 1, 
			        mediaType:['image'],
			        sourceType:['album', 'camera'],
			        success: function (res) {
						this.$refs.cropper.init(res.tempFilePaths[0]);
			        }.bind(this)
			    });
			},
			complete(object){
				var blob = this.dataURLtoBlob(object.path);
				var file = this.blobToFile(blob, 'shopAvatar',object.path);
				this.uploadImg([file])
				this.$refs.cropper.close();
			},
			cancel(){
				this.$refs.cropper.close();
			},
			//将base64转换为blob
			dataURLtoBlob(dataurl) { 
			    var arr = dataurl.split(','),
			    mime = arr[0].match(/:(.*?);/)[1],
			    bstr = atob(arr[1]),
			    n = bstr.length,
			    u8arr = new Uint8Array(n);
			    while (n--) {
			        u8arr[n] = bstr.charCodeAt(n);
			    }
			    return new Blob([u8arr], { type: mime });
			},
			//将blob转换为file
			blobToFile(theBlob, fileName,path){
			   theBlob.lastModifiedDate = new Date();
			   theBlob.name = fileName;
			   theBlob.path = path;
			   return theBlob;
			},
			uploadImg(array){
				UploadApi.image(array,'shopAvatar').then(result => {
					  this.form.avatar = result[0]
				  })
			},
			onSubmit() {
				var that = this;
				Api.sellerUpdate(that.form).then(res => {
					that.$toast(this.$t(res.msg))
				});
			},
		}
	}
</script>

<style>

</style>
