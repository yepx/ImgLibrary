<template>
	<view>
		<view class="a-p-3">
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">Facebook</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.facebook" :placeholder="$t('使用HTTP插入链接')"/>
				</view>
			</view>
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">Twitter</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.twitter" :placeholder="$t('使用HTTP插入链接')"/>
				</view>
			</view>
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">Google</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.google" :placeholder="$t('使用HTTP插入链接')"/>
				</view>
			</view>
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">YouTube</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.youtube" :placeholder="$t('使用HTTP插入链接')"/>
				</view>
			</view>
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font-sm">Instagram</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.instagram" :placeholder="$t('使用HTTP插入链接')"/>
				</view>
			</view>
			
			<view @click="onSubmit" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('保存')}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				sellerInfo:{},
				form:{
					facebook:'',
					instagram:'',
					twitter:'',
					google:'',
					youtube:'',
				}
			}
		},
		onLoad() {
			this.getSellerInfo()
		},
		methods: {
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
					for(var i in that.sellerInfo){
					  for(var ii in that.form){
						if(ii==i && that.sellerInfo[i] !='null'){
							console.log(that.sellerInfo[i])
							that.form[ii] = that.sellerInfo[i]
						}
					  }
					}
				});
			},
			onSubmit() {
				var that = this;
				Api.sellerUpdate(that.form).then(res => {
					that.$toast(this.$t(res.msg))
				});
			},
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
.item:after {
    content: "";
    position: absolute;
    width: 40px;
    height: 40px;
    bottom: -22px;
    right: -22px;
    background-color: #1552f0;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    z-index: 1;
}
</style>
