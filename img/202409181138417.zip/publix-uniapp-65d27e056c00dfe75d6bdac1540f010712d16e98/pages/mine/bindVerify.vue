<template>
	<view>
		<view class="a-p-3">
			
			<view v-if="type==1" class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{$t('手机号')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<view @click="openAreaCode" class="a-flex a-align-center a-mr-2">
						<text class="a-font  a-mr-1">+{{form.areaCode}}</text>
						<text class="iconfonts icon-ai-arrow-down a-font-sm a-transform-90"></text>
					</view>
					<input class="a-font a-flex-1" type="text" v-model="form.phone" :placeholder="$t('请输入')+$t('手机号')"/>
				</view>
			</view>
			<view v-if="type==2" class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{$t('邮箱')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.email" :placeholder="$t('请输入')+$t('邮箱')"/>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{$t('验证码')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" ype="text" v-model="form.verifcode" :placeholder="$t('请输入')+$t('验证码')"/>
					
					<view @click="handelSmsCaptcha" class="a-flex a-align-center a-justify-center a-ml-2">
						<text v-if="!smsState" class="a-font-sm a-text-primary">{{$t('发送验证码')}}</text>
						<text v-else class="a-font-sm a-text-primary">({{ times }}){{$t('秒')}}</text>
					</view>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{type==1?$t('确认新密码'):$t('再次输入资金密码')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" :type="isShow?'text':'password'" v-model="form.password" :placeholder="$t('请输入登录密码')" style="border:none;"/>
					<text @click="isShow = !isShow" class="iconfonts a-font a-text-gray" :class="isShow?'icon-eye':'icon-eye-disable'"></text>
				</view>
			</view>
			
			
			
			<view @click="onSubmit" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('确认')}}</text>
			</view>
		</view>
		
		<AREACODE ref="areaCode" :title="$t('选择区域码')" isMode="bottom" @setAreaCode="setAreaCode"></AREACODE>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import AREACODE from '@/components/areaCode'
	// 倒计时时长(秒)
	const times = 60
	export default {
		components: {
		  AREACODE,
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				type:1,
				isShow:false,
				isLoading:false,
				// 短信验证码发送状态
				smsState: false,
				// 倒计时
				times,
				form:{
					areaCode: uni.getStorageSync("areaCode")||1,
					phone:'',
					email:'',
					verifcode:'',
					password:'',
					verifyCode:''
					
				}
			}
		},
		onLoad(options) {
			this.type = options.type
			this.form.verifyCode = options.verifyCode
			if(this.type==1){
				uni.setNavigationBarTitle({
					title:this.$t('手机号绑定')
				})
			}else{
				uni.setNavigationBarTitle({
					title:this.$t('邮箱绑定')
				})
			}
		},
		methods: {
			openAreaCode() {
			    this.$refs.areaCode.open();
			},
			setAreaCode(number) {
			    this.form.areaCode = number
			    uni.setStorageSync("areaCode", this.form.areaCode)
			},
			// 点击发送短信验证码
			handelSmsCaptcha() {
			  const that = this
			  if (!that.isLoading && !that.smsState && that.type==1 && that.form.phone || !that.isLoading && !that.smsState && that.type==2  && that.form.email) {
			    that.sendSmsCaptcha()
			  }
			},
			// 请求发送短信验证码接口
			sendSmsCaptcha() {
			  const that = this
			  that.isLoading = true
			  if(that.type==1){
				  var params = {
						target: that.form.areaCode+' '+that.form.phone
					}
			  }else{
				  var params = {
						target: that.form.email
					}
			  }
			  Api.sendSmsCaptcha(params).then(result => {
			      // 显示发送成功
			      if(result.code == 0){
						// 执行定时器
						that.timer()
						that.$toast(this.$t('发送成功'))
					}else{
						that.$toast(this.$t(result.msg))
					}
			    })
			    .catch(() => {})
			    .finally(() => that.isLoading = false)
			},
			// 执行定时器
			timer() {
			  const that = this
			  that.smsState = true
			  const inter = setInterval(() => {
			    that.times = that.times - 1
			    if (that.times <= 0) {
			      that.smsState = false
			      that.times = times
			      clearInterval(inter)
			    }
			  }, 1000)
			},
			onSubmit() {
				var that = this;
				if(that.type==1){
					var params = {
						target:that.form.areaCode+' '+that.form.phone,
						phone:that.form.areaCode+' '+that.form.phone,
						verifcode:that.form.verifcode,
						password:that.form.password,
						verifyCode:that.form.verifyCode
					}
				}else{
					var params = {
						target:that.form.phone,
						email:that.form.phone,
						verifcode:that.form.verifcode,
						password:that.form.password,
						verifyCode:that.form.verifyCode
					}
				}
				Api.bindEmailOrPhone(params).then(res => {
					that.$toast(this.$t(res.msg))
					if(res.code==0){
						setTimeout(res=>{
							uni.navigateBack()
						},1000)
					}
				});
			},
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
</style>
