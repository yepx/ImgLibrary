<template>
	<view style="min-height:100vh">
		<image class="a-full-fixed" src="/static/images/bg-invite.png"></image>
		<view class="transitionBackgroundColor a-position-relative" style="z-index:999">
			<view class="a-w-750" :style="'height:'+globalData.statusBar+'px;'"></view>
			<view class="a-mx-4 a-flex a-align-center a-justify-between" :style="[{height:globalData.navbar+'px',paddingRight: isMP ? globalData.capsuleWidth+'px' :'0px'}]">
				<view @click="back" class="a-flex">
					<text class="iconfonts icon-ai-arrow-down a-transform-180 a-font a-text-white"></text>
				</view>
			</view>
		</view>
		
		<view class="a-position-relative" style="z-index:999">
			<view class="a-py-5 a-px-10">
				<view>
					<text class="a-font-max-three a-text-white a-mr-1">{{$t('邀请好友')}}</text>
					<text class="a-font-max-three a-text-yellow">{{$t('得现金')}}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm a-text-white a-mr-1">{{$t('邀请好友瓜分')}}</text>
					<text class="a-font-sm a-text-white">$100,000</text>
				</view>
			</view>
			
			<view class="a-w-690 a-mx-3 a-rounded a-p-4" style="background-color: #e2eaff;">
				<view class="a-flex a-align-center a-justify-between">
					<view class="a-flex-1 a-flex-column a-align-end">
						<view class="a-w-20 a-h-5 a-bg-primary "></view>
						<view class="a-w-20 a-h-5 a-bg-primary a-my a-mr"></view>
						<view class="a-w-20 a-h-5 a-bg-primary a-ml"></view>
					</view>
					<text class="a-font-lg a-text-primary a-font-weight-bold a-mx-3">{{$t("活动规则")}}</text>
					<view class="a-flex-column a-align-start a-flex-1">
						<view class="a-w-20 a-h-5 a-bg-primary "></view>
						<view class="a-w-20 a-h-5 a-bg-primary a-my a-ml"></view>
						<view class="a-w-20 a-h-5 a-bg-primary "></view>
					</view>
				</view>
				<view class="a-mt-3">
					<text class="a-font-sm">{{$t('活动期间，你每成功邀请一个新用户注册并激活店铺都将得到奖金,达到邀请人数之后奖金提升如下：')}}</text>
				</view>
				<view class="a-mt-2">
					<view class="a-rounded-top-2 a-flex a-align-center" style="background-color:#c3d4ff;">
						<view class="a-flex-1 a-py-1 a-border-right a-border-white a-flex a-align-center a-justify-center">
							<text class="a-font">{{$t('邀请人数')}}</text>
						</view>
						<view class="a-flex-1 a-py-1 a-flex a-align-center a-justify-center">
							<text class="a-font">{{$t('每人奖励')}}</text>
						</view>
					</view>
					
					<view 
					 v-for="(item,index) in d1" :key="index"
					class="a-flex a-align-center transparency-white-4 a-border-bottom a-border-white">
						<view class="a-flex-1 a-py-1 a-border-right a-border-white a-flex a-align-center a-justify-center">
							<text class="a-font a-font-weight-bold">{{item[1]}}{{ getNextArray(index) }} </text>
						</view>
						<view class="a-flex-1 a-py-1 a-flex a-align-center a-justify-center">
							<text class="a-font a-font-weight-bold a-text-primary">${{item[0]}}</text>
						</view>
					</view>
					
				</view>
				<view class="a-mt-3">
					<text class="a-font-sm">{{$t('邀请越多，奖励越多，先到先得，数量有限！')}}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm">{{$t('好友开店首次充值金额满足≥')}}</text>
					<FormatNumberShow class="a-font-sm" :data="sellerInfo.rechargeBonus" :currency="true"/>
				</view>
			</view>
			
			<view class="a-w-690 a-mx-3 a-rounded a-p-4 a-mt-3" style="background-color: #e2eaff;">
				<view class="a-flex a-align-center a-justify-between">
					<view class="a-flex-1 a-flex-column a-align-end">
						<view class="a-w-20 a-h-5 a-bg-primary "></view>
						<view class="a-w-20 a-h-5 a-bg-primary a-my a-mr"></view>
						<view class="a-w-20 a-h-5 a-bg-primary a-ml"></view>
					</view>
					<text class="a-font-lg a-text-primary a-font-weight-bold a-mx-3">{{$t("我的邀请记录")}}</text>
					<view class="a-flex-column a-align-start a-flex-1">
						<view class="a-w-20 a-h-5 a-bg-primary "></view>
						<view class="a-w-20 a-h-5 a-bg-primary a-my a-ml"></view>
						<view class="a-w-20 a-h-5 a-bg-primary "></view>
					</view>
				</view>
				<view class="a-mt-2">
					<view class="a-rounded-top-2 a-flex a-align-center" >
						<view class="a-flex-1 a-py-1 a-flex-column a-align-center a-justify-center">
							<text class="a-font-max-four a-font-weight-bold a-text-primary">{{sellerInfo.inviteNum?sellerInfo.inviteNum:0}}</text>
							<text class="a-font">{{$t('成功邀请(人)')}}</text>
						</view>
						<view class="a-h-60 a-w-1" style="background-color:#c3d4ff;"></view>
						<view class="a-flex-1 a-py-1 a-flex-column a-align-center a-justify-center">
							<FormatNumberShow class="a-font-max-four a-font-weight-bold a-text-primary" :data="sellerInfo.inviteReceivedReward" />
							<text class="a-font">{{$t('累计返现($)')}}</text>
						</view>
					</view>
					<view class="a-flex a-align-center a-mt-2">
						<view class="a-border a-bg-white a-flex-1 a-rounded-left a-h-80 a-flex a-align-center a-px-2 a-text-break">
							<text class="a-font-sm">{{globalData.apiUrl}}promote/#/?usercode={{usercode}}</text>
						</view>
						<view @click.stop="copy(globalData.apiUrl+'promote/#/?usercode='+usercode)" class="a-h-80 a-w-150 a-rounded-right a-bg-primary a-flex a-align-center a-justify-center">
							<text class="a-font-sm a-text-white">{{$t('复制')}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				sellerInfo:{},
				alliance:{},
				usercode:0,
				d1:"",
			}
		},
		onLoad(options) {
			this.usercode = options.usercode
			console.log(options.d1)
			let str = "[" + options.d1 + "]";

			this.d1= JSON.parse(str);
			console.log(this.d1)
			this.getSellerInfo()
		},
		methods: {
			 convertIndices(indicesString) {
			      // 将字符串转换为数组
			      const indicesArray = JSON.parse('[' + indicesString.replace(/(\d+)/g, '"$1"') + ']');
			      // 使用map函数和findIndex获取每个索引对应的元素
			      return indicesArray.map(indices => this.dataArray[indices[0]]);
			    },
			back(){
				uni.navigateBack()
			},
			 getNextArray(index) {
			      // Check if the next array exists
			      if (index + 1 < this.d1.length) {
			        // Return the next array
					let s=this.d1[index + 1][1]-1
			        return "-"+s ;
			      } else {
			        // Return an empty array or handle as per your requirement
			        return '';
			      }
			    },
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
				});
			},
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			},
			
		}
	}
</script>

<style lang="scss">
page{
	background-color: #ffffff;
}
</style>
