<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="a-p-3">
			<view v-for="(item,index) in list.data" :key="index" @click="$navTo('pages/mine/withdrawDetail?id='+item.order_no)" class="a-bg-white a-rounded a-mb-3 a-px-3">
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('购买套餐')}}</text>
					<text class="a-font">{{item.name}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('购买时间')}}</text>
					<text class="a-font">{{item.startTime}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('到期时间')}}</text>
					<text class="a-font">{{item.stopTime}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('付款方式')}}</text>
					<text class="a-font">{{$t('钱包余额')}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('付款金额')}}</text>
					<FormatNumberShow class="a-font a-text-primary" :data="item.prize" :currency="true"/>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 10
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
			}
		},
		onShow() {
			
		},
		methods: {
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						page_no:pageNo,
						pageSize:pageSize,
					};
					Api.promotionalRecord(params).then(result =>{
						const newList = result.data
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			}
		}
	}
</script>

<style>

</style>
