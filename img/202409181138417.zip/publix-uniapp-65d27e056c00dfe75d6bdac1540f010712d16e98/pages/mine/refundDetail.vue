<template>
	<view>
		<view class="a-p-3">
			<view class="a-bg-white a-rounded a-mb-3 a-px-3">
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('申请时间')}}</text>
					<text class="a-font">{{detailInfo.refundTime}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款单号')}}</text>
					<view>
						<text class="a-font">{{detailInfo.id}}</text>
						<text @click.stop="copy(detailInfo.id)" class="iconfonts icon-fuzhi1 a-font-lg a-text-gray a-ml-1"></text>
					</view>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款金额')}}</text>
					<FormatNumberShow class="a-font" :data="detailInfo.returnPrice" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款状态')}}</text>
					<text class="a-font" v-if="detailInfo.returnStatus == '0'">{{ $t('未退款') }}</text>
					<text class="a-font a-text-orange" v-if="detailInfo.returnStatus == '1'">{{ $t('退款中') }}</text>
					<text class="a-font a-text-green" v-if="detailInfo.returnStatus == '2'">{{ $t('成功') }}</text>
					<text class="a-font a-text-red" v-if="detailInfo.returnStatus == '3'">{{ $t('失败') }}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款理由')}}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '1'">{{ $t('未收到货') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '2'">{{ $t('不喜欢、不想要') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '3'">{{ $t('卖家发错货') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '4'">{{ $t('假冒品牌') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '5'">{{ $t('少发、漏发') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '6'">{{ $t('收到商品破损') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '7'">{{ $t('存在质量问题') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '8'">{{ $t('与商家协商一致退款') }}</text>
					<text class="a-font" v-if="detailInfo.returnReason == '9'">{{ $t('其他原因') }}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款说明')}}</text>
					<text class="a-font">{{detailInfo.returnDetail?detailInfo.returnDetail:'--'}}</text>
				</view>
			</view>
			<view v-for="(item,index) in detailGoods" :key="index" class="a-bg-white a-rounded a-p-3 a-flex a-align-center a-mb-3">
				<view class="a-mr-2">
					<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="item.goodsIcon"></image>
				</view>
				<view class="a-flex-column a-justify-between">
					<view class="a-flex a-justify-between">
						<text class="a-font-lg a-font-weight-bold a-text-ellipsis-3">{{item.goodsName}}</text>
					</view>
					<view class='a-flex a-align-center a-justify-between a-mt-1'>
						<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.systemPrice" :currency="true"/>
						<text class="a-font a-text-primary">x{{item.goodsNum}}</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				detailInfo:{},
				detailGoods:[],
				
			}
		},
		onLoad(options) {
			this.getOrderDetailGoods(options.id)
			this.getOrderDetailInfo(options.id)
		},
		methods: {
			getOrderDetailInfo(id) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						orderId:id
					};
					Api.orderRefundDetail(params).then(result =>{
						this.detailInfo = result.data
					})
				})
			},
			getOrderDetailGoods(id) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						orderId:id
					};
					Api.orderDetailGoods(params).then(result =>{
						this.detailGoods = result.data.pageList
					})
				})
			},
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			}
		}
	}
</script>

<style>

</style>
