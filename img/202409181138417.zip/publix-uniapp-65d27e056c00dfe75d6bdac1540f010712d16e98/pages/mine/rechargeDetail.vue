<template>
	<view>
		<view class="a-p-3">
			<view class="a-bg-white a-rounded a-mb-3 a-px-3">
				<view class="a-h-100 a-border-bottom a-border-light a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('订单号')}}</text>
					<view>
						<text class="a-font">{{detail.order_no}}</text>
						<text @click.stop="copy(detail.order_no)" class="iconfonts icon-fuzhi1 a-font-lg a-text-gray a-ml-1"></text>
					</view>
				</view>
				<view class="a-h-100 a-border-bottom a-border-light a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('创建时间')}}</text>
					<text class="a-font">{{detail.create_time}}</text>
				</view>
				<view class="a-h-100 a-border-bottom a-border-light a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('充值数量')}}</text>
					<view class="a-flex a-align-center">
						<FormatNumberShow class="a-font a-text-primary" :data="detail.amount" :decimalPlaces="6"/>
						<text class="a-font a-text-primary a-ml">USD</text>
					</view>
				</view>
				<view class="a-h-100 a-border-bottom a-border-light a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('实际到账')}}</text>
					<view v-if="detail.state" class="a-flex a-algin-center">
						<FormatNumberShow class="a-font a-text-primary" :data="(detail.amount - detail.fee)" :decimalPlaces="6"/>
						<text class="a-font a-text-primary a-ml">USD</text>
					</view>
					<text v-else class="a-font">--</text>
				</view>
				<view class="a-h-100 a-border-bottom a-border-light a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('订单状态')}}</text>
					<text class="a-font" :class="detail.state==1?'a-text-green':detail.state==2?'a-text-red':'a-text-primary'">{{detail.state==1?$t('成功'):detail.state==2?$t('失败'):$t('审核中')}}</text>
				</view>
				<view v-if="false" class="a-h-100 a-border-bottom a-border-light a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('币种协议')}}</text>
					<text class="a-font">{{detail.coin_blockchain?detail.coin_blockchain:'--'}}</text>
				</view>
				<view class="a-border-bottom a-border-light a-flex a-align-center a-justify-between" style="min-height:100rpx;">
					<text class="a-font a-text-gray">{{$t('收款地址')}}</text>
					<view class="a-flex-1 a-flex a-align-center a-justify-end">
						<text class="a-font a-flex-1 a-text-break a-ml-2 a-text-right">{{detail.channel_address?detail.channel_address:'--'}}</text>
						<text @click.stop="copy(detail.channel_address)" class="iconfonts icon-fuzhi1 a-font-lg a-text-gray a-ml-1"></text>
					</view>
				</view>
				<view class="a-border-bottom a-border-light a-flex a-align-center a-justify-between" style="min-height:100rpx;">
					<text class="a-font a-text-gray">{{$t('支付凭证')}}</text>
					<image v-if="detail.img" @click="previewImage(detail.img)" class="a-w-160 a-h-160 a-my-2 a-rounded" mode="aspectFill" :src="detail.img"></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				detail:{}
				
			}
		},
		onLoad(options) {
			this.getDetail(options.id)
			
		},
		methods: {
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			},
			previewImage(image){
				uni.previewImage({
					urls: [image],
					longPressActions: {
						// itemList: ['发送给朋友', '保存图片', '收藏'],
						success: function(data) {
							console.log('选中了第' + (data.tapIndex + 1) + '个按钮,第' + (data.index + 1) + '张图片');
						},
						fail: function(err) {
							console.log(err.errMsg);
						}
					}
				});
			},
			feeFunc(a, b) {
			  return this.$bigDecimal.subtract(a, b)
			},
			// 获取订单列表
			getDetail(id) {
				const that = this
				Api.rechargeDetail({order_no:id}).then(result =>{
					that.detail = result.data
				})
			},
		}
	}
</script>

<style>

</style>
