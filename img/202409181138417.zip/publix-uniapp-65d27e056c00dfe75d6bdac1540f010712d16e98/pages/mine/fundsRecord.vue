<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="">
			<view v-for="(item,index) in list.data" :key="index" class="a-flex a-align-center a-justify-between">
				<view class="a-flex a-align-center a-justify-center a-mx-3">
					<text class="iconfonts icon-fanhui a-text-red a-font-max-two" :class="item.amount > 0?'a-transform-315 a-text-green':'a-transform-135 a-text-red'"></text>
				</view>
				<view class="a-flex-1 a-pr-3 a-flex a-align-center a-justify-between a-border-bottom a-border-light a-py-2">
					<view class="a-flex-column">
						<view class="a-flex a-align-center">
							<text class="a-font">{{getOrderType(item.content_type)}}</text>
							<!-- <text class="iconfonts icon-wenhao-yuankuang a-font a-ml-1"></text> -->
						</view>
						<text class="a-font-sm a-text-gray a-mt-1">{{item.createTimeStr}}</text>
					</view>
					<view v-if="item.amount > 0">
						<text class="a-font a-text-green a-mr">+</text>
						<FormatNumberShow  class="a-font a-text-green" :data="item.amount" :currency="true"/>
					</view>
					<view v-else>
						<text class="a-font a-text-red a-mr">-</text>
						<FormatNumberShow class="a-font a-text-red" :data="(item.amount+'').replace('-', '')" :currency="true"/>
					</view>
				</view>
			</view>
		</view>
		</mescroll-body>
		
		<u-popup v-model="popupOptions" mode="bottom" closeable height="80%">
			<view class="a-bg-white a-flex-column a-w-750">
				<view class="a-flex a-align-center a-justify-center a-py-3 ">
					<text class="a-font-lg">{{$t('筛选信息')}}</text>
				</view>
				<view v-for="(item,index) in orderOptions" :key="index" @click="onChangeTab(index)" class="a-h-100 a-flex a-align-center a-justify-between a-border-top a-border-light">
					<view class="a-flex-1"></view>
					<text class="a-font">{{item.label}}</text>
					<view class="a-flex-1 a-flex a-justify-end">
						<text v-if="orderOptionsActive == index" class="iconfonts icon-dagou a-font-tiny a-text-primary a-mr-2"></text>
					</view>
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				popupOptions:false,
				orderOptions: [
				  {
				    label: this.$t('全部'),
				    value: "",
				  },
				  {
				    label: this.$t('充值订单'),
				    value: "recharge",
				  },
				  {
				    label: this.$t('提现订单'),
				    value: "withdraw",
				  },
				  {
				    label: this.$t('推广佣金'),
				    value: "brokerage",
				  },
				  {
				    label: this.$t('商品退款'),
				    value: "return-order-seller",
				  },
				  {
				    label: this.$t('商品采购'),
				    value: "push-order",
				  },
				  {
				    label: this.$t('购买直通车'),
				    value: "combo-order",
				  },
				  {
				    label: this.$t('冻结余额'),
				    value: "freeze_seller_money",
				  },
				  {
				    label: this.$t('解冻余额'),
				    value: "unfreeze_seller_money",
				  },
				  {
				    label: this.$t('订单收入'),
				    value: "order-income",
				  },
				  {
				    label: this.$t('支付订单'),
				    value: "pay-order",
				  },
				  {
				    label: this.$t('会员退货'),
				    value: "return-order-user",
				  },
				  {
				    label: this.$t('活动赠送'),
				    value: "first-recharge-bonus",
				  },
				  {
				    label: this.$t("升级礼金"),
				    value: "mall_level_upgrade_award",
				  },
				  {
				    label: this.$t("赠送彩金"),
				    value: "jackpot",
				  },
				  {
				    label: this.$t("邀请奖励"),
				    value: "invitation-rewards",
				  },
				],
				// 当前标签索引
				orderOptionsActive: 0,
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
				
			}
		},
		onShow() {
			
		},
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.popupOptions = true
			}
		},
		methods: {
			onChangeTab(index) {
				const that = this
				// 设置当前选中的标签
				that.orderOptionsActive = index
				that.popupOptions = false
				// 刷新订单列表
				that.onRefreshList()
			},
			// 获取当前标签项的值
			getTabValue() {
			  const that = this
			  return that.orderOptions.length ? that.orderOptions[that.orderOptionsActive].value : ''
			},
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.data.length
					const totalSize = list.data.length
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						page_no:pageNo,
						pageSize:pageSize,
						content_type:that.getTabValue(),
					};
					Api.fundsRecord(params).then(result =>{
						const newList = result.data
						
						
						let arr = [];
						result.data?.forEach(item => {
						  if (this.orderOptions.find(res => res.value === item.content_type)) {
						    arr.push(item)
						  }
						})
						newList.data = arr
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			getOrderType(type) {
			  return this.orderOptions.find(item => item.value === type)?.label
			},
			
		}
	}
</script>

<style lang="scss">
page {
	background-color:#ffffff;
}
</style>
