<template>
	<view>
		<view class="a-p-3">
			<view class="a-h-90 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter a-mb-4">
				<view class="a-flex a-align-center">
					<text class="a-font">{{$t('身份认证')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts a-font-lg a-mr-1" :class="kycInfo.status==1?'icon-shenhezhong2 a-text-orange':kycInfo.status==2?'icon-dagou1 a-text-green':'icon-guanbixiao a-text-red'"></text>
					<text class="a-font-sm a-text-gray a-mr-1">{{kycInfo.status==1?$t('审核中'):kycInfo.status==2?$t('已认证'):kycInfo.status==3?$t('审核失败'):$t('未认证')}}</text>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('国籍')}}</text>
				</view>
				
				<view @click="openCountry" class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<text class="a-font a-flex-1">{{form.nationality?country:$t('国籍')}}</text>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('真实姓名')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.name" :placeholder="$t('真实姓名')" :disabled="kycInfo.status==1 || kycInfo.status==2"/>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('证件/护照号码')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.idnumber" :placeholder="$t('证件/护照号码')" :disabled="kycInfo.status==1 || kycInfo.status==2"/>
				</view>
			</view>
			<view class="a-mb-4">
				<view class="a-flex a-align-center a-justify-between a-mx-1">
					<view class="a-w-200 a-h-130 a-position-relative a-bg-gray">
						<image v-if="form.idimg_1" class="a-w-200 a-h-130" :class="kycInfo.status==1?'a-opacity-5':''" mode="aspectFill" :src="form.idimg_1"></image>
						<view v-else @click="addImage('idimg_1')" class="a-w-200 a-h-130 a-flex a-align-center a-justify-center">
							<text class="iconfonts icon-xiangji a-font-max a-text-gray-light"></text>
						</view>
						<text v-if="form.idimg_1 && kycInfo.status!=1 && kycInfo.status!=2" @click="deleteImage('idimg_1')" class="iconfonts icon-guanbixiao a-font a-position-absolute a-top-0 a-right-0"></text>
					</view>
					<view class="a-w-200 a-h-130 a-position-relative a-bg-gray">
						<image v-if="form.idimg_2" class="a-w-200 a-h-130" :class="kycInfo.status==1?'a-opacity-5':''" mode="aspectFill" :src="form.idimg_2"></image>
						<view v-else @click="addImage('idimg_2')" class="a-w-200 a-h-130 a-flex a-align-center a-justify-center">
							<text class="iconfonts icon-xiangji a-font-max a-text-gray-light"></text>
						</view>
						<text v-if="form.idimg_2 && kycInfo.status!=1 && kycInfo.status!=2" @click="deleteImage('idimg_2')" class="iconfonts icon-guanbixiao a-font a-position-absolute a-top-0 a-right-0"></text>
					</view>
					<view class="a-w-200 a-h-130 a-position-relative a-bg-gray" >
						<image v-if="form.idimg_3" class="a-w-200 a-h-130" :class="kycInfo.status==1?'a-opacity-5':''" mode="aspectFill" :src="form.idimg_3"></image>
						<view v-else @click="addImage('idimg_3')" class="a-w-200 a-h-130 a-flex a-align-center a-justify-center">
							<text class="iconfonts icon-xiangji a-font-max a-text-gray-light"></text>
						</view>
						<text v-if="form.idimg_3 && kycInfo.status!=1 && kycInfo.status!=2" @click="deleteImage('idimg_3')" class="iconfonts icon-guanbixiao a-font a-position-absolute a-top-0 a-right-0"></text>
					</view>
					
				</view>
			</view>
			<view v-if="kycInfo.status!=1 && kycInfo.status!=2" class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{$t('拍照示例')}}</text>
				</view>
				<view class="a-flex a-align-center a-justify-between a-mx-1">
					<image class="a-w-200 a-h-130" :src="globalData.imgUrl+'/images/auth/01.png'"></image>
					<image class="a-w-200 a-h-130" :src="globalData.imgUrl+'/images/auth/02.png'"></image>
					<image v-if="false" class="a-w-200 a-h-130" :src="globalData.imgUrl+'/images/auth/03.png'"></image>
				</view>
			</view>
			
			<view v-if="kycInfo.status!=1 && kycInfo.status!=2" @click="onSubmit" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('认证')}}</text>
			</view>
		</view>
		
		<COUNTRY ref="Country" :title="$t('请选择国家')" :isCode="form.nationality" isMode="bottom" @setCountry="setCountry"></COUNTRY>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as UploadApi from '@/api/upload'
	import * as utils from "@/utils/util";
	import COUNTRY from '@/components/country'
	export default {
		components: {
		  COUNTRY,
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				kycInfo:{},
				country:'',
				form:{
					nationality:'',
					idname:'',
					name:'',
					idnumber:'',
					idimg_1:'',
					idimg_2:'',
					idimg_3:'',
				}
			}
		},
		onShow() {
			this.getKycInfo()
		},
		methods: {
			getKycInfo() {
				var that = this;
				Api.kycInfo().then(res => {
					const {status,message,data} = res;
					
					
					
					that.kycInfo = res.data
					that.kycInfo.idname= res.data.idname|| "id/passpost"
					for(var i in that.kycInfo){
					  for(var ii in that.form){
						if(ii==i){
							that.form[ii] = that.kycInfo[i]
						}
					  }
					}
					
					if(that.form.nationality){
						this.getCountry()
					}
					
				});
			},
			getCountry() {
				var that = this;
				Api.country().then(res => {
					const {status,message,data} = res;
					var country = res.data.data
					let index = country.findIndex((ele) => {
					    return ele.id === that.form.nationality;
					});
					that.country = country[index].countryName
				});
			},
			openCountry() {
				if(this.kycInfo.status==1||this.kycInfo.status==2){
					return
				}
			    this.$refs.Country.open();
			},
			setCountry(object) {
			    this.country = object.countryName
			    this.form.nationality = object.id
			},
			addImage(type){
			    uni.chooseImage({
			        count: 1, 
			        mediaType:['image'],
			        sourceType:['album', 'camera'],
			        success: function (res) {
						var array  = res.tempFiles;
						this.uploadImg(array,type);
			        }.bind(this)
			    });
			},
			uploadImg(array,type){
				UploadApi.image(array,type).then(result => {
					  this.form[type] = result[0]
				  })
			},
			deleteImage(type){
				this.form[type] = ''
			},
			onSubmit() {
				var that = this;
				console.log(that.form)
				if (that.form.idname==''){
					that.form.idname=that.kycInfo.idname
				}
				
				
				Api.kycApply(that.form).then(res => {
					that.$toast(this.$t(res.msg))
					if(res.code==0){
						setTimeout(res=>{
							uni.navigateBack()
						},1000)
					}
				});
			},
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
</style>
