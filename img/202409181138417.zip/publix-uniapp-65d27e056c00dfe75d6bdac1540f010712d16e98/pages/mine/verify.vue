<template>
	<view>
		<view class="a-p-3">
			<view class="a-flex-column a-mb-4">
				<text v-if="verType" class="a-font-max">{{verType==1?$t('手机验证'):$t('邮箱验证')}}</text>
				<text class="a-font a-mt-1">{{$t('为了保障您的账号安全，请验证后进行下一步操作')}}</text>
			</view>
			<view v-if="verType" class="a-flex-column a-mb-4">
				<text class="a-font">{{verType==1?$t('当前绑定手机'):$t('当前绑定邮箱')}}</text>
				<text class="a-font-max a-font-weight-bold a-mt-1">{{verType==1?getPhone(userInfo.phone):getEmail(userInfo.email)}}</text>
			</view>
			
			<view v-else class="a-flex-column a-mb-4">
				<text class="a-font">{{type==1?$t('当前绑定手机'):$t('当前绑定邮箱')}}</text>
				<text class="a-font-max a-font-weight-bold a-mt-1">{{type==1?getPhone(userInfo.phone):getEmail(userInfo.email)}}</text>
			</view>
			
			<view class="a-mb-4">
				<view class="a-flex a-align-center">
					<view class="a-border a-bg-white a-flex-1 a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1" type="text" v-model="form.verifcode" :placeholder="$t('验证码')"/>
					</view>
					<view @click="handelSmsCaptcha" class="a-h-90 a-w-250 a-rounded a-bg-primary a-flex a-align-center a-justify-center a-ml-2">
						<text v-if="!smsState" class="a-font-sm a-text-white">{{$t('发送验证码')}}</text>
						<text v-else class="a-font-sm a-text-white">({{ times }}){{$t('秒')}}</text>
					</view>
				</view>
				<view v-if="type==1" @click="changeVerType" class="a-flex a-align-center a-justify-end a-mt-2">
					<text class="iconfonts icon-qiehuan a-text-primary"></text>
					<text class="a-font a-text-primary">{{$t('切换为')}}{{verType==1?$t('邮箱验证'):$t('手机验证')}}</text>
				</view>
			</view>
			
		</view>
		
		<view class="a-w-750 a-h-120"></view>
		<view class="a-w-750 safeHeight"></view>
		<view class="a-position-fixed a-bottom-0 safePadding">
			<view class="a-w-750 a-h-120 a-flex a-align-center a-justify-center">
				<view v-if="verType" @click="onNext" class="a-mx-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
					<text class="a-font-lg a-text-white">{{$t('下一步')}}</text>
				</view>
				<view v-else @click="onSubmit" class="a-mx-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
					<text class="a-font-lg a-text-white">{{$t('确认')}}</text>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	// 倒计时时长(秒)
	const times = 60
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				userInfo:{},
				
				isLoading:false,
				// 短信验证码发送状态
				smsState: false,
				// 倒计时
				times,
				verType:0,
				form:{
					verifcode:''
				}
			}
		},
		onLoad(options) {
			this.type = options.type
			this.getUserInfo()
		},
		methods: {
			getEmail(email){
				if(email){
					return utils.emailHide(email)
				}else{
					return ''
				}
				
			},
			getPhone(phone){
				if(phone){
					return utils.phoneHide(email)
				}else{
					return ''
				}
				
			},
			// 个人信息
			getUserInfo() {
				const that = this
				Api.info().then(result =>{
					that.userInfo = result.data
					if(this.type==1){
						if(that.userInfo.email){
							this.verType = 2 
						}else if(that.userInfo.phone){
							this.verType = 1
						}
					}else if(this.type==2 && !that.userInfo.email){
						if(that.userInfo.phone){
							this.verType = 1 
						}else if(that.userInfo.email){
							this.verType = 2
						}
					}
					
				})
			},
			changeVerType(){
				if(this.verType==1 && this.userInfo.email){
					this.verType = 2 
				}else if(this.verType==2 && this.userInfo.phone){
					this.verType = 1
				}else{
					if(this.verType==1){
						this.$toast(this.$t('暂未绑定邮箱，无法进行邮箱验证'))
					}else{
						this.$toast(this.$t('暂未绑定手机号，无法进行手机验证'))
					}
				}
			},
			// 点击发送短信验证码
			handelSmsCaptcha() {
			  const that = this
			  if (!that.isLoading && !that.smsState && that.type==1 || !that.isLoading && !that.smsState && that.type==2) {
			    that.sendSmsCaptcha()
			  }
			},
			// 请求发送短信验证码接口
			sendSmsCaptcha() {
			  const that = this
			  that.isLoading = true
			  
			  if(that.verType==1){
				  var params = {
						target: that.userInfo.phone
					}
			  }else if(that.verType==2){
				  var params = {
						target: that.userInfo.email
					}
			  }else if(that.type==1){
				  var params = {
						target: that.userInfo.phone
					}
			  }else if(that.type==2){
				  var params = {
						target: that.userInfo.email
					}
			  }
			  Api.sendSmsCaptcha(params).then(result => {
			      // 显示发送成功
			      if(result.code == 0){
						// 执行定时器
						that.timer()
						that.$toast(this.$t('发送成功'))
					}else{
						that.$toast(this.$t("验证码不正确"))
					}
			    })
			    .catch(() => {})
			    .finally(() => that.isLoading = false)
			},
			// 执行定时器
			timer() {
			  const that = this
			  that.smsState = true
			  const inter = setInterval(() => {
			    that.times = that.times - 1
			    if (that.times <= 0) {
			      that.smsState = false
			      that.times = times
			      clearInterval(inter)
			    }
			  }, 1000)
			},
			//下一步
			onNext() {
				
				const that = this
				if(that.verType==1){
					var params = {
						target:that.userInfo.phone,
						verifcode:that.form.verifcode,
						phone:that.userInfo.phone
					}
				}else{
					var params = {
						target:that.userInfo.email,
						verifcode:that.form.verifcode,
						email:that.userInfo.email
					}
				}
				
				Api.beforeBind(params).then(result =>{
					if(result.code==0){
						this.$navTo('pages/mine/bindVerify?type='+that.type+'&verifyCode='+result.data.verifyCode)
					}else{
						that.$toast(this.$t('验证码不正确'))
					}
				})
				
			},
			// 提交验证
			onSubmit() {
				const that = this
				if(that.type==1){
					var params = {
						target:that.userInfo.phone,
						verifcode:that.form.verifcode,
						phone:that.userInfo.phone
					}
				}else{
					var params = {
						target:that.userInfo.email,
						verifcode:that.form.verifcode,
						email:that.userInfo.email
					}
				}
				
				Api.authCheck(params).then(result =>{
					that.$toast(rthis.$t(result.msg))
					if(result.code==0){
						setTimeout(res=>{
							uni.navigateBack()
						},1000)
					}
				})
				
			},
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
</style>
