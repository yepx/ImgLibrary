<template>
	<view>
		<view class="a-mb-3 a-mx-3">
			<view v-for="(item,index) in promotional" :key="index" class="a-flex a-bg-white a-rounded a-mt-3 a-p-2">
				<view>
					<image class="a-w-120 a-h-120" :src="item.icon"></image>
				</view>
				<view class="a-ml-2 a-flex-1">
					<text class="a-font a-text-ellipsis-2 a-mb-2">{{item.name}}</text>
					<view class="a-flex a-align-center a-mb-2">
						<text class="a-font a-text-gray a-mr-2">{{$t('可推广产品数')}}:</text>
						<text class="a-font a-text-primary">{{item.count}}</text>
					</view>
					<view class="a-flex a-align-center a-mb-2">
						<text class="a-font a-text-gray a-mr-2">{{item.desc1}}</text>
					</view>
					
					<view class="a-flex a-align-center a-justify-between">
						<view>
							<view class="a-flex a-align-end">
								<FormatNumberShow  class="a-font-lg a-font-weight-bold a-text-primary a-mr" :data="item.prize" :currency="true"/>
								<text class="a-font-sm a-text-primary">/{{item.per}}{{$t('天')}}</text>
							</view>
						</view>
						<view @click="onBuy(item.id)" class="a-rounded a-bg-primary a-w-150 a-h-60 a-flex a-align-center a-justify-center">
							<text class="a-font-sm a-text-white">{{$t('立即购买')}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
		<cc-defineKeyboard ref="CodeKeyboard" :passwordArr="passwordArr" passwrdType="pay" @KeyInfo="KeyInfo"></cc-defineKeyboard>
	</view>
</template>

<script>
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				promotional:[],
				buyId:null,
				passwordArr:[],
				popupPassword:false,
			}
		},
		onLoad() {
			this.getPromotional()
		},
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.popupOptions = true
			}
		},
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.$navTo(`pages/mine/marketingRecord`)
			}
		},
		methods: {
			getPromotional() {
				var that = this;
				Api.promotional().then(res => {
					const {status,message,data} = res;
					that.promotional = res.data.line
				});
			},
			onBuy(id){
				this.buyId = id
				this.popupPassword = true
				this.passwordArr = []
				this.$refs.CodeKeyboard.keyIndex = -1
				this.$refs.CodeKeyboard.show();
			},
			KeyInfo(val) {
				if (val.index >= 6) {
					return;
				}
				// 判断是否输入的是删除键
				if (val.keyCode === 8) {
					// 删除最后一位
					this.passwordArr.splice(val.index + 1, 1)
				}
				// 判断是否输入的是.
				else if (val.keyCode == 190) {
					this.$refs.CodeKeyboard.hide();
				} else {
					this.passwordArr.push(val.key);
				}
				// uni.showModal({
				// 	title: '温馨提示',
				// 	content: '输入密码是 = ' + JSON.stringify(this.passwordArr)
				// })
				if(val.index >= 5){
					this.promotionalBuy()
				}
			},
			// 
			promotionalBuy(id) {
				const that = this
				var password = ''
				for(var i in this.passwordArr){
					password = password + this.passwordArr[i] 
				}
				var params = {
					safeword:password,
					id:that.buyId,
				}
				Api.promotionalBuy(params).then(result =>{
					if(result.code == 0){
						that.$refs.CodeKeyboard.hide();
						that.$toast(that.$t('成功'))
					}else{
						that.$toast(this.$t(result.msg))
					}
					
				})
			},
		}
	}
</script>

<style>

</style>
