<template>
	<view>
		<view class="a-p-3">
			<view class="a-mb-2">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('区块链网络')}}</text>
				</view>
				<view class="a-flex a-align-center a-flex-wrap">
					<view :class="active==0?'item a-border-primary':''" class="a-overflow-hidden a-border a-rounded a-w-210 a-flex a-align-center a-justify-center a-h-90 a-mr-2 a-position-relative">
						<text class="a-font">ETH_ERC20</text>
					</view>
					<view :class="active==1?'item a-border-primary':''" class="a-overflow-hidden a-border a-rounded a-w-210 a-flex a-align-center a-justify-center a-h-90 a-mr-2 a-position-relative">
						<text class="a-font">ETH_ERC20</text>
						<text class="iconfonts icon-dagou a-font-tiny a-text-white a-position-absolute a-bottom-0 a-right-0 a-p" style="z-index:99"></text>
					</view>
				</view>
				<view class="a-justify-center a-align-center a-flex-column a-w-690 a-my-5">
					
					<view class="a-w-200 a-h-200">
						
					</view>
					<view class="a-overflow-hidden a-border a-rounded a-w-210 a-flex a-align-center a-justify-center a-h-90 a-mr-2 a-position-relative">
						<text class="a-font">{{$t('保存二维码')}}</text>
					</view>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{$t('充值地址')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="a" :placeholder="$t('充值地址')"/>
					<view class="a-ml-2">
						<text class="a-font a-text-primary">{{$t('复制')}}</text>
					</view>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('充值数量')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="a" :placeholder="$t('充值数量')"/>
				</view>
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font">{{$t('预计到账')}}({{$t('当前汇率')}}1:3368)</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="a"/>
					<view class="a-ml-2">
						<text class="a-font-sm">USDT</text>
					</view>
				</view>
			</view>
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('上传图片')}}({{$t('上传支付详情截图')}})</text>
				</view>
				<view class="a-border a-border-dashed a-w-200 a-h-200 a-rounded a-flex a-align-center a-justify-center">
					<text class="iconfonts icon-xiangji a-font-max a-text-gray-light a-opacity-5"></text>
				</view>
			</view>
			
			<view @click="submitLogin" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('提交')}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				active:1
				
			}
		},
		onShow() {
			this.isLogin = checkLogin()
			if(!this.isLogin){
				this.$navTo('pages/login/index')
				return
			}
			
		},
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.$navTo(`pages/mine/withdrawRecord`)
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
.item:after {
    content: "";
    position: absolute;
    width: 40px;
    height: 40px;
    bottom: -22px;
    right: -22px;
    background-color: #1552f0;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    z-index: 1;
}
</style>
