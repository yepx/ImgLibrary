<template>
	<view>
		<view>
			<image class="a-w-750 a-h-300" mode="aspectFill" src="/static/images/level/seller-level-image.png"></image>
		</view>
		<view class="a-bg-white a-rounded-top-3 a-position-relative" style="margin-top:-100rpx;">
		  <view class="a-flex a-align-center a-mx-3 a-py-2">
			  <view class="a-w-120 a-mr-2">
			    <view class="a-w-120 a-h-100 a-position-relative" style="z-index:1">
			  		<image :src="getLevelIcon(mallLevel())" class="a-w-120 a-h-100"></image>
			  	</view>
			    <view class="a-w-120 a-rounded-circle a-flex a-align-center a-justify-center a-position-relative" style="z-index:2;margin-top:-20rpx;background:linear-gradient(180deg, #ff965b, #ce3925);">
			  		<text class="a-font-sm a-text-white">{{ $t('等级') }}{{mallLevel()}}</text>
			  	</view>
			  </view>
			  <view class="a-flex-1">
			    <text class="a-font-max a-font-weight-bold">{{mallLevel()}}-{{ $t('等级') }}{{ $t('卖家') }}</text>
			    <view>
					<svg src="/static/font/svg/bonus.svg" class="a-w-30 a-h-30"></svg>
			    	<text class="a-font-sm">{{ $t('当前分店人数：') }}</text>
			    	<text class="a-font-sm a-text-primary">{{sellerInfo.childNum || 0}}/10</text>
			    </view>
				<view>
					<text class="a-font-sm">{{ $t('当前') }}{{$t('运行资金')}}： </text>
					<FormatNumberShow class="a-font-sm a-text-primary" :data="sellerInfo.storeMoneyRechargeAcc" :currency="true" />
					<text class="a-font-sm">，{{ $t('距离') }}{{ $t('等级') }}{{nextLevelData.level}}{{ $t('还需') }}： </text>
					<text class="a-font-sm a-text-primary">${{nextLevelMoney}}</text>
				</view>
				<view>
					<text class="a-font-sm">{{ $t('当前') }}{{$t('采购优惠')}} </text>
					<text class="a-font-sm a-text-primary">{{currentLevelDis || 0}}%</text>
				</view>
			  </view>
		  </view>
		  
		  <view class="a-mx-3 a-flex a-align-center a-justify-between a-py-3">
			  <view class="a-w-60 a-h-50 a-position-relative" style="z-index:1">
			  	<image :src="getLevelIcon(mallLevel())" class="a-w-60 a-h-50"></image>
			  </view>
			  <div class="show-level-slider-main">
			    <div class="show-level-slider-line">
			      <div class="show-level-slider-line-inner" :style="'width:'+upgradeProgress+'%;'"></div>
			    </div>
			    <div class="show-level-slider-tips" style="left: 0%;"> {{upgradeProgress}}% </div>
			  </div>
			  <view class="a-w-60 a-h-50 a-position-relative" style="z-index:1">
			  	<image :src="getLevelIcon(nextLevelData.level)" class="a-w-60 a-h-50"></image>
			  </view>
		  </view>
		  
		</view>
		
		<view class="a-p-3">
		  <view class="">
		    <text class="a-font-lg">{{ $t('升级') }}</text>
			<text class="a-font-lg a-text-primary a-mr-2">{{ $t('销量扶持') }}</text>
		    <text class="a-font-lg">{{ $t('轻松') }}</text>
			<text class="a-font-lg a-text-primary">{{ $t('月入过万') }}</text>
		  </view>
		  <view class="a-flex a-align-center a-mt-2">
		    <text class="a-font" v-if="sellerInfo.childNum">
		      {{ $t('当前分店人数：') }}{{ sellerInfo.childNum || 0 }}
		    </text>
		    <text class="a-font" v-if="sellerInfo.teamNum">
		      {{ $t('当前团队人数：') }}{{ sellerInfo.teamNum || 0 }}
		    </text>
		  </view>
		  <view class="a-mt-3">
		    <view class="">
				<text class="a-font a-text-primary a-font-weight-bold">1.{{ $t('卖家等级介绍') }}</text>
			</view>
			<view class="a-mt-2">
				<text class="a-font-sm">
				  {{
					$t('平台为鼓励广大创业者，为创业者提供更大的商业机会，让您与我与我们一同成长，助您在销售中获得更大的成功，创业过程中为您准备了丰厚的升级奖励和销售利润比例提升，无论您是新手还是经验丰富的销售员，我们都鼓励您参与升级计划，并诚挚的邀请您加入我们，实现您的销售梦想！')
				  }}
				</text>
			</view>
		  </view>
		  <view class="a-mt-3">
		    <view class="">
				<text class="a-font a-text-primary a-font-weight-bold">2.{{ $t('会员升级说明') }}</text>
			</view>
			<view class="a-mt-2">
				<view class="">
					<text class="a-font a-font-weight-bold">{{ $t('会员升级') }}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm">
					  {{
						["Shop2U"].includes(projectTitle) ? $t('会员升级是通过直属推分店数决会员级别，分店数越高，系统将自动升级。') : $t('会员升级是通过直属推分店数决会员级别，分店数越高或运行资金满足条件，系统将自动升级。')
					  }}
					</text>
				</view>
			</view>
			<view class="a-mt-2">
				<view class="">
					<text class="a-font a-font-weight-bold">{{ $t('分店人数') }}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm">
					  {{$t("直属下级中，累计充值金额超过")}}
					</text>
					<text class="a-font-sm a-text-primary">
						${{(limitRechargeAmount * 1).toFixed(2)}}
					</text>
					<text class="a-font-sm">
					  {{$t("将视为有效人数")}}
					</text>
				</view>
			</view>
			<view class="a-mt-2">
				<view class="">
					<text class="a-font a-font-weight-bold">{{ $t('团队人数') }}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm">
					  {{$t("所有下级中，累计充值金额超过")}}
					</text>
					<text class="a-font-sm a-text-primary">
						${{(teamRechargeAmount * 1).toFixed(2)}}
					</text>
					<text class="a-font-sm">
					  {{$t("视为有效团队人数")}}
					</text>
				</view>
			</view>
			<view class="a-mt-2">
				<view class="">
					<text class="a-font a-font-weight-bold">{{ $t('销售利润比例') }}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm">
					  {{ $t('等级越高，获得销售利润越高') }}
					</text>
				</view>
			</view>
			<view class="a-mt-2">
				<view class="">
					<text class="a-font a-font-weight-bold">{{ $t('平台流量扶持') }}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm">
					  {{ $t('系统将优先为您提供一定商品流量曝光，创造更多的销售机会') }}
					</text>
				</view>
			</view>
			<view class="a-mt-2" v-if="!['Inchoi'].includes(projectTitle)">
				<view class="">
					<text class="a-font a-font-weight-bold">{{ $t('升级礼金') }}</text>
				</view>
				<view class="a-mt-1">
					<text class="a-font-sm">
					  {{ $t('每升级成功，系统将自动发放升级礼金') }}
					</text>
				</view>
			</view>
		  </view>
		  <view class="a-mt-3">
		    <view class="">
					<text class="a-font a-text-primary a-font-weight-bold">3.{{ $t('成长规则') }}</text>
				</view>
				<view class="a-mt-2">
					<text class="a-font-sm">
					  {{ $t('会员等级从升级那一刻开始计算，等级身份将终生有效；') }}
					</text>
				</view>
			</view>
		</view>
		<view class="a-mx-3">
		<div class="seller-level-list">
		  <div v-for="(item,index) in sellerLevelList" :key="index" class="seller-level-card a-mb-3" :class="item.level">
		    <div class="title">
		      <div class="level-title-desc">
		        <div class="level-title">{{item.level}} - {{$t('卖家等级')}} <!----></div>
		        <div class="level-desc">
		          <div class="desc-content">
		            <div class="desc-content-text">{{$t('运行资金')}}：<span
		                class="desc-content-text-span">
		                <!-- <FormatNumberShow :data="item.rechargeAmountCnd" :currency="true" /> -->
		              </span></div>
		            <div class="desc-content-text">{{$t('分店数')}}：<span
		                class="desc-content-text-span">{{item.popularizeUserCountCnd}}</span></div><!---->
		          </div>
		        </div>
		      </div>
		      <div class="mini desc-image">
		        <div class="el-image">
					<image :src="getLevelIcon(item.level)" class="a-w-120 a-h-120"
		            style="object-fit: cover;"/></image>
				</div>
		      </div>
		    </div>
		    <div class="content">
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
					<image src="/static/font/svg/dollar.svg" class="a-w-30 a-h-30"></image>
					{{$t('销售利润比')}}： </div>
		        <div class="content-item-right"><span>{{
		              (item.profitRationMin * 100).toFixed(2)
		            }}%</span>-<span>{{ (item.profitRationMax * 100).toFixed(2) }}%</span></div>
		      </div>
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
					<image src="/static/font/svg/wavy.svg" class="a-w-30 a-h-30"></image>
					 {{$t('平台流量扶持量（每日）')}}： </div>
		        <div class="content-item-right"> {{item.promoteViewDaily}} </div>
		      </div>
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
					<image src="/static/font/svg/earth.svg" class="a-w-30 a-h-30"></image>
					{{$t('全球到货时间')}}： 
				</div>
		        <div class="content-item-right">{{item.deliveryDays}}-15 </div>
		      </div>
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
		        	<image src="/static/font/svg/purchase.svg" class="a-w-30 a-h-30"></image>
					 {{$t('采购优惠')}}： </div>
		        <div class="content-item-right"><span>{{(item.sellerDiscount * 100).toFixed(2)}}%</span></div>
		      </div>
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
		        	<image src="/static/font/svg/bonus.svg" class="a-w-30 a-h-30"></image>
					 {{$t('升级礼金')}}： </div>
		        <div class="content-item-right">
		          <span v-if="item.upgradeCash">
		            <FormatNumberShow :data="item.upgradeCash" :currency="true" />
		          </span>
		          <span v-else>
		            <image :src="e" class="a-w-20 a-h-20"/>
		          </span>
		          </div>
		      </div><!---->
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
		        	<image src="/static/font/svg/customer-service.svg" class="a-w-30 a-h-30"></image>
					 {{$t('专属服务')}}： </div>
		        <div class="content-item-right">
		          <span v-if="item.hasExclusiveService">
					<image :src="r" class="a-w-20 a-h-20"/>
		          </span>
		          <span v-else>
		            <image :src="e" class="a-w-20 a-h-20"/>
		          </span>
		          </div>
		      </div>
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
		        	<image src="/static/font/svg/recommend.svg" class="a-w-30 a-h-30"></image>
					 {{$t('首页推荐')}}： </div>
		        <div class="content-item-right">
		          <span v-if="item.recommendAtFirstPage">
		            <image :src="r" class="a-w-20 a-h-20"/>
		          </span>
		          <span v-else>
		            <image :src="e" class="a-w-20 a-h-20"/>
		          </span>
		        </div>
		      </div>
		      <div class="content-item">
		        <div class="content-item-left a-flex a-align-center">
		        	<image src="/static/font/svg/recommend.svg" class="a-w-30 a-h-30"></image>
					{{$t('成为供货商')}}： </div>
		        <div class="content-item-right">
		          <span v-if="item.level==='SS'">
		            <image :src="r" class="a-w-20 a-h-20"/>
		          </span>
		          <span v-else>
		            <image :src="e" class="a-w-20 a-h-20"/>
		          </span>
		        </div>
		      </div><!---->
		    </div>
		  </div>
		</div>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import levela from '@/static/images/level/a.png'
	import levelb from '@/static/images/level/b.png'
	import levelc from '@/static/images/level/c.png'
	import levelo from '@/static/images/level/o.png'
	import levels from '@/static/images/level/s.png'
	import levelss from '@/static/images/level/ss.png'
	import levelsss from '@/static/images/level/sss.png'
	import e from '@/static/images/level/e.png'
	import r from '@/static/images/level/r.png'
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				sellerInfo:{},
				sellerLevelList: [],
				showTeamNum: false,
				levela,
				levelb,
				levelc,
				levelo,
				levels,
				levelss,
				levelsss,
				e,
				r,
				limitRechargeAmount: 0,
				teamRechargeAmount: 0,
				currentLevelData:{},
				nextLevelMoney:0,
				nextLevelData:{},
				upgradeProgress:0,
				currentLevelDis:0,
				projectTitle:"RavbyMall"
			}
		},
		onLoad() {
			this.getSellerInfo()
		},
		methods: {
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
					that.getSellerLevelList()
				});
			},
			getLevelIcon(level) {
			  switch (level) {
			    case 'A':
			      return this.levela
			    case 'B':
			      return this.levelb
			    case 'C':
			      return this.levelc
			    case 'O':
			      return this.levelo
			    case 'S':
			      return this.levels
			    case 'SS':
			      return this.levelss
			    case 'SSS':
			      return this.levelsss
			    default:
			      return this.levelo
			  }
			},
			getSellerLevelList() {
			  Api.sellerLevelList().then(res => {
			    this.sellerLevelList = res.data.result
				this.showTeamNum = !!this.sellerLevelList.find(item => item.teamNum > 0)
				// if (['Shop2U'].includes(projectTitle)) {
				//   //upgradeCash 写死
				//   this.sellerLevelList.forEach(item => {
				//     item.upgradeCash = this.webShowUpgradeCash(item.level)
				//   })
				// }
				this.currentLevelData = this.getCurrentLevelData() || {},
				this.getCurrentLevel()
				this.nextLevelMoney = this.getCurrentLevelData(this.nextLevel(this.mallLevel())).rechargeAmountCnd - this.sellerInfo.storeMoneyRechargeAcc;
				var t = this.sellerInfo.storeMoneyRechargeAcc,
				    n = this.getCurrentLevelData(this.nextLevel(this.mallLevel())) || {};
				this.nextLevelData = n;
				var i = n.rechargeAmountCnd || 0;
				this.upgradeProgress = (100 * (t / i > 1 ? 1 : t / i)).toFixed(2)
			  })
			},
			mallLevel() {
			    return this.sellerInfo.mallLevel || "O"
			},
			getCurrentLevel(){
			  var levelData = this.getCurrentLevelData(this.mallLevel())
			  if(levelData.sellerDiscount){
			    this.currentLevelDis = (levelData.sellerDiscount * 100).toFixed(2)
			  }
			
			},
			getCurrentLevelData(e) {
			    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.mallLevel();
				return this.sellerLevelList.find((function(a) {
			            return a.level === (e || "O")
			        })) || {}
			},
			nextLevel(a) {
			  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "O";
			  switch (e) {
			    case "O":
			        return "C";
			    case "C":
			        return "B";
			    case "B":
			        return "A";
			    case "A":
			        return "S";
			    case "S":
			        return "SS";
			    case "SS":
			        return "SSS";
			    case "SSS":
			        return "SSS";
			    default:
			        return "O"
			  }
			},
			webShowUpgradeCash(level) {
			  switch (level) {
			    case 'A':
			      return 700
			    case 'B':
			      return 500
			    case 'C':
			      return 100
			    case 'O':
			      return 0
			    case 'S':
			      return 1000
			    case 'SS':
			      return 1500
			    case 'SSS':
			      return 2000
			    default:
			      return 0
			  }
			},
			getSysPara() {
			  Api.getSysParaService({
			    code: 'valid_recharge_amount_for_seller_upgrade,valid_recharge_amount_for_team_num'
			  }).then(res => {
			    this.limitRechargeAmount = res.data.valid_recharge_amount_for_seller_upgrade
			    this.teamRechargeAmount = res.data.valid_recharge_amount_for_team_num
			  })
			}
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
.show-level-slider-main {
    position: relative;
    -webkit-box-flex: 1;
    -ms-flex: 1;
    flex: 1;
    margin: 0 6px
  }

.show-level-slider-main .show-level-slider-line {
    width: 100%;
    height: 8px;
    background-color: #ccc;
    border-radius: 4px
  }

.show-level-slider-main .show-level-slider-line .show-level-slider-line-inner {
    width: 0;
    -webkit-transition: all 1s;
    transition: all 1s;
    height: 100%;
    background-color: #2c78f8;
    border-radius: 4px
  }

.show-level-slider-main .show-level-slider-tips {
    position: absolute;
    -webkit-transition: all 1s;
    transition: all 1s;
    -webkit-transform: translateX(-50%);
    transform: translateX(-50%);
    border-radius: 4px;
    -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, .25);
    box-shadow: 0 2px 4px rgba(0, 0, 0, .25);
    left: 0;
    top: -30px;
    min-width: 40px;
    height: 20px;
    background-color: #2c78f8;
    color: #fff;
    font-size: 12px;
    padding: 4px 12px;
    text-align: center
  }

.show-level-slider-main .show-level-slider-tips:after {
    content: "";
    position: absolute;
    left: 50%;
    top: 100%;
    margin-left: -4px;
    border-width: 4px;
    border-style: solid;
    border-color: #2c78f8 transparent transparent transparent
  }
.seller-level-list {
    width: 100%;
    -webkit-box-pack: start;
    -ms-flex-pack: start;
    justify-content: flex-start;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap
}

.seller-level-card {
    border-radius: 10px;
    padding: 20px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    // margin-right: 24px;
    // margin-bottom: 24px
}

.seller-level-card.C {
    background: -webkit-gradient(linear,left top,left bottom,from(#f2fdff),to(#e9faff));
    background: linear-gradient(180deg,#f2fdff,#e9faff)
}

.seller-level-card.C .title:after {
    background: #d6f0f5
}

.seller-level-card.B {
    background: -webkit-gradient(linear,left top,left bottom,from(#fffef1),to(#fbffe0));
    background: linear-gradient(180deg,#fffef1,#fbffe0)
}

.seller-level-card.B .title:after {
    background: #e9efa2
}

.seller-level-card.A {
    background: -webkit-gradient(linear,left top,left bottom,from(#f9eeff),to(#f3dfff));
    background: linear-gradient(180deg,#f9eeff,#f3dfff)
}

.seller-level-card.A .title:after {
    background: #ebd0f9
}

.seller-level-card.O {
    background: -webkit-gradient(linear,left top,left bottom,from(#f2f2ff),to(#e9e9ff));
    background: linear-gradient(180deg,#f2f2ff,#e9e9ff)
}

.seller-level-card.O .title:after {
    background: #ebd0f9
}

.seller-level-card.S {
    background: -webkit-gradient(linear,left top,left bottom,from(#fff4f0),to(#ffe5d9));
    background: linear-gradient(180deg,#fff4f0,#ffe5d9)
}

.seller-level-card.S .title:after {
    background: #fbe6e2
}

.seller-level-card.SS {
    background: -webkit-gradient(linear,left top,left bottom,from(#fff5f1),color-stop(49.48%,#ffd6d6),to(#ffc5ab));
    background: linear-gradient(180deg,#fff5f1,#ffd6d6 49.48%,#ffc5ab)
}

.seller-level-card.SS .title:after {
    background: #f9d2cb
}

.seller-level-card.SSS {
    background: -webkit-gradient(linear,left top,left bottom,from(#fae1ff),color-stop(49.48%,#fad7ff),to(#f5b1ff));
    background: linear-gradient(180deg,#fae1ff,#fad7ff 49.48%,#f5b1ff)
}

.seller-level-card.SSS .title:after {
    background: #ebd0f9
}

// .seller-level-card:nth-child(3n) {
//     margin-right: 0
// }

// .seller-level-card:nth-child(n+4) {
//     margin-bottom: 0
// }

.seller-level-card .title {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    color: #000;
    font-family: Roboto;
    font-size: 16px;
    font-style: normal;
    position: relative;
    margin-bottom: 18px;
    padding-bottom: 18px
}

.seller-level-card .title:after {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    position: absolute;
    bottom: 0
}

.seller-level-card .title .desc-image {
    width:60px;
    height: 60px
}

.seller-level-card .title .desc-image.mini {
    width: 60px;
    height: 60px
}

.seller-level-card .title .level-title {
    font-weight: 700;
    margin-bottom: 12px
}

.seller-level-card .title .desc-content-text {
    line-height: 22px
}

.seller-level-card .title .level-desc {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    color: #333;
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400
}

.seller-level-card .title .level-desc .desc-content-text-span {
    font-weight: 500
}

.seller-level-card .content {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: start;
    -ms-flex-pack: start;
    justify-content: flex-start;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column
}

.seller-level-card .content .content-item {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    color: #333;
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    margin-bottom: 12px
}

.seller-level-card .content .content-item:last-child {
    margin-bottom: 0
}

.seller-level-card .content .content-item .content-item-right {
    font-weight: 500
}

.seller-level-card .content .content-item .card-pay-title {
    color: #1552f0;
    font-family: Roboto;
    font-size: 16px;
    font-style: normal;
    font-weight: 700;
    line-height: 36px
}
</style>
