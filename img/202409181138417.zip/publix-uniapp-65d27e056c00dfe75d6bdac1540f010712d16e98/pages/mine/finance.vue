<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="a-flex a-flex-wrap a-align-center a-justify-between a-mx-3 a-pt-3">
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(92, 157, 255);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('待到账金额')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<FormatNumberShow class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2" :data="sellerReport.willIncome" :currency="sellerReport.willIncome?true:false"/>
				</view>
			</view>
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(84, 193, 255);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('总销售额')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<FormatNumberShow class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2" :data="sellerReport.totalSales" :currency="sellerReport.totalSales?true:false"/>
				</view>
			</view>
			
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(255, 128, 73);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('总利润')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<FormatNumberShow class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2" :data="sellerReport.totalProfit" :currency="sellerReport.totalProfit?true:false"/>
				</view>
			</view>
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(63, 188, 143);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('总订单')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<FormatNumberShow class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2" :data="sellerReport.orderNum"/>
				</view>
			</view>
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(93, 106, 126);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('取消订单')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<FormatNumberShow class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2" :data="sellerReport.orderCancel"/>
				</view>
			</view>
			
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(221, 78, 78);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('退款订单')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<FormatNumberShow class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2" :data="sellerReport.orderReturns"/>
				</view>
			</view>
		</view>
		
		<view class=" a-mx-3">
			<view v-for="(item,index) in list.data" :key="index" class="a-bg-white a-rounded a-pb-2 a-px-2 a-mb-3 a-overflow-hidden">
				<view class="a-flex a-align-center a-justify-between a-mt-3">
					<view class="a-flex a-align-center">
						<image class="a-w-40 a-h-40 a-mr-2" :src="icodate"></image>
						<text class="a-font  a-mr-2">{{$t('日期')}}:</text>
						<text class="a-font-sm ">{{item.dayString}}</text>
					</view>
					<view class="a-flex a-align-center">
						<text class="a-font a-text-primary">{{$t('利润')}}</text>
						<FormatNumberShow  class="a-font a-text-primary a-ml" :data="item.totalProfit"  :decimalPlaces="6" />
					</view>
				</view>
				<view class="a-flex a-align-center a-mt-3">
					<image class="a-w-40 a-h-40 a-mr-2" :src="icobank"></image>
					<text class="a-font-sm  a-mr-2">{{$t('总订单')}}:</text>
					<text class="a-font-sm ">{{item.orderNum}}</text>
				</view>
				<view class="a-flex a-align-center a-mt-3">
					<image class="a-w-40 a-h-40 a-mr-2" :src="icocancel"></image>
					<text class="a-font-sm  a-mr-2">{{$t('取消订单')}}:</text>
					<text class="a-font-sm a-text-red">{{item.orderCancel}}</text>
				</view>
				<view class="a-flex a-align-center a-mt-3">
					<image class="a-w-40 a-h-40 a-mr-2" :src="icoback"></image>
					<text class="a-font-sm  a-mr-2">{{$t('退款订单')}}:</text>
					<text class="a-font-sm ">{{item.orderReturns}}</text>
				</view>
			</view>
		</view>
		</mescroll-body>
		
		<u-popup v-model="popupOptions" mode="bottom">
			<view class="a-bg-white a-flex-column a-w-750 a-rounded-top-3">
				<view v-for="(item,index) in orderOptions" :key="index" @click="onChangeTab(index)" class="a-h-100 a-flex a-align-center a-justify-between a-border-top a-border-light">
					<view class="a-flex-1"></view>
					<text class="a-font">{{item.label}}</text>
					<view class="a-flex-1 a-flex a-justify-end">
						<text v-if="orderOptionsActive == index" class="iconfonts icon-dagou a-font-tiny a-text-primary a-mr-2"></text>
					</view>
				</view>
				<view class="a-bg-gray-light a-h-20 a-w-75-">
					
				</view>
				<view @click="popupOptions = false" class="a-h-100 a-flex a-align-center a-justify-center a-border-top a-border-light">
					<text class="a-font">{{$t('取消')}}</text>
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				icodate:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAF+SURBVHgB7Zj/UcMgFMe/9fq/2aCs4ARJJ9ANjBPYDawT1A3UEZzAbqAbFDeoE+jjCheSEMqPC2l7fO6+d03hwQsPCDzgAilIDP4wJGJH+iOtPGzW0kbYFhgRJjtSnbnypdktPOxwhTQEj9rM0qAIYYn+3NGfOdxgFhvx/Eb6IO3h2JiaZym1g+NCmsI5pc+uM90QV51KaxyGX8FIW/mby/oubNGMToV2mJekDZp5ukTTR48nNG/zaihnCFvFelQWhvKNVv6oF9hWMTf8t0czkTnc0ev+DrSraK34OfwQDYkQlKR3D7sH0j0OoXNaqQpfBwXfUj5w0jMCSLVRB3PyDtpCLL4kNdIw+CmcHzEa9eThwlmH+EUqBSsMnC9tDor96gdpGNwb8zYTS3YwluxgLNnBWLKDsWQHYzlrByc/rJqoEZAriYShfbG/1Qu7qY8C/SQjx7joVwtOusGRu3ON6ZJHd3CkQjsrmiKrVZocmcGOGPprjIvI1XilQ06Kf/JOva1PtAe6AAAAAElFTkSuQmCC',
				icobank:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFGSURBVHgB7ZiBbcIwEEV/UQZoJ2iYoN2gdJNuUDYAJgAmgA0yArABGxAmgA3gTiRwCTkIinwOwk/6kv1lKZ/YXGwDgYBf3hS/R/oivcOOFWl5bxAHSkgHT5rhzkuZeAyXaywDySmOSRvRn5NS2BCT/kT/g7QvD+IB+a9IYM9CPP8/NztiwKdor2HPUrTP67CDlhMCNiVS/D6K/yoLKutfdGOw5VdE5WmneJLJkn6mAlpAruJb2LKvMkOZaUoI2JSXD8jFfoPiPvOWf4XrgEOcNqN1/StcBuSiyxtPrm+/NfxKXAWMSYOsPcTl6KD5Kq4C8vad1xl/Lqc1fBWXU5ySRg/4lURwQ/dBX+Wp6qDcTfRgz7dop3lDHtx58e5Efw5/B/eu9my+dmjV1UcZfoszj+ESlM5C2vXbD2zXIa9/vs1YIRBoGUc107GxkH5nqgAAAABJRU5ErkJggg==',
				icocancel:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAF4SURBVHgB7ZiNTcMwEEa/IgaADcoGHaEbwAZkg44QZwLYgHQCYAI6AhtQJoANWp/qqhfHtuKfuFHkJ53SSx3lNfbVsYHCzFk4vruT8ayOY/Iv41PG3ueiVxmHzPGCgVxDziqpd/FSxg/LdyrGZCXjieX3OHW7kQ0uv+Yd+fhi993wL260hrwgvpGPHcwOPcHJUQRjmbVghdNMk6qdkVuEUcl4U58fZAhLOzpfs3wLT1J0cQ2zoEBXLohQwRZdKV1SoCtHuffTI0K7mGjYzaEJ6XINAokRBNyS5/PBckSKMdjAPgaj5IhU/4OLgee8SSEoYK5WW3V7ESso0C8IwfJoyZgiEXBXq1DHWsu9CH2CFdxyeuFQ26DpLtUYNFWrrbq9CO3iVh3pFd01Q5Dk74B2VmLGYJu4nZHywhpLEYxFF+Qr+jXysYLZoTeh06L5j+UfGH8Bv0b3YdASYu+6gDZwJrN5NCVJo5zrnW0p4xF5NjC3cOxoFWbNERnpt8/Se1PmAAAAAElFTkSuQmCC',
				icoback:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFDSURBVHgB7ZiBbQIhFIb/XBygI7wNdIO+DdoN2hU6QesEdoO2G7QTtG7QDXQD3UAhoDlPuAOOPDHyJX9yIhe+8BIOACqV8iCVhcpGZScUPdaHHbuXmbCYS3TWJ7i6oNwhK5/cY6fTPeToVo4PfzStTtPW87fKEnL8q3y2fh8np/G8sIU8zjEbFE7xghNPO0MedjX2CTIK4GpL/GcjCcNRtT7BOeThbkNdZsZyM4Kk8guzyWBkJIcgwcixfX5CRsYKEowctdp+kJExgoRzuWeYrVo2UgUJbrkvZGaCeAjncnpRXyLg0GPZInDPmSLYldO82sTwovI+1Cm2xITwWRpiGtIpdgbXKm8wB6w7pLNG4Lc+pcRzCG4kfCUeMzupDI7JiDjhZ4Zxemnw4OtY9M2Cpvi7GQ3B3DRJ324tkG8Jq1Ruhz39veqNh2RQngAAAABJRU5ErkJggg==',
				
				sellerInfo:{},
				sellerReport:{},
				
				popupOptions:false,
				orderOptions: [
				  {
				    label: this.$t('全部'),
				    value: 0,
				  },
				  {
				    label: this.$t('今日'),
				    value: 1,
				  },
				  {
				    label: this.$t('昨日'),
				    value: 2,
				  },
				  {
				    label: this.$t('本周'),
				    value: 3,
				  },
				  {
				    label: this.$t('本月'),
				    value: 4,
				  },
				  {
				    label: this.$t('本年'),
				    value: 5,
				  }
				],
				// 当前标签索引
				orderOptionsActive: 0,
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: false,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
			}
		},
		onShow() {
			this.getSellerInfo()
		},
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.popupOptions = true
			}
		},
		methods: {
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
					that.getSellerReport()
					that.onRefreshList()
				});
			},
			getSellerReport() {
				var that = this;
				var params = {
					sellerId:that.sellerInfo.id,
					content_type:that.getTabValue()
				}
				Api.sellerReport(params).then(res => {
					const {status,message,data} = res;
					that.sellerReport = res.data.head
				});
			},
			onChangeTab(index) {
				const that = this
				// 设置当前选中的标签
				that.orderOptionsActive = index
				that.popupOptions = false
				// 刷新订单列表
				that.onRefreshList()
				that.getSellerReport()
			},
			// 获取当前标签项的值
			getTabValue() {
			  const that = this
			  return that.orderOptions.length ? that.orderOptions[that.orderOptionsActive].value : ''
			},
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						page_no:pageNo,
						pageSize:pageSize,
						sellerId:that.sellerInfo.id,
						content_type:that.getTabValue(),
					};
					Api.financeReport(params).then(result =>{
						const newList = result.data
						
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
		}
	}
</script>

<style>

</style>
