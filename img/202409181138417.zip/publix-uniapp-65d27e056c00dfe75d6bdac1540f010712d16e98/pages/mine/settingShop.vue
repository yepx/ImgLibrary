<template>
	<view>
		<view class="a-p-3 a-px-2 a-rounded">
			<view @click="$navTo('pages/mine/shopInfo')" class="a-p-2 a-flex a-align-center a-justify-between a-bg-white a-mb-2 a-rounded">
				<view class="a-flex a-align-center">
					<image class="a-w-80 a-h-80" mode="aspectFill" :src="globalData.imgUrl+'/images/ico-info.png'"></image>
					<text class="a-font a-ml-2">{{$t('基础信息')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/shopBanner')" class="a-p-2 a-flex a-align-center a-justify-between a-bg-white a-mb-2 a-rounded">
				<view class="a-flex a-align-center">
					<image class="a-w-80 a-h-80" mode="aspectFill" :src="globalData.imgUrl+'/images/ico-banner.png'"></image>
					<text class="a-font a-ml-2">{{$t('首页横幅')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/shopSocial')" class="a-p-2 a-flex a-align-center a-justify-between a-bg-white a-mb-2 a-rounded">
				<view class="a-flex a-align-center">
					<image class="a-w-80 a-h-80" mode="aspectFill" :src="globalData.imgUrl+'/images/ico-social.png'"></image>
					<text class="a-font a-ml-2">{{$t('社交媒体')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			
			
		</view>
		
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
			}
		},
		onShow() {
			this.isLogin = checkLogin()
			if(!this.isLogin){
				this.$navTo('pages/login/index')
				return
			}
			
		},
		methods: {
			// 切换标签项
			onChangeTab(index) {
				const that = this
				// 设置当前选中的标签
				that.curTab = index
				// 刷新订单列表
				that.onRefreshList()
			},
		}
	}
</script>

<style>

</style>
