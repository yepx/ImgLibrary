<template>
	<view>
		<view class="a-bg-white">
			<view v-for="(item,index) in notificationList" :key="index" @click="$navTo('pages/mine/messageCenter')" class="a-flex a-p-3 a-border-top a-border-light">
				<view class="a-w-90 a-h-90 a-rounded-circle a-bg-primary a-flex a-align-center a-justify-center">
					<text class="iconfonts icon-xiaoxi a-font-max-two a-text-white"></text>
				</view>
				<view class="a-ml-2 a-flex-1">
					<view class="a-flex a-align-center a-justify-between">
						<text class="a-font">{{$t('系统消息')}}</text>
						<view v-if="messageNumber" class="a-flex a-align-center a-justify-center a-px-1 a-py a-bg-red a-rounded-circle">
							<text class="a-font-sm a-text-white">{{messageNumber>99?'99+':messageNumber}}</text>
						</view>
					</view>
					<view class="a-flex a-align-center a-justify-between a-mt-2">
						<text class="a-font-sm a-text-ellipsis-1 a-flex-1">{{item.content?item.content:'-'}}</text>
						<text class="a-font-min a-text-gray">{{item.reserveSendTime}}</text>
					</view>
				</view>
			</view>
			<view v-for="(item,index) in messageList" @click="$navTo('pages/chat/index?partyid='+item.partyid+'&username='+getEmail(item.username)+'&avatar='+item.useravatar)" class="a-flex a-p-3 a-border-top a-border-light">
				<view>
					<image class="a-w-90 a-h-90 a-rounded-circle" :src="require(`@/static/images/avatar/${
					  item.useravatar || '1'
					}.png`)"></image>
				</view>
				<view class="a-ml-2 a-flex-1">
					<view class="a-flex a-align-center a-justify-between">
						<text class="a-font">{{getEmail(item.username)}}</text>
					</view>
					<view class="a-flex a-align-center a-justify-between a-mt-2">
						<text class="a-font-sm a-text-ellipsis-1 a-flex-1">{{item.content?item.content:'-'}}</text>
						<text class="a-font-min a-text-gray">{{getTime(item.updatetime)}}</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import {sumo_time} from '@/common/js/sumo_time.js'
	export default {
		data() {
			return {
				globalData: App.globalData,
				isMP: false,
				isLogin: false,
				runInterval:null,
				notificationList:[],
				messageList:[],
				messageNumber:0,
			}
		},
		onShow() {
			this.getMessageList()
			this.getNotificationList()
			this.getMessageNumber()
			this.runSetInterval()
		},
		onHide() {
			clearInterval(this.runInterval)
		},
		destroyed() {
			clearInterval(this.runInterval)
		},
		methods: {
			getTime(time){
				let date = new Date(time);
				 //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				let y = date.getFullYear();
				let MM = date.getMonth() + 1;
				MM = MM < 10 ? ('0' + MM) : MM;//月补0
				let d = date.getDate();
				d = d < 10 ? ('0' + d) : d;//天补0
				let h = date.getHours();
				h = h < 10 ? ('0' + h) : h;//小时补0
				let m = date.getMinutes();
				m = m < 10 ? ('0' + m) : m;//分钟补0
				let s = date.getSeconds();
				s = s < 10 ? ('0' + s) : s;//秒补0
				let nowTime = y + '-' + MM + '-' + d + ' ' + h + ':' + m+ ':' + s;
				let dateTime = sumo_time(nowTime)
				return dateTime;
			},
			getEmail(email){
				return utils.emailHide(email)
				
			},
			//定时
			runSetInterval(){
				this.runInterval = setInterval(() => {
					this.getMessageList()
				}, 3000)
			},
			getNotificationList() {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
					  pageSize:1,
					  lastLocation:0,
					  type:3,
					  status:0,
					  module:0
					};
					Api.notificationList(params).then(result =>{
						this.notificationList = this.getElementsI18n(result.data)
					})
				})
			},
			getElementsI18n(list) {
			  list.forEach(item => {
			    // i18n支持通配符
			    let varInfo = JSON.parse(item.varInfo)
			    let varObj = {}
			    varInfo.forEach((item, index) => {
			      varObj[item.code] = item.value
			    })
			    switch (item.title) {
			      case 'One order finished':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Freeze seller because of violation':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'New Order':
			        item.content = this.$t(item.content)
			        break;
			      case 'Order overtime':
			        item.content = this.$t(item.content)
			        break;
			      case 'Buyer Consult from Customer Service':
			        item.content = this.$t(item.content)
			        break;
			      case 'Your Seller-Credit updated':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'UnFreeze seller':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Withdraw Success Notify':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Recharge Pass Notify':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Store certification passed':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Store authentication failed':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			      case 'Order purchase overtime':
			        item.content = this.$t(item.title + ' content', varObj)
			        break;
			    }
			    item.title = this.$t(item.title)
			  })
			  return list
			},
			getMessageList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
					  loginType:'shop'
					};
					Api.messageList(params).then(result =>{
						this.messageList = result.data
					})
				})
			},
			getMessageNumber() {
				var that = this;
				Api.messageNumber({type:3}).then(res => {
					const {status,message,data} = res;
					that.messageNumber = res.data.count
				});
			},
		}
	}
</script>

<style lang="scss">
</style>