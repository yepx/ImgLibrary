<template>
	<view>
		<view class="a-p-3">
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('取款方式')}}</text>
				</view>
				<picker :range="methodType" :value="methodTypeActive" range-key="title" @change="changeMethodType">
					<view v-if="methodType.length" class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<text class="a-font a-flex-1">{{methodType[methodTypeActive-1].title}}</text>
					</view>
				</picker>
			</view>
			
			<view v-if="methodTypeActive==0">
				<view class="a-mb-4">
					<view class="a-mb-2">
						<text class="a-font a-text-red">*</text>
						<text class="a-font">{{$t('选择币种')}}</text>
					</view>
					<picker :range="blockchainType" :value="blockchainActive" range-key="coin" @change="changeBlockchain">
					<view v-if="blockchainType.length" class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<text class="a-font a-flex-1">{{currencyType}}</text>
					</view>
					</picker>
				</view>
				
				<view class="a-mb-4">
					<view class="a-mb-2">
						<text class="a-font a-text-red">*</text>
						<text class="a-font">{{$t('区块链网络')}}</text>
					</view>
					<view class="a-flex a-align-center a-flex-wrap">
						<view v-for="(item,index) in network" :key="index" @click="changeNetwork(index)" :class="networkActive==index?'item a-border-primary':''" class="a-overflow-hidden a-border a-rounded a-w-210 a-flex a-align-center a-justify-center a-h-90 a-mr-2 a-position-relative">
							<text class="a-font">{{item}}</text>
							<text v-if="networkActive==index" class="iconfonts icon-dagou a-font-tiny a-text-white a-position-absolute a-bottom-0 a-right-0 a-p" style="z-index:99"></text>
						</view>
					</view>
				</view>
				
				<view class="a-mb-4">
					<view class="a-mb-2">
						<text class="a-font a-text-red">*</text>
						<text class="a-font">{{$t('地址')}}</text>
					</view>
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1" type="text" v-model="form.walletAddress" :placeholder="$t('地址')"/>
					</view>
				</view>
				
				
			</view>
			
			<view v-if="methodTypeActive==1">
				
				<view class="a-mb-4">
					<view class="a-mb-2">
						<text class="a-font a-text-red">*</text>
						<text class="a-font">{{$t('开户行')}}</text>
					</view>
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1" type="text" v-model="form.bankName" :placeholder="$t('开户行')"/>
					</view>
				</view>
				
				<view class="a-mb-4">
					<view class="a-mb-2">
						<text class="a-font a-text-red">*</text>
						<text class="a-font">{{$t('姓名')}}</text>
					</view>
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1" type="text" v-model="form.bankUserName" :placeholder="$t('姓名')"/>
					</view>
				</view>
				<view class="a-mb-4">
					<view class="a-mb-2">
						<text class="a-font a-text-red">*</text>
						<text class="a-font">{{$t('卡号')}}</text>
					</view>
					<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
						<input class="a-font a-flex-1" type="text" v-model="form.bankCardNo" :placeholder="$t('卡号')"/>
					</view>
				</view>
				
				
			</view>
			
			<view class="a-mb-4">
				<view class="a-mb-2">
					<text class="a-font a-text-red">*</text>
					<text class="a-font">{{$t('金额')}}</text>
				</view>
				<view class="a-border a-bg-white a-rounded-2 a-h-90 a-flex a-align-center a-px-2 ">
					<input class="a-font a-flex-1" type="text" v-model="form.account"  @input="truncateInput" :placeholder="$t('金额')"/>
					<view @click="all" class="a-ml-2">
						<text class="a-font-sm a-text-primary">{{$t('全部')}}</text>
					</view>
				</view>
			</view>
			
			<view class="a-mb-1">
				<text class="a-font-sm" style="color:#67c23a">{{$t('当前余额')}}:</text>
				<FormatNumberShow  class="a-font-sm" style="color:#67c23a" :data="walletInfo.money" :decimalPlaces="6"/>
				<text class="a-font-sm" style="color:#67c23a">{{ ' USD'}}</text>
				<text v-if="!['USDT','usdt'].includes(currencyType)" class="a-font-sm" style="color:#67c23a">{{' ≈ '}}</text>
				<FormatNumberShow v-if="!['USDT','usdt'].includes(currencyType)" class="a-font-sm" style="color:#67c23a" :data="(walletInfo.money / (currencyFee|1))" :decimalPlaces="6"/>
				<text v-if="!['USDT','usdt'].includes(currencyType)" class="a-font-sm" style="color:#67c23a">{{ ' '+currencyType }}</text>
			</view>
			
			<view class="a-mb-4 a-flex a-align-center a-justify-between">
				<view class="a-flex a-align-center">
					<text class="a-font-sm a-text-gray" v-if="false">{{$t('实际到账')}}:{{actualAccount}} {{currencyType}}</text>
					<!-- <FormatNumberShow class="a-font-sm a-text-gray" :data="actualAccount * (currencyFee|1)" :decimalPlaces="6"/>
					<text class="a-font-sm a-text-gray"> USDT</text> -->
				</view>
				<text class="a-font-sm a-text-primary">{{$t('手续费')}}:{{feeAcc}}%</text>
				<!-- <FormatNumberShow class="a-font-sm a-text-primary a-ml-2" :data="(feeAccount / (currencyFee|1))" :decimalPlaces="6"/> -->
			</view>
			
			
			<view @click="onWithdraw" class="a-mb-3 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center ">
				<text class="a-font-lg a-text-white">{{$t('提交')}}</text>
			</view>
		</view>
		
		<cc-defineKeyboard ref="CodeKeyboard" :passwordArr="passwordArr" passwrdType="pay" @KeyInfo="KeyInfo"></cc-defineKeyboard>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				walletInfo:{},
				feeSetInvetval:null,//汇率定时器
				currencyFee: null,//币种汇率
				feeAccount:'',//手续费
				currencyType:'bank',//币种
				actualAccount:'',//实际到账
				handlingFee:'',//搜续费
				form:{
					walletAddress:'',
					account:'',
					bankName:'',
					bankUserName:'',
					bankCardNo:'',
				},
				methodTypeActive:1,
				methodType:[
					/*{
						value:1,
						title:this.$t('虚拟币')
					},
					*/
					{
						value:2,
						title:this.$t('银行卡')
					}
				],
				blockchainActive:0,
				blockchain:[],
				blockchainType:[],
				networkActive:0,
				network:[],
				
				passwordArr:[],
				popupPassword:false,
				withdraw_fee:0,
			}
		},
		watch: {
			'form.account'() {
			//  this.changeAccount()
			},
		},
		computed: {
		  feeAcc() {
			  //手续费比例
			  console.log(this.withdraw_fee)
		    return (this.$bigDecimal.multiply(this.withdraw_fee, 100) * 1).toFixed(2)
		  },
		},
		onLoad() {
			this.getWalletInfo()
			this.getBlockchain()
			this.getWithdrawOpen()
			
			 let type= this.currencyType
			Api.getWithdrawFee({channel: type}).then(result =>{
				this.withdraw_fee = result.data.withdraw_fee
				//this.currencyFee= result.data.withdraw_fee
			
			})
			
		},
		onHide() {
			clearInterval(this.feeSetInvetval)
			this.feeSetInvetval=null
		},
		destroyed() {
			clearInterval(this.feeSetInvetval)
			this.feeSetInvetval=null
		},
		onNavigationBarButtonTap(e){
			const index = e.index;
			
			if (index === 0){
				this.$navTo(`pages/mine/withdrawRecord`)
			}
		},
		methods: {
			// 钱包
			getWalletInfo() {
				const that = this
				Api.walletInfo().then(result =>{
					that.walletInfo = result.data
				})
			},
			changeMethodType(e){
				
				var that = this
				that.methodTypeActive = e.detail.value
				that.form.account = ''
				that.getCurrencyFee()
				that.getWithdrawFee()
			},
			// 获取虚拟方式
			getBlockchain() {
				const that = this
				Api.selectPaymentChannel().then(result =>{
					that.blockchain = result.data
					that.blockchainType = []
					for(var i in that.blockchain){
						let index = that.blockchainType.findIndex((ele) => {
						    return ele.coin === that.blockchain[i].coin;
						});
						if(index==-1){
							that.blockchainType.push(that.blockchain[i]);
						}
					}
					that.currencyType = that.blockchainType[that.blockchainActive].coin
					that.network = []
					that.blockchain.map(item => {
					  if (that.currencyType == item.coin) {
					    that.network.push(item.blockchain_name)
					  }
					})
					
					
					that.getWithdrawFee()
					this.feeSetInvetval = setInterval(() => {
					  that.getCurrencyFee()
					}, 2000)
				})
			},
			changeBlockchain(e){
				var that = this
				that.blockchainActive = e.detail.value
				that.currencyType = that.blockchainType[that.blockchainActive].coin
				that.network = []
				that.blockchain.map(item => {
				  if (that.currencyType === item.coin) {
				    that.network.push(item.blockchain_name)
				  }
				})
				that.getCurrencyFee()
				that.getWithdrawFee()
			},
			changeNetwork(e){
				var that = this
				that.networkActive = e
			},
			// 获取汇率
			getCurrencyFee() {
				const that = this
				if(that.methodTypeActive ==1){
					var type = 'bank'
				}else{
					var type = that.currencyType
				}
				Api.getCurrencyFee({symbol: type}).then(result =>{
					//that.currencyFee = result.data.price
					setTimeout(() => {
					//  that.changeAccount()
					}, 100)
				})
			},
			//获取
			getWithdrawFee() {
				const that = this
				if(that.methodTypeActive ==1){
					var type = 'bank'
				}else{
					var type = that.currencyType
				}
				Api.getCurrencyFee({channel: type}).then(result =>{
					that.handlingFee = result.data.price
					that.
					debugger
				})
			},
			changeAccount() {
			  //计算实际到账，保留两位小数，用截取法
			  //先转成U
			  let usdtAccount = this.$bigDecimal.multiply(this.form.account, this.currencyFee)
			  //计算手续费要多少usdt
			  let feeAccount = this.$bigDecimal.multiply(usdtAccount, this.handlingFee) * 1
			  this.feeAccount = feeAccount.toFixed(feeAccount.toString().split('.')[1]?.length < 2 ? feeAccount.toString().split('.')[1]?.length : 2)
			  //实际到账的usdt = usdtAccount - 手续费
			  usdtAccount = this.$bigDecimal.subtract(usdtAccount, this.feeAccount)
			  //再转成用户选择的币种
			  let actualAccount = this.$bigDecimal.divide(usdtAccount, this.currencyFee) * 1
			  
			  this.actualAccount = actualAccount.toFixed(actualAccount.toString().split('.')[1]?.length < 6 ? actualAccount.toString().split('.')[1]?.length : 6)
			},
			truncateInput() {
			  if (this.form.account !== "") {
			    this.form.account = this.form.account.replace(/[^0-9.]/g, '')
			    const parts = this.form.account.toString().split('.');
			    if (parts.length === 2) {
			      const decimalPart = parts[1].slice(0, 10); // 截取小数部分的前10位
			      this.form.account = `${parts[0]}.${decimalPart}`;
			    }
			  }
			},
			all(){
				var that = this
				that.form.account = that.walletInfo.money
			},
			getWithdrawOpen(){
				const that = this
				Api.getWithdrawOpen().then(result =>{
					this.sessionToken = result.data.session_token
				})
			},
			onWithdraw(id){
				this.popupPassword = true
				this.passwordArr = []
				this.$refs.CodeKeyboard.keyIndex = -1
				this.$refs.CodeKeyboard.show();
			},
			KeyInfo(val) {
				if (val.index >= 6) {
					return;
				}
				// 判断是否输入的是删除键
				if (val.keyCode === 8) {
					// 删除最后一位
					this.passwordArr.splice(val.index + 1, 1)
				}
				// 判断是否输入的是.
				else if (val.keyCode == 190) {
					this.$refs.CodeKeyboard.hide();
				} else {
					this.passwordArr.push(val.key);
				}
				// uni.showModal({
				// 	title: '温馨提示',
				// 	content: '输入密码是 = ' + JSON.stringify(this.passwordArr)
				// })
				if(val.index >= 5){
					this.onSubmit()
				}
			},
			
			onSubmit(){
				var that = this
				var password = ''
				for(var i in this.passwordArr){
					password = password + this.passwordArr[i] 
				}
				if(this.methodTypeActive == 1){
					var params = {
						session_token: that.sessionToken,
						safeword:password,
						amount: this.form.account,
						channel:  'bank',
						bankName: this.form.bankName,
						bankUserName: this.form.bankUserName,
						bankCardNo: this.form.bankCardNo,
					}
				}else{
					var params = {
						session_token: that.sessionToken,
						amount: this.form.account,
						safeword:password,
						from: this.form.walletAddress,
						channel: that.currencyType,
					}
				}
				
				Api.withdraw(params).then(result =>{
					that.$toast(this.$t(result.msg))
					if(result.code ==0){
						setTimeout(res=>{
							uni.navigateBack()
						},1000)
					}
				})
				
				
			}
			
		}
	}
</script>

<style lang="scss">
page{
	background-color:#ffffff;
}
.item:after {
    content: "";
    position: absolute;
    width: 40px;
    height: 40px;
    bottom: -22px;
    right: -22px;
    background-color: #1552f0;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    z-index: 1;
}
</style>
