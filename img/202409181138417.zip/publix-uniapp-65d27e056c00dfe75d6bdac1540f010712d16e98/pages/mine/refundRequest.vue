<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="a-p-3">
			<view v-for="(item,index) in list.data" :key="index" @click="$navTo('pages/mine/refundDetail?id='+item.id)" class="a-bg-white a-rounded a-mb-3 a-px-3">
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('申请时间')}}</text>
					<text class="a-font">{{item.refundTime}}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款单号')}}</text>
					<view class="a-flex a-text-ellipsis-1">
						<text class="a-font">{{item.id}}</text>
						<text @click.stop="copy(item.id)" class="iconfonts icon-fuzhi1 a-font-lg a-text-gray a-ml-1"></text>
					</view>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款金额')}}</text>
					<FormatNumberShow class="a-font" :data="item.returnPrice" :currency="true"/>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款状态')}}</text>
					<text class="a-font" v-if="item.returnStatus == '0'">{{ $t('未退款') }}</text>
					<text class="a-font a-text-orange" v-if="item.returnStatus == '1'">{{ $t('退款中') }}</text>
					<text class="a-font a-text-green" v-if="item.returnStatus == '2'">{{ $t('成功') }}</text>
					<text class="a-font a-text-red" v-if="item.returnStatus == '3'">{{ $t('失败') }}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款理由')}}</text>
					<text class="a-font" v-if="item.returnReason == '1'">{{ $t('未收到货') }}</text>
					<text class="a-font" v-if="item.returnReason == '2'">{{ $t('不喜欢、不想要') }}</text>
					<text class="a-font" v-if="item.returnReason == '3'">{{ $t('卖家发错货') }}</text>
					<text class="a-font" v-if="item.returnReason == '4'">{{ $t('假冒品牌') }}</text>
					<text class="a-font" v-if="item.returnReason == '5'">{{ $t('少发、漏发') }}</text>
					<text class="a-font" v-if="item.returnReason == '6'">{{ $t('收到商品破损') }}</text>
					<text class="a-font" v-if="item.returnReason == '7'">{{ $t('存在质量问题') }}</text>
					<text class="a-font" v-if="item.returnReason == '8'">{{ $t('与商家协商一致退款') }}</text>
					<text class="a-font" v-if="item.returnReason == '9'">{{ $t('其他原因') }}</text>
				</view>
				<view class="a-h-80 a-flex a-align-center a-justify-between">
					<text class="a-font a-text-gray">{{$t('退款说明')}}</text>
					<text class="a-font">{{item.returnDetail?item.returnDetail:'--'}}</text>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
				
			}
		},
		onShow() {
			
		},
		methods: {
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						page_no:pageNo,
						pageSize:pageSize,
					};
					Api.orderRefund(params).then(result =>{
						const newList = result.data
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			}
		}
	}
</script>

<style>

</style>
