<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class="autoFixed">
			<u-tabs ref="tabs" :list="tabs" :is-scroll="false" :current="curTab" bar-height="6" bar-width="40" active-color="#1552f0" inactive-color="" bg-color="#ffffff" @change="onChangeTab"></u-tabs>
		</view>
		<view  class=" transitionBackgroundColor a-mb-3">
			<view class="a-w-750" :style="'height:'+globalData.statusBar+'px;'"></view>
			<view class="a-mx-4 a-h-110 a-flex a-align-end">
				<view @click="$navTo('pages/search/order')" class="a-flex-1 a-h-80 a-px-3 a-bg-white a-rounded-circle a-flex a-align-center a-justify-between">
					<text class="iconfonts icon-sousuo a-font-max-two a-text-gray"></text>
					<text class="a-flex-1 a-text-center a-text-gray-light a-font">{{$t('搜索')}}</text>
				</view>
			</view>
		</view>
		
		<view class="a-flex a-align-center a-justify-between a-mx-3">
			
			<picker class="a-flex-1" :range="payStatus" range-key="label" :value="indexPayStatus" @change="changePayStatus">
			<view class="a-flex a-align-center a-justify-between a-flex-1 a-px-2 a-rounded a-bg-white a-mr-1 a-h-80">
				<text class="a-font">{{payStatus[indexPayStatus].value?payStatus[indexPayStatus].label:$t('支付状态')}}</text>
				<text class="iconfonts icon-xiajiantou a-font"></text>
			</view>
			</picker>
			<picker class="a-flex-1" :range="orderStatus" range-key="label" :value="indexOrderStatus" @change="changeOrderStatus">
			<view class="a-flex a-align-center a-justify-between a-flex-1 a-px-2 a-rounded a-bg-white a-ml-1 a-h-80">
				<text class="a-font">{{orderStatus[indexOrderStatus].value?orderStatus[indexOrderStatus].label:$t('物流状态')}}</text>
				<text class="iconfonts icon-xiajiantou a-font"></text>
			</view>
			</picker>
		</view>
		<view class="a-mb-3 a-mx-3">
			<view v-for="(item,index) in list.data" :key="index" @click="$navTo('pages/order/detail?id='+item.id+'&title='+$t('订单详情'))" class="a-bg-white a-rounded a-mt-3 a-p-2">
				<text class="a-font a-text-ellipsis-2 a-mb-3">{{item.id}}</text>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE6F2 a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('下单日期')}}:</text>
					<text class="a-font-sm a-text-gray">{{item.createTime}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE69D a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('支付状态')}}:</text>
					<text class="a-font-sm" :class="item.payStatus?'a-text-primary':'a-text-red'">{{item.payStatus?$t('买家已付款'):$t('等待买家付款')}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE681 a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('采购状态')}}:</text>
					<text class="a-font-sm a-text-gray">{{item.purchStatus === 0?$t('待采购'):$t('已采购')}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE6DF a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('物流状态')}}:</text>
					<text class="a-font-sm a-text-gray">{{getOrderStatus(item.status)}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE6F2 a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('订单超时')}}:</text>
					<text v-if="getTimeStatus(item.createTime,item.currstyemTime) && item.status == 1 && parseInt(item.purchStatus) === 0">
					  <Countdown color="#f56c6c" background-color="#fef0f0" :showDay="false" :day="countdown(item.createTime,item.currstyemTime,'day')" :hour="countdown(item.createTime,item.currstyemTime,'hour')" :minute="countdown(item.createTime,item.currstyemTime,'minute')" :second="countdown(item.createTime,item.currstyemTime,'second')"/>
					</text>
					<text class="a-font-sm a-text-gray" v-else-if="item.status == 1 && parseInt(item.purchStatus) === 0">{{$t('已超时')}}</text>
					<text class="a-font-sm a-text-gray" v-else>-</text>
				</view>
				
				
				
				<view class="a-border-top a-border-light a-pt-2 a-flex a-align-center a-justify-between">
					<view>
						<view class="a-flex a-align-center">
							<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.prizeReal" :currency="true"/>
						</view>
						<text class="a-font-sm a-text-gray">({{$t('利润')}}</text>
						<FormatNumberShow class="a-font-sm a-text-gray" :data="item.profit" :currency="true"/>
						<text class="a-font-sm a-text-gray">)</text>
					</view>
					<view v-if="item.status==1 && item.payStatus && item.purchStatus==0" @click.stop="$navTo('pages/order/create?id='+item.id+'&title='+$t('采购确认'))" class="a-rounded a-bg-primary a-w-150 a-h-60 a-flex a-align-center a-justify-center">
						<text class="a-font-sm a-text-white">{{$t('采购')}}</text>
					</view>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 18
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	import Countdown from "@/components/Countdown";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow,
		  Countdown
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				orderoutTime:172800000,//48小时
				isMP:false,
				isLogin:false,
				
				indexPayStatus:0,
				payStatus: [],
				indexOrderStatus:0,
				orderStatus: [],
				
				//
				tabs:[],
				// 当前标签索引
				curTab: 0,
				
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
				timeout:48,
				options:{
					payStatus:'',
					status:''
				}
			}
		},
		onShow() {
			this.gettimeout()
			this.onRefreshList()
			App.getOrderNoPushNum()
			this.tabs = [{
				name: this.$t('全部'),
				value: ''
			}, {
				name: this.$t('待采购'),
				value: 0
			}, {
				name: this.$t('已采购'),
				value: 1
			}]
			this.payStatus = [
			  {
				label: this.$t('全部'),
				value: null,
			  },
			  {
				label: this.$t('已支付'),
				value: "1",
			  },
			  {
				label: this.$t('未支付'),
				value: "0",
			  },
			]
			this.orderStatus = [
			  {
				label: this.$t('全部'),
				value: null,
			  },
			  {
				label: this.getOrderStatus(0),
				value: "0",
			  },
			  {
				label: this.getOrderStatus(1),
				value: "1",
			  },
			  {
				label: this.getOrderStatus(2),
				value: "2",
			  },
			  {
				label: this.getOrderStatus(3),
				value: "3",
			  },
			  {
				label: this.getOrderStatus(4),
				value: "4",
			  },
			  {
				label: this.getOrderStatus(5),
				value: "5",
			  },
			  {
				label: this.getOrderStatus(6),
				value: "6",
			  },
			]
		},
		methods: {
			gettimeout(){
				let that=this;
				let params={
					code:"mall_order_purch_time_out",
					
				}
				Api.getSysParaService(params).then(result =>{
					let timeout=result.data.mall_order_purch_time_out;
					if (timeout==''||timeout==null){
						timeout=72;
						
					}
					
					that.orderoutTime=timeout*60*60*1000
					
						
						
				})
				
			},
			// 切换标签项
			onChangeTab(index) {
				const that = this
				// 设置当前选中的标签
				that.curTab = index
				// that.indexPayStatus = 0
				// that.indexOrderStatus = 0
				// that.options.payStatus = ''
				// that.options.status = ''
				// 刷新订单列表
				that.onRefreshList()
			},
			// 获取当前标签项的值
			getTabValue() {
			  const app = this
			  return app.tabs.length ? app.tabs[app.curTab].value : ''
			},
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						pageNum:pageNo,
						pageSize:pageSize,
						purchStatus:that.getTabValue(),
					};
					console.log(params)
					if(that.options.payStatus){
						params.payStatus = that.options.payStatus
					}
					if(that.options.status){
						params.status = that.options.status
					}
					Api.orderList(params).then(result =>{
						const newList = result.data
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			
			getOrderStatus(status) {
			  let obj = {
			    '-1': "订单已取消",
			    0: "等待买家付款",
			    1: "买家已付款",
			    2: "供应商已接单",
			    3: "物流运输中",
			    4: "买家已签收",
			    5: "订单已完成",
			    6: "已退款"
			  };
			
			  return this.$t(obj[status]);
			},
			changePayStatus(e){
				this.indexPayStatus = e.detail.value
				this.options.payStatus = this.payStatus[this.indexPayStatus].value
				this.onRefreshList()
				
			},
			changeOrderStatus(e){
				this.indexOrderStatus = e.detail.value
				this.options.status = this.orderStatus[this.indexOrderStatus].value
				this.onRefreshList()
			},
			
			getTimeStatus(time,currstyemTime){
				
			
				let that=this;
				

			  var timestamp =new Date(time.replace(/-/g,'/'))
			  var time1 = timestamp.getTime()
			//  var time2 = time1+259200000
			var time2 = time1+that.orderoutTime
			
			  // var time3 = new Date().getTime()
			  var currstyemTimestamp = new Date(currstyemTime.replace(/-/g,'/'))
			//  new Date(currstyemTime)
			  var time3 = currstyemTimestamp.getTime()
			  if(time2>time3){
			    return time2
			  }else{
			    return false
			  }
			},
			/**
			 * 倒计时
			 */
			countdown(time,currstyemTime,type){
				let that=this;
			  var timestamp = new Date(time.replace(/-/g,'/'))
			//  new Date(time)
			  var time1 = timestamp.getTime()
			  var time2 = time1+that.orderoutTime
			  // var time3 = new Date().getTime()
			  var currstyemTimestamp =  new Date(currstyemTime.replace(/-/g,'/'))
		//	  new Date(currstyemTime)
			  var time3 = currstyemTimestamp.getTime()
			  var times = (time2-time3)/1000
			  if(type=="day"){
			  	var day = Math.floor(times / (60 * 60 * 24))
			  	return day
			  }if(type=="hour"){
			  	var hour = Math.floor(times / (60 * 60) % 24)
			  	return hour
			  }else if(type=="minute"){
			  	var minute = Math.floor(times / 60 % 60)
			  	return minute
			  }else if(type=="second"){
			  	var second = Math.floor(times % 60)
			  	return second
			  }
			}
		}
	}
</script>

<style>

</style>
