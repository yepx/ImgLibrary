<template>
	<view class="a-w-750 a-overflow-hidden">
		<view class=" transitionBackgroundColor a-bg-primary">
			<view class="a-w-750" :style="'height:'+globalData.statusBar+'px;'"></view>
			<view class="a-mx-4 a-h-170 a-flex a-align-center a-justify-between">
				<view class="a-flex a-align-center">
					<view class="a-mr-2">
						<image class="a-w-80 a-h-80 a-rounded-circle a-border a-border-white" :src="sellerInfo.avatar?sellerInfo.avatar:globalData.imgUrl+'/default-avatar.png'"></image>
					</view>
					<text class="a-font-lg a-text-white ">{{sellerInfo.name?sellerInfo.name:'Store Name'}}</text>
					<view v-if="!isSellerLevel" class="a-ml-2">
						<image class="a-w-40 a-h-40" :src="getLevelIcon(sellerInfo.mallLevel)"></image>
					</view>
				</view>
				<view class="a-flex a-align-center">
					<view  @click="customerServiceGo" class="a-position-relative">
						<text class="iconfonts icon-a-xingzhuangjiehe2x a-text-white a-font-max-one"></text>
						<view v-if="globalData.chatNumber" style="min-width:30rpx;top:-10rpx;" class="a-px a-h-30 a-position-absolute a-right-0 a-bg-red a-rounded-circle a-flex a-align-center a-justify-center">
							<text class="a-font-min a-text-white">{{globalData.chatNumber>99?'99+':globalData.chatNumber}}</text>
						</view>
					</view>
					<view  @click="$navTo('pages/mine/message')" class="a-position-relative">
						<text class="iconfonts icon-xiaoxi1 a-text-white a-font-max-one a-ml-3"></text>
						<view v-if="globalData.messageNumber" style="min-width:30rpx;top:-10rpx;" class="a-px a-h-30 a-position-absolute a-right-0 a-bg-red a-rounded-circle a-flex a-align-center a-justify-center">
							<text class="a-font-min a-text-white">{{globalData.messageNumber>99?'99+':globalData.messageNumber}}</text>
						</view>
					</view>
				</view>
			</view>
			<view v-if="active<3" class="a-flex a-align-center a-justify-between a-mx-5 step-content-item">
					<view class="a-flex-1 a-flex-column a-align-center a-justify-center item a-position-relative" :class="active>=1?'active':''">

					<view class="icon"></view>
					<view class="a-mt-1">
						<text class="a-font-sm a-text-white">{{$t('店铺设置')}}</text>
					</view>
				</view>
								<view class="a-flex-1 a-flex-column a-align-center a-justify-center item a-position-relative" :class="active>=2?'active':''">

					<view class="icon"></view>
					<view class="a-mt-1">
						<text class="a-font-sm a-text-white">{{$t('店铺认证')}}</text>
					</view>
				</view>
				<view class="a-flex-1 a-flex-column a-align-center a-justify-center item a-position-relative" :class="active==3?'active':''">
					<view class="icon"></view>
					<view class="a-mt-1">
						<text class="a-font-sm a-text-white">{{$t('上架商品')}}</text>
					</view>
				</view>
			</view>
			
			<view v-if="active<3" class="a-w-690 a-bg-white a-rounded a-flex-column a-align-center a-justify-center a-py-3 a-px-5 a-m-3">
				<view @click="intoPage" class="a-px-5 a-py-1 a-bg-primary a-rounded a-mt-2">
					<text class="a-font-sm a-text-white">{{active==0?$t('立即设置'):active==1?$t('查看认证'):active==2?$t('上架商品'):''}}</text>
				</view>
			</view>
		</view>
		<view class="a-position-relative a-mb-3">
			<view class="a-w-750 a-position-absolute a-bg-primary a-h-80">
			</view>
			
			<view class="a-bg-white a-rounded a-flex a-align-center a-justify-between a-position-relative a-py-3 a-px-5 a-mx-3">
				<view class="a-flex-1">
					<view class="a-flex a-align-center">
						<FormatNumberShow class="a-font-max-two a-font-weight-bold a-text-primary" :data="sellerHead.totalSales" :currency="true"/>
					</view>
					<view class="a-flex a-align-center a-justify-center a-mt-2">
						<image class="a-w-25 a-h-25 a-mr" :src="globalData.imgUrl+'/images/ico-salesVolume.png'"></image>
						<text class="a-font-sm a-text-gray">{{$t('总销售额')}}</text>
					</view>
				</view>
				<view class="a-h-50 a-w-1 a-border-left a-border-light a-mx-4"></view>
				<view class="a-flex-1">
					<view class="a-flex a-align-center">
						<FormatNumberShow class="a-font-max-two a-font-weight-bold a-text-primary" :data="sellerHead.totalProfit" :currency="true"/>
					</view>
					<view class="a-flex a-align-center a-justify-center a-mt-2">
						<image class="a-w-25 a-h-25 a-mr" :src="globalData.imgUrl+'/images/ico-profit.png'"></image>
						<text class="a-font-sm a-text-gray">{{$t('总利润')}}</text>
					</view>
				</view>
			</view>
		</view>
		
		<view class="a-mx-3 a-bg-white a-rounded a-mb-3 a-p-3">
			<view>
				<text class="a-font a-font-weight-bold">{{$t('今日数据')}}</text>
			</view>
			<view class="a-mt-3 a-flex a-align-center a-justify-between">
				<view style="min-height:130rpx;" class=" a-flex-1 a-p-2 a-bg-gray a-rounded a-flex a-align-center a-justify-between a-mr-1-5">
					<view class="a-flex-column">
						<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.visits1Today"/>
						
						<text class="a-font-sm a-text-gray a-mt-1">{{$t('今日访客')}}</text>
					</view>
					<view class="a-w-50 a-h-50 a-bg-white a-rounded-circle a-flex a-align-center a-justify-center">
						<image class="a-w-50 a-h-50" :src="globalData.imgUrl+'/images/ico-data1.png'"></image>
					</view>
				</view>
				<view style="min-height:130rpx;" class=" a-flex-1 a-p-2 a-bg-gray a-rounded a-flex a-align-center a-justify-between a-ml-1-5">
					<view class="a-flex-column">
						<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.visits7Today"/>
						<text class="a-font-sm a-text-gray a-mt-1">{{$t('7日访客')}}</text>
					</view>
					<view class="a-w-50 a-h-50 a-bg-white a-rounded-circle a-flex a-align-center a-justify-center">
						<image class="a-w-50 a-h-50" :src="globalData.imgUrl+'/images/ico-data2.png'"></image>
					</view>
				</view>
			</view>
			<view class="a-mt-3 a-flex a-align-center a-justify-between">
				<view style="min-height:130rpx;" class=" a-flex-1 a-p-2 a-bg-gray a-rounded a-flex a-align-center a-justify-between a-mr-1-5">
					<view class="a-flex-column">
						<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.visits30Today"/>
						<text class="a-font-sm a-text-gray a-mt-1">{{$t('30日访客')}}</text>
					</view>
					<view class="a-w-50 a-h-50 a-bg-white a-rounded-circle a-flex a-align-center a-justify-center">
						<image class="a-w-50 a-h-50" :src="globalData.imgUrl+'/images/ico-data3.png'"></image>
					</view>
				</view>
				<view style="min-height:130rpx;" class=" a-flex-1 a-p-2 a-bg-gray a-rounded a-flex a-align-center a-justify-between a-ml-1-5">
					<view class="a-flex-column">
						<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.todayOrder"/>
						<text class="a-font-sm a-text-gray a-mt-1">{{$t('今日售出订单')}}</text>
					</view>
					<view class="a-w-50 a-h-50 a-bg-white a-rounded-circle a-flex a-align-center a-justify-center">
						<image class="a-w-50 a-h-50" :src="globalData.imgUrl+'/images/ico-data4.png'"></image>
					</view>
				</view>
			</view>
			<view class="a-mt-3 a-flex a-align-center a-justify-between">
				<view style="min-height:130rpx;" class=" a-flex-1 a-p-2 a-bg-gray a-rounded a-flex a-align-center a-justify-between a-mr-1-5">
					<view class="a-flex-column">
						<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.todaySales"/>
						<text class="a-font-sm a-text-gray a-mt-1">{{$t('今日总销售额')}}</text>
					</view>
					<view class="a-w-50 a-h-50 a-bg-white a-rounded-circle a-flex a-align-center a-justify-center">
						<image class="a-w-50 a-h-50" :src="globalData.imgUrl+'/images/ico-data5.png'"></image>
					</view>
				</view>
				<view style="min-height:130rpx;" class=" a-flex-1 a-p-2 a-bg-gray a-rounded a-flex a-align-center a-justify-between a-ml-1-5">
					<view class="a-flex-column">
						<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.todayProfit" :currency="true"/>
						<text class="a-font-sm a-text-gray a-mt-1">{{$t('预计利润')}}</text>
					</view>
					<view class="a-w-50 a-h-50 a-bg-white a-rounded-circle a-flex a-align-center a-justify-center">
						<image class="a-w-50 a-h-50" :src="globalData.imgUrl+'/images/ico-data6.png'"></image>
					</view>
				</view>
			</view>
		</view>
		<view class="a-mx-3 a-bg-white a-rounded a-mb-3 a-py-3 a-position-relative a-overflow-hidden">
			<view class="a-px-3 a-flex a-position-relative" style="z-index:9">
				<view class="a-px-2 a-py a-rounded a-mr-1" @click="changeSellerLine(0)" :class="sellerLineCurrent == 0?'a-bg-primary':'a-bg-gray'">
					<text class="a-font-sm " :class="sellerLineCurrent == 0?'a-text-white':'a-text-gray'">{{$t('今日')}}</text>
				</view>
				<view class="a-px-2 a-py a-rounded a-mr-1" @click="changeSellerLine(1)"  :class="sellerLineCurrent == 1?'a-bg-primary':'a-bg-gray'" >
					<text class="a-font-sm " :class="sellerLineCurrent == 1?'a-text-white':'a-text-gray'">{{$t('近7日')}}</text>
				</view>
				<view class="a-px-2 a-py a-rounded" @click="changeSellerLine(2)" :class="sellerLineCurrent == 2?'a-bg-primary':'a-bg-gray'">
					<text class="a-font-sm " :class="sellerLineCurrent == 2?'a-text-white':'a-text-gray'">{{$t('近30日')}}</text>
				</view>
			</view>
			<view class="a-w-680" v-if="isChartshow" style="margin-top:-40rpx;">
				<qiun-data-charts type="line" :opts="optsUserTrend" :ontouch="true" :chartData="chartDataUserTrend"/>
			</view>
			
		</view>
		<view class="a-mx-3 a-bg-white a-rounded a-mb-3 a-py-3 a-flex a-flex-wrap a-align-center">
			<view @click="$navTo('pages/mine/settingShop')" class="a-w-230 a-flex-column a-align-center a-justify-center a-py-2">
				<image class="a-w-60 a-h-60" :src="globalData.imgUrl+'/images/ico-setting.png'"></image>
				<text class="a-font-sm a-mt-1 a-text-center a-text-ellipsis-1">{{$t('店铺设置')}}</text>
			</view>
			<view @click="$navTo('pages/mine/refundRequest')" class="a-w-230 a-flex-column a-align-center a-justify-center a-py-2">
				<image class="a-w-60 a-h-60" :src="globalData.imgUrl+'/images/ico-refuse.png'"></image>
				<text class="a-font-sm a-mt-1 a-text-center a-text-ellipsis-1">{{$t('退款订单')}}</text>
			</view>
			<view @click="$navTo('pages/mine/marketing')" class="a-w-230 a-flex-column a-align-center a-justify-center a-py-2">
				<image class="a-w-60 a-h-60" :src="globalData.imgUrl+'/images/ico-exposure.png'"></image>
				<text class="a-font-sm a-mt-1 a-text-center a-text-ellipsis-1">{{$t('店铺直通车')}}</text>
			</view>
			<view v-if="false" @click="$navTo('pages/mine/promotion')" class="a-w-230 a-flex-column a-align-center a-justify-center a-py-2">
				<image class="a-w-60 a-h-60" :src="globalData.imgUrl+'/images/ico-alliance.png'"></image>
				<text class="a-font-sm a-mt-1 a-text-center a-text-ellipsis-1">{{$t('创业联盟')}}</text>
			</view>
			<view v-if="false" @click="$navTo('pages/mine/rechargeList')" class="a-w-230 a-flex-column a-align-center a-justify-center a-py-2">
				<image class="a-w-60 a-h-60" :src="globalData.imgUrl+'/images/ico-recharge.png'"></image>
				<text class="a-font-sm a-mt-1 a-text-center a-text-ellipsis-1">{{$t('充值')}}</text>
			</view>
			<view v-if="false" @click="$navTo('pages/mine/withdraw')" class="a-w-230 a-flex-column a-align-center a-justify-center a-py-2">
				<image class="a-w-60 a-h-60" :src="globalData.imgUrl+'/images/ico-withdraw.png'"></image>
				<text class="a-font-sm a-mt-1 a-text-center a-text-ellipsis-1">{{$t('提现')}}</text>
			</view>
			<view  @click="$navTo('pages/mine/sellerLevel')" class="a-w-230 a-flex-column a-align-center a-justify-center a-py-2">
				<image class="a-w-60 a-h-60" :src="globalData.imgUrl+'/images/ico-level.png'"></image>
				<text class="a-font-sm a-mt-1 a-text-center a-text-ellipsis-1">{{$t('卖家等级')}}</text>
			</view>
		</view>
		<view class="a-flex a-align-center a-justify-between a-bg-white a-p-3 a-rounded a-mx-3 a-mb-3">
			<view class="a-flex a-align-center">
				<image class="a-w-60 a-h-60 a-mr-2" :src="globalData.imgUrl+'/images/ico-follow.png'"></image>
				<text class="a-font">{{$t('店铺关注')}}</text>
			</view>
			<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.focusCount"/>
		</view>
		<view class="a-flex a-align-center a-justify-between a-bg-white a-p-3 a-rounded a-mx-3 a-mb-3">
			<view class="a-flex a-align-center">
				<image class="a-w-60 a-h-60 a-mr-2" :src="globalData.imgUrl+'/images/ico-star.png'"></image>
				<text class="a-font">{{$t('店铺评分')}}</text>
			</view>
			<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.rating"/>
		</view>
		<view class="a-flex a-align-center a-justify-between a-bg-white a-p-3 a-rounded a-mx-3 a-mb-3">
			<view class="a-flex a-align-center">
				<image class="a-w-60 a-h-60 a-mr-2" :src="globalData.imgUrl+'/images/ico-credit.png'"></image>
				<text class="a-font">{{$t('卖家信用分')}}</text>
				<text @click="$navTo('pages/webView/webView?title='+$t('卖家政策')+'&url='+ globalData.mobileUrl+'/promote/#/shippingPolicy?lang='+globalData.langeuage)" class="iconfonts icon-wenhao-yuankuang a-font a-text-gray a-ml-1"></text>
			</view>
			<FormatNumberShow class="a-font-max a-font-weight-bold" :data="sellerHead.creditScore"/>
		</view>
		<view class="a-flex a-flex-wrap a-align-center a-justify-between a-mx-3">
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(92, 157, 255);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('总订单')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<text class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2">{{sellerStats.orderNum}}</text>
				</view>
			</view>
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(255, 128, 73);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('进行中')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<text class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2">{{sellerStats.orderIng}}</text>
				</view>
			</view>
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(63, 188, 143);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('已完成')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<text class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2">{{sellerStats.orderFinish}}</text>
				</view>
			</view>
			<view class="a-w-330 a-bg-primary a-rounded a-h-170 a-position-relative a-mb-3" style="background-color: rgb(93, 106, 126);">
				<view class="a-p-2">
					<text class="a-font a-text-white">{{$t('取消订单')}}</text>
				</view>
				<view class="transparency-white-1 a-rounded-circle a-w-140 a-h-140 a-position-absolute" style="top:-75rpx;right:-75rpx;"></view>
				<view class="a-w-330 a-h-80 a-position-absolute a-bottom-0 a-left-0 a-flex a-align-center a-justify-end">
					<image class="a-w-330 a-h-80 a-position-absolute a-right-0" :src="globalData.imgUrl+'/images/bg-order.png'"></image>
					<text class="a-font-max a-font-weight-bold a-text-white a-position-relative a-mr-2">{{sellerStats.orderCancel}}</text>
				</view>
			</view>
		</view>
		
		<view class="a-mb-3">
			<view class="a-mx-3">
				<text class="a-font">{{$t('您的类别')}}({{sellerCate.length}})</text>
			</view>
			<view class="a-mt-2" style="height: 9.375rem;">
				<scroll-view scroll-x>
					<view class="a-flex">
						<view v-for="(item,index) in sellerCate" :key="index" @click="$navTo('pages/product/class?name='+item.name+'&categoryId='+item.categoryId+'&sellerId='+sellerInfo.id)" class="a-w-240 a-h-240 a-ml-3 a-position-relative">
							<image class="a-w-240 a-h-240 a-rounded" mode="aspectFill" :src="item.iconImg"></image>
							<view class="a-w-240 a-h-240 a-rounded transparency-black-4 a-flex-column a-align-center a-justify-center a-position-absolute a-top-0 a-left-0">
								<text class="a-text-white a-font-sm">{{item.name}}</text>
								<text class="a-text-white a-font-sm">({{item.goodCount}})</text>
							</view>
						</view>
					</view>
				</scroll-view>
			</view>
		</view>
		
		<view class="a-mb-3">
			<view class="a-mx-3">
				<text class="a-font">{{$t('热销商品')}} TOP 10</text>
			</view>
			<view class="a-mx-3">
				<view v-for="(item,index) in sellerGoods" :key="index" @click="$navTo('pages/product/detail',item)" class="a-bg-white a-rounded a-mt-3 a-p-2 a-flex">
					<view class="a-mr-3">
						<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="item.imgUrl1"></image>
					</view>
					<view class="a-flex-column a-justify-between">
						<text class="a-font a-text-ellipsis-2">{{item.name}}</text>
						<view class='a-flex a-align-center'>
							<text class="a-font-sm a-text-gray">{{$t('浏览')}}:</text>
							<FormatNumberShow class="a-font-sm a-text-gray a-mr-2" :data="item.viewsNum"/>
							<text class="a-font-sm a-text-gray ">{{$t('销量')}}:</text>
							<FormatNumberShow class="a-font-sm a-text-gray " :data="item.soldNum"/>
						</view>
						<view class="a-flex a-align-center a-mt">
							<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.sellingPrice" :currency="true"/>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="placeholderH5"></view>
		
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	const innerAudioContext = uni.createInnerAudioContext()
	import levela from '@/static/images/level/a.png'
	import levelb from '@/static/images/level/b.png'
	import levelc from '@/static/images/level/c.png'
	import levelo from '@/static/images/level/o.png'
	import levels from '@/static/images/level/s.png'
	import levelss from '@/static/images/level/ss.png'
	import levelsss from '@/static/images/level/sss.png'
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				customer_service_url:null,
				active: 4,
				show: false,
				isChartshow:false,
				isFirst:true,
				levela,
				levelb,
				levelc,
				levelo,
				levels,
				levelss,
				levelsss,
				isSellerLevel:false,
				runInterval:null,
				
				userInfo:{},
				walletInfo:{},
				sellerInfo:{},
				sellerHead:{},
				sellerLineCurrent:2,
				sellerLine:{},
				sellerStats:{},
				sellerCate:[],
				sellerGoods:[],
				
				//chart
				chartDataUserTrend: {
					series:[
						{
							name: this.$t('销量'),
							data: []
						},
						{
							name: this.$t('浏览'),
							data: []
						}
					],
				},
				optsUserTrend:{
					enableScroll:true,
					dataPointShapeType:'hollow',
					legend:{
						show:true,
						position:'top',
						float:'left',
						margin:20,
						
					},
					color:["#1552f0","#666666"],
					extra:{
						line:{
							type:'curve'
						}
					},
					xAxis:{
						itemCount:6,
						scrollAlign: "right",
					}
				},
			}
		},
		onLoad(){
			
			
			
		},
		onShow() {
			this.isChartshow = true
			this.isLogin = checkLogin()
			
			if(!this.isLogin){
				this.$navTo('pages/login/index')
				return
			}
			
			this.getSellerGoods()
			App.getOrderNoPushNum()
			this.getSellerInfo()
			this.getSysPara()
			this.runSetInterval()
		
			
		},
		onHide() {
			this.isChartshow =false
			clearInterval(this.runInterval)
			this.runInterval=null
		},
		destroyed() {
			this.isChartshow =false
			clearInterval(this.runInterval)
			this.runInterval=null
		},
		methods: {
			getSysPara() {
			  Api.getSysParaService({
			    code: 'customer_service_url'
			  }).then(res => {
			    this.customer_service_url = res.data.customer_service_url
			  })
			},
			customerServiceGo(){
				if(this.customer_service_url){
					window.open(this.customer_service_url, "_blank");

					
					
				}else{
					this.$navTo('pages/customerService/index')
				}
			},
			playerMusic(){
				innerAudioContext.src ='/static/message.mp3';
				innerAudioContext.volume = 0.5
				innerAudioContext.loop = true
				innerAudioContext.startTime = 0
				innerAudioContext.play()
				this.isFirst = false
				setTimeout(res=>{
					innerAudioContext.pause()
				},800)
			},
			getLevelIcon(mallLevel) {
			  switch (mallLevel) {
			    case 'A':
			      return this.levela
			    case 'B':
			      return this.levelb
			    case 'C':
			      return this.levelc
			    case 'O':
			      return this.levelo
			    case 'S':
			      return this.levels
			    case 'SS':
			      return this.levelss
			    case 'SSS':
			      return this.levelsss
			    default:
			      return this.levelo
			  }
			},
			getActive() {
			  let active = 0
			if (this.sellerInfo.sellerSettingFlag === "0") {
						    active = 0
				} else if (this.sellerInfo.onShelvesFlag === "1") {

			    active = 3
			  } else if (this.sellerInfo.sellerKycFlag === "1") {
			    active = 2
			  } else if (this.sellerInfo.sellerSettingFlag === "1") {
			    active = 1
			  }
			  this.active = active;
			  console.log(this.active)
			},
			intoPage() {
			  switch (this.active) {
			    case 0:
					 this.$navTo('pages/mine/shopInfo')

			      break;
			    case 1:
			      this.$navTo('pages/mine/auth')
			      break;
			    case 2:
			      this.$navTo('pages/main/product')
			      break;
			  }
			},
			changeSellerLine(type){
				this.sellerLineCurrent = type
				this.chartDataUserTrend = {
					series:[
						{
							name: this.$t('销量'),
							data: []
						},
						{
							name: this.$t('浏览'),
							data: []
						}
					],
				},
				uni.showLoading()
				this.getSellerLine()
			},
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
					this.getActive()
					that.getSellerHead()
					that.getSellerLine()
					that.getSellerStats()
					that.getSellerCate()
				});
			},
			getSellerGoods() {
				var that = this;
				Api.sellerGoods({isHot:1,pageNum:1,pageSize:10}).then(res => {
					const {status,message,data} = res;
					that.sellerGoods = res.data.pageList
				});
			},
			getSellerHead() {
				var that = this;
				Api.sellerHead({sellerId:that.sellerInfo.id}).then(res => {
					const {status,message,data} = res;
					that.sellerHead = res.data.head
				});
			},
			getSellerCate() {
				var that = this;
				Api.sellerCate({sellerId:that.sellerInfo.id}).then(res => {
					const {status,message,data} = res;
					that.sellerCate = res.data
				});
			},
			getSellerStats() {
				var that = this;
				Api.sellerStats({sellerId:that.sellerInfo.id}).then(res => {
					const {status,message,data} = res;
					that.sellerStats = res.data.stats
				});
			},
			getSellerLine() {
				var that = this;
				Api.sellerLine({type: this.sellerLineCurrent,sellerId:that.sellerInfo.id}).then(res => {
					const {status,message,data} = res;
					that.sellerLine = res.data
					that.setTrendData(res.data)
				});
			},
			//定时
			runSetInterval(){
				this.runInterval = setInterval(() => {
					this.getMessageNumber()
					this.getChatNumber()
				}, 5000)
			},
			getMessageNumber() {
				var that = this;
				Api.messageNumber({type:3}).then(res => {
					const {status,message,data} = res;
					that.globalData.messageNumber = res.data.count
					if(this.globalData.messageNumber && this.isFirst){
						this.playerMusic()
					}
				});
			},
			getChatNumber() {
				var that = this;
				Api.chatNumber({type:3}).then(res => {
					const {status,message,data} = res;
					that.globalData.chatNumber = res.data
					if(this.globalData.chatNumber && this.isFirst){
						this.playerMusic()
					}

				});
			},
			
			
			
			setTrendData(data) {
				setTimeout(() => {
					var detailList = data.line
					var countVisits = detailList.map((item) => {
						return item.countVisits
					})
					var countSales = detailList.map((item) => {
						return item.countSales
					})
					var dayString = detailList.map((item) => {
						if(this.sellerLineCurrent==0){
							return item.dayString
						}else{
							var array = item.dayString.split('-');
							return array[1]+'-'+array[2]
						}
					})
					let res = {
						categories: dayString,
						series: [
							{
								name: this.$t('销量'),
								data: countSales
							},
							{
								name: this.$t('浏览'),
								data: countVisits
							}
						]
					};
					uni.hideLoading()
					this.chartDataUserTrend = JSON.parse(JSON.stringify(res));
										
				}, 100);
			},
		}
	}
</script>

<style lang="scss">
.step-content-item .item:before,.step-content-item .item:after {
    content: "";
    display: block;
    width: calc((100% - 32px)/2);
    height: 2px;
    background-color: rgba(255,255,255,.4);
    position: absolute;
    top: 12px
}

.step-content-item .item:before {
    left: 0;
    border-top-right-radius: 2px;
    border-bottom-right-radius: 2px
}

.step-content-item .item:after {
    right: 0;
    border-top-left-radius: 2px;
    border-bottom-left-radius: 2px
}

.step-content-item .item:first-child:before {
    display: none
}

.step-content-item .item:last-child:after {
    display: none
}

.step-content-item .item.active:after {
    background-color: #fff
}

.step-content-item .item.active .icon:after {
    background-color: #fff
}

.step-content-item .item.active+.item:before {
    background-color: #fff;
}

.step-content-item .item .icon {
    width: 26px;
    height: 26px;
    background-color: rgba(255,255,255,.2);
    border-radius: 50%;
    position: relative
}

.step-content-item .item .icon:after {
    content: "";
    display: block;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background-color: rgba(255,255,255,.5);
    position: absolute;
    top: 6px;
    left: 6px
}
</style>
