<template>
	<view>
		<image class="a-w-750 a-position-absolute a-top-0" mode="aspectFill" :src="globalData.imgUrl+'/images/bg-mine.png'"></image>
		<view class="transitionBackgroundColor">
			<view class="a-w-750" :style="'height:'+globalData.statusBar+'px;'"></view>
			<view class="a-mx-4 a-h-150 a-flex a-align-center a-justify-between a-h-100">
			</view>
		</view>

		<view @click="$navTo('pages/mine/personalInfo')" class="a-mx-3 a-position-relative a-flex a-align-center a-mb-3">
			<view class="a-mr-3">
				<image class="a-w-100 a-h-100 a-rounded-circle" mode="aspectFill" :src="`/static/images/avatar/${userInfo.avatar}.png`"></image>
			</view>
			<view>
				<text class="a-font a-font-weight-bold a-text-white">{{getEmail(userInfo.username)}}</text>
				<view class="a-flex a-align-center a-mt-1">
					<text class="a-font-sm a-text-white">ID：{{userInfo.usercode}}</text>
					<text @click.stop="copy(userInfo.usercode)" class="iconfonts icon-fuzhi a-font a-font-weight-bold a-ml-1 a-text-white"></text>
				</view>
			</view>
		</view>
		<view class="a-bg-white a-rounded a-p-3 a-position-relative a-mx-3 a-mb-3">
			<view>
				<FormatNumberShow class="a-font-max a-font-weight-bold" :data="walletInfo.money" :currency="true"/>
				<text @click="getWalletInfo" class="iconfonts icon-shuaxin a-font a-ml-3"></text>
			</view>
			<view class="a-border-bottom a-border-lighter a-pb-2 a-mb-2 a-mt-1">
				<text class="a-font-sm">{{$t('余额')}}</text>
			</view>
			
			<view class="">
				<text class="a-font-sm ">{{$t('累计收益')}}：</text>
				<FormatNumberShow class="a-font-max" :data="walletInfo.rebate" :currency="true"/>
				<view class="a-flex a-align-center a-justify-between a-mt-2">
					<view @click="$navTo('pages/mine/withdraw')" class="a-rounded a-border a-border-primary a-flex-1 a-mx-2 a-h-60 a-flex a-align-center a-justify-center">
						<text class="a-font-sm a-text-primary">{{$t('提现')}}</text>
					</view>
					<view @click="chongzhiclick" class="a-rounded a-bg-primary a-flex-1 a-mx-2 a-h-60 a-flex a-align-center a-justify-center">
						<text class="a-font-sm a-text-white">{{$t('充值')}}</text>
					</view>
				</view>
			</view>
		</view>
		
		<view v-if="false"  @click="$navTo('pages/mine/invite?usercode='+userInfo.usercode+'&d1='+timeout)" class="a-mb-3 a-mx-3 a-h-200 a-bg-white a-rounded a-position-relative">
			<image class="a-w-690 a-h-200 a-position-absolute a-top-0 a-rounded" mode="aspectFill" :src="globalData.imgUrl+'/images/bg-mine-banner.png'"></image>
			<view class="a-position-relative a-pt-3 a-pl-5" >
				<view>
					<text class="a-font-lg a-text-white a-text-ellipsis-1">{{$t('邀请好友开店')}} <span class="a-font-max a-text-yellow">{{$t('豪礼')}}</span>{{$t('相送')}}</text>
				</view>
				<text class="a-font-min a-text-white a-opacity-7 ">{{$t('累计领取')}}</text>
				<FormatNumberShow class="a-font-min a-text-white a-opacity-7 " :data="sellerInfo.inviteReceivedReward" :currency="true"/>
				<text class="a-font-min a-text-white a-opacity-7 ">,{{$t('可领取')}}</text>
				<FormatNumberShow class="a-font-min a-text-white a-opacity-7 " :data="sellerInfo.inviteAmountReward" :currency="true"/>
				<view class="a-w-150 a-h-40 a-mt-1 a-rounded-circle a-flex a-align-center a-justify-center" style="background:linear-gradient(rgb(255,150,91),rgb(206,57,37))">
					<text class="a-font-min a-text-white">{{$t('邀请')}}</text>
				</view>
			</view>
		</view>
		
		<view class="a-mb-3 a-mx-3 a-bg-white a-px-2 a-rounded a-position-relative">
			<view @click="$navTo('pages/mine/personalInfo')" class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<view class="a-w-30 a-flex a-align-center a-justify-center a-mr-1">
						<text class="iconfonts icon-wode a-font-max"></text>
					</view>
					<text class="a-font-sm">{{$t('个人信息')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/language')" class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<view class="a-w-30 a-flex a-align-center a-justify-center a-mr-1">
						<text class="iconfonts icon-yuyan a-font-lg"></text>
					</view>
					<text class="a-font-sm">{{$t('语言')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="a-font-sm a-text-gray a-mr-2">{{languageText}}</text>
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/refundRequest')" class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<view class="a-w-30 a-flex a-align-center a-justify-center a-mr-1">
						<text class="iconfonts icon-waibiduihuan a-font-max-one"></text>
					</view>
					<text class="a-font-sm">{{$t('退款申请')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
		</view>
		
		<view class="a-mb-3 a-mx-3 a-bg-white a-px-2 a-rounded a-position-relative">
			<view @click="$navTo('pages/mine/fundsRecord')" class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<view class="a-w-30 a-flex a-align-center a-justify-center a-mr-1">
						<text class="iconfonts icon-switch a-font-max"></text>
					</view>
					<text class="a-font-sm">{{$t('资金记录')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view @click="$navTo('pages/mine/finance')" class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<view class="a-w-30 a-flex a-align-center a-justify-center a-mr-1">
						<text class="iconfonts icon-trending-hangqing a-font-max"></text>
					</view>
					<text class="a-font-sm">{{$t('财务报表')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
			<view v-if='false' @click="$navTo('pages/mine/promotion')" class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<view class="a-w-30 a-flex a-align-center a-justify-center a-mr-1">
						<text class="iconfonts icon-fenxiang2 a-font-max"></text>
					</view>
					<text class="a-font-sm">{{$t('创业联盟')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
		</view>
		<view class="a-mb-3 a-mx-3 a-bg-white a-px-2 a-rounded">
			<view @click="$navTo('pages/mine/setting')" class="a-h-80 a-flex a-align-center a-justify-between a-border-bottom a-border-lighter">
				<view class="a-flex a-align-center">
					<view class="a-w-30 a-flex a-align-center a-justify-center a-mr-1">
						<text class="iconfonts icon-shezhi a-font-max"></text>
					</view>
					<text class="a-font-sm">{{$t('设置')}}</text>
				</view>
				<view class="a-flex a-align-center">
					<text class="iconfonts icon-ai-arrow-down a-font-sm a-text-gray"></text>
				</view>
			</view>
		</view>
		<view class="placeholderH5"></view>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as utils from "@/utils/util";
	import languages from "@/common/js/language.js"
	import FormatNumberShow from "@/components/FormatNumberShow";
	import MyIcon from '@/static/font/svg/bonus.svg';
	export default {
		components: {
		  FormatNumberShow
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				languageText:'',
				userInfo:{},
				walletInfo:{},
				sellerInfo:{},
				timeout:"[]",
			}
		},
		onShow() {
			this.gettimeout()
			this.getUserInfo()
			this.getWalletInfo()
			this.getSellerInfo()
			App.getOrderNoPushNum()
			this.isLanguage()
			this.getSysPara();
		},
		methods: {
			getEmail(email){
				if(email){
					return utils.emailHide(email)
				}else{
					return ''
				}
				
			},
			getPhone(phone){
				if(phone){
					return utils.phoneHide(email)
				}else{
					return ''
				}
				
			},
			isLanguage(){
				var language = uni.getLocale() || "cn";
				console.log(uni.getLocale())
				if (language == 'en-US' || language == '"en-US"') {
					language = 'en'
				} else if (language == 'zh-CN' || language == "'zh-CN'") {
					language = 'cn'
				} else if (language == 'zh-TW' || language == "'zh-TW'") {
					language = 'tw'
				}
				console.log(language)
				let index = languages.findIndex((ele) => {
				    return ele.key === language;
				});
				this.languageText = languages[index].title
			},
			copy(content){
				var that = this
				uni.setClipboardData({
					data: content,
					success: function() {
						uni.showToast({
							title: that.$t('复制成功'),
							duration: 1000
						});
					}
				});
			},
			gettimeout(){
				let that=this;
				let params={
					code:"mall_first_invite_recharge_rewards",
					
				}
				Api.getSysParaService(params).then(result =>{
						that.timeout=result.data.mall_first_invite_recharge_rewards;
						console.log(that.timeout)
					//that.timeout="[[7,1],[15,11]]"

						
				})
				
			},
			getSysPara() {
						  Api.getSysParaService({
						    code: 'customer_service_url'
						  }).then(res => {
						    this.customer_service_url = res.data.customer_service_url
						  })
						},
						

			chongzhiclick(){
				if(this.customer_service_url){
					  window.open(this.customer_service_url, "_blank");
					
				}else{
					this.$navTo('pages/mine/rechargeList')
				}
				
				
				
			},
			// 个人信息
			getUserInfo() {
				const that = this
				Api.info().then(result =>{
					that.userInfo = result.data
				})
			},
			// 钱包
			getWalletInfo() {
				uni.showLoading()
				const that = this
				Api.walletInfo().then(result =>{
					uni.hideLoading()
					that.walletInfo = result.data
				})
			},
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
				});
			},
		}
	}
</script>

<style>

</style>
