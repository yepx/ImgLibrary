<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view class=" transitionBackgroundColor a-mb-3">
			<view class="a-w-750" :style="'height:'+globalData.statusBar+'px;'"></view>
			<view class="a-mx-4 a-h-110 a-flex a-align-end">
				<view @click="$navTo('pages/search/product')" class="a-flex-1 a-h-80 a-px-3 a-bg-white a-rounded-circle a-flex a-align-center a-justify-between">
					<text class="iconfonts icon-sousuo a-font-max-two a-text-gray"></text>
					<text class="a-flex-1 a-text-center a-text-gray-light a-font">{{$t('请输入搜索商品名称')}}</text>
				</view>
			</view>
		</view>
		<view class="a-position-relative a-mb-3">
			<view class="a-bg-white a-rounded a-flex a-align-center a-justify-between a-py-3 a-px-5 a-mx-3">
				<view class="a-flex-1">
					<view class="a-flex a-align-center a-justify-center">
						<text class="a-font-max-one a-font-weight-bold ">{{systemGoodsNum}}</text>
					</view>
					<view @click="$navTo('pages/product/list')" class="a-flex a-align-center a-justify-center a-mt-2">
						<text class="a-font-sm a-text-gray a-mr">{{$t('商品库')}}</text>
						<text class="iconfonts icon-ai-arrow-down a-font-min a-text-gray"></text>
					</view>
				</view>
				<view class="a-h-50 a-w-1 a-border-left a-border-light a-mx-4"></view>
				<view class="a-flex-1">
					<view class="a-flex a-align-center a-justify-center">
						<text class="a-font-max-one a-font-weight-bold ">{{evaluations}}</text>
					</view>
					<view @click="$navTo('pages/product/comment')" class="a-flex a-align-center a-justify-center a-mt-2">
						<text class="a-font-sm a-text-gray a-mr">{{$t('评论')}}</text>
						<text class="iconfonts icon-ai-arrow-down a-font-min a-text-gray"></text>
					</view>
				</view>
			</view>
		</view>
		
		<view class="a-mb-3">
			<view class="a-mx-3">
				<text class="a-font">{{$t('店铺产品')}}({{sellerGoodsNum}})</text>
			</view>
			<view class="a-mx-3">
				<view v-for="(item,index) in list.data" :key="index" @click="$navTo('pages/product/detail',item)" class="a-bg-white a-rounded a-mt-3 a-p-2 a-flex">
					<view class="a-mr-2 a-w-150 a-h-150 a-position-relative">
						<image class="a-w-150 a-h-150 a-rounded" mode="aspectFill" :src="item.imgUrl1"></image>
						<view class="a-w-150 a-h-150 a-position-absolute a-top-0 a-flex a-align-center a-justify-center">
							<view v-if="!item.isShelf" class="a-w-120 a-h-120 a-border-5 a-border-red a-rounded-circle a-flex a-align-center a-justify-center a-transform-315">
								<text class="a-font a-text-red">{{$t('已下架')}}</text>
							</view>
						</view>
					</view>
					<view class="a-flex-1 a-flex-column a-justify-between">
						<view class="a-flex a-justify-between">
							<text class="a-font a-text-ellipsis-2">{{item.name}}</text>
							<text @click.stop="$navTo('pages/product/edit',item)" class="iconfonts icon-gengduo a-font-max-four a-text-primary a-ml-1"></text>
						</view>
						<view class='a-flex a-align-center'>
							<text class="a-font-sm a-text-gray a-mr-2">{{item.categoryName}}</text>
							<text class="a-font-sm a-text-gray">{{$t('销量')}}:</text>
							<FormatNumberShow class="a-font-sm a-text-gray a-mr-2" :data="item.soldNum"/>
						</view>
						<view class="a-flex a-align-center a-justify-between">
							<view class="a-flex a-align-center">
								<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.sellingPrice" :currency="true"/>
							</view>
							<view v-if="item.discountPrice" class="a-flex a-align-center">
								<text class="a-font a-text-red a-mr">{{$t('折扣价')}}</text>
								<FormatNumberShow class="a-font-lg a-text-red" :data="item.discountPrice" :currency="true"/>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				options:{
					isNew:0,
					isRec:0,
					isPrice:0
				},
				evaluations:0,
				systemGoodsNum:0,
				sellerGoodsNum:0,
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: true,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
			}
		},
		onShow() {
			this.onRefreshList()
			App.getOrderNoPushNum()
		},
		methods: {
			// 刷新订单列表
			onRefreshList() {
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						pageNum:pageNo,
						pageSize:pageSize,
						...that.options
					};
					Api.sellerGoods(params).then(result =>{
						that.evaluations = result.data.evaluations
						that.systemGoodsNum = result.data.systemGoodsNum
						that.sellerGoodsNum = result.data.sellerGoodsNum
						const newList = result.data
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
		}
	}
</script>

<style>

</style>
