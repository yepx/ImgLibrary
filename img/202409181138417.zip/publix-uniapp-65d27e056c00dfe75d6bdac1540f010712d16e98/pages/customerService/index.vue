<template>
	<view>
		<view class="a-w-750">
			<scroll-view class="a-position-absolute a-top-0 a-left-0 a-right-0 " style="bottom:120rpx;" scroll-y="true" :scroll-with-animation="scrollAnimation" :scroll-top="scrollTop" :scroll-into-view="scrollToView" @scrolltoupper="loadHistory" @scroll="scrollimg" @scrolltolower="scrolltolower" upper-threshold="50">
				<!-- 加载历史数据waitingUI -->
				<view class="loading" v-if="isHistoryLoading">
					<view class="spinner">
						<view class="rect1"></view>
						<view class="rect2"></view>
						<view class="rect3"></view>
						<view class="rect4"></view>
						<view class="rect5"></view>
					</view>
				</view>
				<view class="a-p-2" v-for="(row,index) in msgList" :key="index" :id="'msg'+row.id">
					<!-- 系统消息 -->
					<block v-if="row.send_receive=='system'" >
						<view class="a-flex a-align-center a-justify-center">
							<!-- 文字消息 -->
							<text v-if="row.msg.type=='text'" class="a-font-sm">
								{{row.msg.content.text}}
							</text>
						</view>
					</block>
					<!-- 用户消息 -->
					<block v-if="row.send_receive=='send' || row.send_receive=='receive'">
						<!-- 自己发出的消息 -->
						<view class="a-flex a-justify-end" v-if="row.send_receive=='send'">
							<!-- 左-消息 -->
							<view class="a-flex-column a-align-end a-w-750">
								<view class="a-flex a-align-center a-mb-1">
									<text class="a-font-min a-text-gray">{{row.createtime}}</text> 
								</view>
								<!-- 文字消息 -->
								<view v-if="row.type=='text'" class="a-px-2 a-py-1-5 a-bg-brown-light a-rounded a-rounded-bottom-right-0" style="max-width:70%;min-height:50rpx;">
									<rich-text :nodes="row.content"></rich-text>
								</view>
								<!-- 图片消息 -->
								<view v-if="row.type=='img'" class="a-p-2 a-flex a-bg-brown-light a-rounded a-rounded-bottom-right-0" @tap="showPic(row.content)">
									<image :src="row.content" style="max-width:350rpx;max-height:350rpx;" mode="aspectFill" :style="{'width': row.imageWH.w+'px','height': row.imageWH.h+'px'}"></image>
								</view>
								<!-- 图片消息 -->
								<view v-if="row.type=='image'" class="a-p-2 a-flex a-bg-brown-light a-rounded a-rounded-bottom-right-0" @tap="showPic(row.content)">
									<image :src="row.content" style="max-width:350rpx;max-height:350rpx;" mode="aspectFill" :style="{'width': row.imageWH.w+'px','height': row.imageWH.h+'px'}"></image>
								</view>
							</view>
							<!-- 右-头像 -->
							<view class="a-ml-2">
								<image class="a-w-80 a-h-80 a-rounded-circle" :src="sellerInfo.avatar?sellerInfo.avatar:globalData.imgUrl+'/default-avatar.png'"></image>
							</view>
						</view>
						<!-- 别人发出的消息 -->
						<view class="a-flex" v-if="row.send_receive=='receive'">
							<!-- 左-头像 -->
							<view class="a-mr-2">
								<image class="a-w-80 a-h-80 a-rounded-circle" :src="globalData.imgUrl+'/logo.png'"></image>
							</view>
							<!-- 右-用户名称-时间-消息 -->
							<view class="a-flex-column a-align-start a-w-750">
								<view class="a-flex a-align-center a-mb-1">
									<text class="a-font-min a-text-gray">{{row.createtime}}</text>
								</view>
								<!-- 文字消息 -->
								<view v-if="row.type=='text'" class="a-px-2 a-py-1-5 a-bg-white a-rounded a-rounded-bottom-left-0" style="max-width:70%;min-height:50rpx;">
									<rich-text :nodes="row.content"></rich-text>
								</view>
								<!-- 图片消息 -->
								<view v-if="row.type=='img'" class="a-p-2 a-flex a-bg-white a-rounded a-rounded-bottom-right-0" @tap="showPic(row.content)">
									<image :src="row.content"  style="max-width:350rpx;max-height:350rpx;" :style="{'width': row.imageWH.w+'px','height': row.imageWH.h+'px'}"></image>
								</view>
							</view>
						</view>
					</block>
				</view>
			</scroll-view>
		</view>
		<!-- 底部输入栏 -->
		<view class="a-bg-white a-w-750 a-h-120 a-flex a-align-center a-position-fixed a-bottom-0" style="z-index:2;" @touchmove.stop.prevent="discard">
			<view class="a-w-110 a-flex a-align-center a-justify-center" @tap="chooseImage">
				<text class="iconfonts icon-fenghuangxiangmutubiao_tupian a-font-max-five a-text-gray"></text>
			</view>
			<view class="a-flex a-h-90 a-align-center a-flex-1 a-bg-gray-dark a-overflow-hidden">
				<textarea class="a-flex-1 a-px-2" auto-height="true" v-model="textMsg" @focus="textareaFocus" :placeholder="$t('请输入您的消息...')"/>
			</view>
			<view class="a-w-110 a-flex a-align-center a-justify-center" @tap="sendText">
				<text class="iconfonts icon-fasong a-font-max-five a-text-primary"></text>
			</view>
		</view>
	</view>
</template>
<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import * as UploadApi from '@/api/upload'
	import * as utils from "@/utils/util";
	export default {
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				sellerInfo:{},
				//文字消息
				textMsg:'',
				//消息列表
				isHistoryLoading:false,
				scrollAnimation:false,
				scrollTop:0,
				scrollToView:'',
				msgList:[],
				msgImgList:[],
				myuid:0,
				//定时器
				runInterval:null,
				isBottom:true,
			};
		},
		onLoad(options) {
			this.runSetInterval()
			if(options.notoken){
				return
			}
			this.getSellerInfo()
		},
		onHide() {
			clearInterval(this.runInterval)
			this.runInterval=null
			App.globalData.chatNumber = 0
		},
		destroyed() {
			clearInterval(this.runInterval)
			this.runInterval=null
			App.globalData.chatNumber = 0
		},
		methods:{
			scrollimg(){
				this.isBottom=false
			},
			scrolltolower(){
				setTimeout(res=>{
					this.isBottom=true
				},100)
			},
			//定时
			runSetInterval(){
				this.runInterval = setInterval(() => {
					this.getMsgList();
				}, 1000)
			},
			getSellerInfo() {
				var that = this;
				Api.sellerInfo().then(res => {
					const {status,message,data} = res;
					that.sellerInfo = res.data
				});
			},
			getChatList(id){
				var that = this
				var params = {
					show_img:true,
					message_id:id?id:''
				}
				return new Promise((resolve, reject) => {
					Api.serviceChatList(params).then(res => {
						const {status,message,data} = res;
						if(!res.data.length){
							return resolve([])
						}
						var list = res.data
						// 获取消息中的图片,并处理显示尺寸
						for(let i=0;i<list.length;i++){
							if(list[i].type=="img"){
								list[i].imageWH = that.setPicSize(list[i].content);
								that.msgImgList.push(list[i].content);
							}
							if(list[i].type=="image"){
								list[i].imageWH = that.setPicSize(list[i].content);
								that.msgImgList.push(list[i].content);
							}
							if(id){
								that.msgList.unshift(list[i]);
							}
						}
						return resolve(list.reverse())
					});
				});
			},
			// 接受消息(筛选处理)
			screenMsg(msg){
				//从长连接处转发给这个方法，进行筛选处理
				if(msg.send_receive=='system'){
					// 系统消息
					switch (msg.type){
						case 'text':
							this.addSystemTextMsg(msg);
							break;
					}
				}else if(msg.send_receive=='send'||msg.send_receive=='receive'){
					// 用户消息
					switch (msg.type){
						case 'text':
							this.addTextMsg(msg);
							break;
						case 'img':
							this.addImgMsg(msg);
							break;
					}
					
					//非自己的消息震动
					if(msg.send_receive=='receive'){
						console.log('振动');
						uni.vibrateLong();
					}
				}
				this.$nextTick(function() {
					// 滚动到底
					this.scrollToView = 'msg'+msg.id
				});
			},
			
			//触发滑动到顶部(加载历史信息记录)
			loadHistory(e){
				var that = this;
				if(that.isHistoryLoading){
					return ;
				}
				that.isHistoryLoading = true;//参数作为进入请求标识，防止重复请求
				that.scrollAnimation = false;//关闭滑动动画
				let Viewid = that.msgList[0].id;//记住第一个信息ID
				//本地模拟请求历史记录效果
				that.getChatList(Viewid).then(data => {

					//这段代码很重要，不然每次加载历史数据都会跳到顶部
					this.$nextTick(function() {
						this.scrollToView = 'msg'+Viewid;//跳转上次的第一行信息位置
						this.$nextTick(function() {
							this.scrollAnimation = true;//恢复滚动动画
						});
						
					});
					this.isHistoryLoading = false;
					
				})
			},
			// 加载初始页面消息
			getMsgList(){
				var that = this;
				that.scrollAnimation = false;
				that.getChatList().then(data => {
					
					if(this.msgList.length){
						for(var i in data){
							let index = this.msgList.findIndex((ele) => {
							    return ele.id === data[i].id;
							});
							if(index==-1){
								this.msgList.push(data[i])
								// 滚动到底部
								this.$nextTick(function() {
									//进入页面滚动到底部
									if(this.isBottom){
										this.scrollTop = this.scrollTop+99;
									}
								});
							}
						}
					}else{
						this.msgList = data;
						// 滚动到底部
						this.$nextTick(function() {
							//进入页面滚动到底部
							this.scrollTop = 999;
							this.$nextTick(function() {
								this.scrollAnimation = true;
								setTimeout(res=>{
									this.isBottom=true
								},100)
							});
						});
					}
					
					
				})
			},
			//处理图片尺寸，如果不处理宽高，新进入页面加载图片时候会闪
			setPicSize(content){
				// 让图片最长边等于设置的最大长度，短边等比例缩小，图片控件真实改变，区别于aspectFit方式。
				let maxW = uni.upx2px(350);//350是定义消息图片最大宽度
				let maxH = uni.upx2px(350);//350是定义消息图片最大高度
				if(content.w>maxW||content.h>maxH){
					let scale = content.w/content.h;
					content.w = scale>1?maxW:maxH*scale;
					content.h = scale>1?maxW/scale:maxH;
				}
				return content;
			},
			
			// 选择图片发送
			chooseImage(){
				uni.chooseImage({
				    count: 1, 
				    mediaType:['image'],
				    sourceType:['album', 'camera'],
				    success: function (res) {
						var array  = res.tempFiles;
						this.uploadImg(array,res.tempFilePaths[0]);
				    }.bind(this)
				});
			},
			uploadImg(array,url){
				UploadApi.image(array,'customerService').then(result => {
					  this.sendMsg(result[0],'img');
				})
			},
			//获取焦点
			textareaFocus(){
				
			},
			// 发送文字消息
			sendText(){
				if(!this.textMsg){
					return;
				}
				let content = this.textMsg
				this.sendMsg(content,'text');
				this.textMsg = '';//清空输入框
			},
			// 发送消息
			sendMsg(content,type){
				var that = this;
				//实际应用中，此处应该提交长连接，模板仅做本地处理。
				var nowDate = new Date();
				if(that.msgList.length){
					var lastid = that.msgList[that.msgList.length-1].id;
				}else{
					var lastid = 123456788
				}
				lastid++;
				let msg = {type:type,createtime:nowDate.getHours()+":"+nowDate.getMinutes(),id:lastid,content:content,send_receive:'send'}
				// 发送消息
				var params = {
					type:type,
					content:content
				}
				Api.sendServiceChatMsg(params).then(res => {
					const {status,message,data} = res;
					if(res.code == 0){
						// that.screenMsg(msg);
					}else{
						that.$toast(this.$t(res.msg))
					}
				});
			},
			
			// 添加文字消息到列表
			addTextMsg(msg){
				this.msgList.push(msg);
			},
			// 添加图片消息到列表
			addImgMsg(msg){
				msg.imageWH = this.setPicSize(msg.content);
				this.msgImgList.push(msg.content);
				this.msgList.push(msg);
			},
			// 添加系统文字消息到列表
			addSystemTextMsg(msg){
				this.msgList.push(msg);
			},
			sendSystemMsg(content,type){
				if(that.msgList.length){
					var lastid = that.msgList[that.msgList.length-1].id;
				}else{
					var lastid = 123456788
				}
				lastid++;
				let row = {type:type,createtime:nowDate.getHours()+":"+nowDate.getMinutes(),id:lastid,content:content}
				this.screenMsg(row)
			},
			// 预览图片
			showPic(msg){
				uni.previewImage({
					indicator:"none",
					current:msg,
					urls: this.msgImgList
				});
			},
			discard(){
				return;
			}
		}
	}
</script>
<style lang="scss">
.loading{
	//loading动画
	display: flex;
	justify-content: center;
	@keyframes stretchdelay {
		0%, 40%, 100% {
			transform: scaleY(0.6);
		}
		20% {
			transform: scaleY(1.0);
		}
	}
	.spinner {
		margin: 20upx 0;
		width: 60upx;
		height: 100upx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		view {
			background-color: #f06c7a;
			height: 50upx;
			width: 6upx;
			border-radius: 6upx;
			animation: stretchdelay 1.2s infinite ease-in-out;
		}
		.rect2 {
		  animation-delay: -1.1s;
		}
		.rect3 {
		  animation-delay: -1.0s;
		}
		.rect4 {
		  animation-delay: -0.9s;
		}
		.rect5 {
		  animation-delay: -0.8s;
		}
	}
}
</style>