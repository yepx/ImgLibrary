<template>
	<view>
		<mescroll-body ref="mescrollRef" :sticky="true" @init="mescrollInit" :down="{ use: false }" :up="upOption"
		@up="upCallback">
		<view  class="autoFixed a-bg-white transitionBackgroundColor a-mb-3">
			<view class="a-w-750 " :style="'height:'+globalData.statusBar+'px;'"></view>
			<view class="a-h-100 a-flex ">
				<view class="a-flex-1 a-h-100 a-bg-white a-rounded-circle a-flex a-align-center a-justify-between">
					<view @click="back" class="a-w-100 a-h-100 a-flex a-align-center a-justify-center">
						<text class="iconfonts icon-ai-arrow-down a-font-lg a-transform-180"></text>
					</view>
					<text class="iconfonts icon-sousuo a-font-max a-text-gray"></text>
					<input class="a-flex-1 a-pl-2 a-font" v-model="searchText" @confirm="onRefreshList" :placeholder="$t('请输入订单号')" placeholder-class="a-text-gray"/>
					<view @click="onRefreshList" class="a-px-2">
						<text class="a-text-center a-text-gray-light a-font">{{$t('搜索')}}</text>
					</view>
				</view>
			</view>
		</view>
		<view class="a-mb-3 a-mx-3">
			<view v-for="(item,index) in list.data" :key="index" class="a-bg-white a-rounded a-mt-3 a-p-2" @click="$navTo('pages/order/detail?id='+item.id+'&title='+$t('订单详情'))">
				<text class="a-font a-text-ellipsis-2 a-mb-3">{{item.id}}</text>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE6F2 a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('下单日期')}}:</text>
					<text class="a-font-sm a-text-gray">{{item.createTime}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE69D a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('支付状态')}}:</text>
					<text class="a-font-sm" :class="item.payStatus?'a-text-primary':'a-text-red'">{{item.payStatus?$t('买家已付款'):$t('等待买家付款')}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE681 a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('采购状态')}}:</text>
					<text class="a-font-sm a-text-gray">{{item.purchStatus === 0?$t('待采购'):$t('已采购')}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE6DF a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('物流状态')}}:</text>
					<text class="a-font-sm a-text-gray">{{getOrderStatus(item.status)}}</text>
				</view>
				<view class="a-flex a-align-center a-mb-3">
					<text class="iconfonts icon-uniE6F2 a-font-lg a-mr-2"></text>
					<text class="a-font-sm a-text-gray a-mr-2">{{$t('订单超时')}}:</text>
					<text v-if="getTimeStatus(item.createTime,item.currstyemTime) && item.status == 1 && parseInt(item.purchStatus) === 0">
					  <Countdown color="#f56c6c" background-color="#fef0f0" :showDay="false" :day="countdown(item.createTime,item.currstyemTime,'day')" :hour="countdown(item.createTime,item.currstyemTime,'hour')" :minute="countdown(item.createTime,item.currstyemTime,'minute')" :second="countdown(item.createTime,item.currstyemTime,'second')"/>
					</text>
					<text class="a-font-sm a-text-gray" v-else-if="item.status == 1 && parseInt(item.purchStatus) === 0">{{$t('已超时')}}</text>
					<text class="a-font-sm a-text-gray" v-else>-</text>
				</view>
				
				
				
				<view class="a-border-top a-border-light a-pt-2 a-flex a-align-center a-justify-between">
					<view>
						<view class="a-flex a-align-center">
							<FormatNumberShow class="a-font-lg a-font-weight-bold a-text-primary" :data="item.totalCost" :currency="true"/>
						</view>
						<text class="a-font-sm a-text-gray">({{$t('利润')}}</text>
						<FormatNumberShow class="a-font-sm a-text-gray" :data="item.profit" :currency="true"/>
						<text class="a-font-sm a-text-gray">)</text>
					</view>
				</view>
			</view>
		</view>
		</mescroll-body>
	</view>
</template>

<script>
	import MescrollBody from '@/components/mescroll-uni/mescroll-body.vue'
	import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins'
	import { getEmptyPaginateObj, getMoreListData } from '@/core/app'
	const pageSize = 20
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	import FormatNumberShow from "@/components/FormatNumberShow";
	import Countdown from "@/components/Countdown";
	export default {
		components: {
		  MescrollBody,
		  FormatNumberShow,
		  Countdown
		},
		mixins: [MescrollMixin],
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				list: getEmptyPaginateObj(),
				// 上拉加载配置
				upOption: {
					// 首次自动执行
					auto: false,
					// 每页数据的数量; 默认10
					page: { size: pageSize },
					// 数量要大于4条才显示无更多数据
					noMoreSize: 4,
					// 空布局
					empty: { tip: '' }
				},
				searchText:'',
			}
		},
		methods: {
			back(){
				uni.navigateBack()
			},
			// 刷新订单列表
			onRefreshList() {
				if(!this.searchText){
					this.$toast(this.$t('请输入订单号'))
					return
				}
				this.list = getEmptyPaginateObj()
				setTimeout(() => {
					this.mescroll.resetUpScroll()
				}, 120)
			},
			
			/**
			* 上拉加载的回调 (页面初始化时也会执行一次)
			* 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10
			* @param {Object} page
			*/
			upCallback(page) {
				const app = this
				// 设置列表数据
				app.getList(page.num).then(list => {
					const curPageLen = list.pageList.length
					const totalSize = list.pageInfo.totalElements
					app.mescroll.endBySize(curPageLen, totalSize)
				})
				.catch(() => app.mescroll.endErr())
			},
			
			// 获取订单列表
			getList(pageNo = 1) {
				const that = this
				return new Promise((resolve, reject) => {
					var params={
						pageNum:pageNo,
						pageSize:pageSize,
						orderId:that.searchText
					};
					Api.orderList(params).then(result =>{
						const newList = result.data
						newList.data = result.data.pageList
						that.list.data = getMoreListData(newList, that.list)
						resolve(newList)
					})
				})
			},
			
			getOrderStatus(status) {
			  let obj = {
			    '-1': "订单已取消",
			    0: "等待买家付款",
			    1: "买家已付款",
			    2: "供应商已接单",
			    3: "物流运输中",
			    4: "买家已签收",
			    5: "订单已完成",
			    6: "已退款"
			  };
			
			  return this.$t(obj[status]);
			},
			changePayStatus(e){
				this.indexPayStatus = e.detail.value
				this.options.payStatus = this.payStatus[this.indexPayStatus].value
				this.onRefreshList()
				
			},
			changeOrderStatus(e){
				this.indexOrderStatus = e.detail.value
				this.options.status = this.orderStatus[this.indexOrderStatus].value
				this.onRefreshList()
			},
			
			getTimeStatus(time,currstyemTime){
			  var timestamp = new Date(time)
			  var time1 = timestamp.getTime()
			  var time2 = time1+259200000
			  // var time3 = new Date().getTime()
			  var currstyemTimestamp = new Date(currstyemTime)
			  var time3 = currstyemTimestamp.getTime()
			  if(time2>time3){
			    return time2
			  }else{
			    return false
			  }
			},
			/**
			 * 倒计时
			 */
			countdown(time,currstyemTime,type){
			  var timestamp = new Date(time)
			  var time1 = timestamp.getTime()
			  var time2 = time1+259200000
			  // var time3 = new Date().getTime()
			  var currstyemTimestamp = new Date(currstyemTime)
			  var time3 = currstyemTimestamp.getTime()
			  var times = (time2-time3)/1000
			  if(type=="day"){
			  	var day = Math.floor(times / (60 * 60 * 24))
			  	return day
			  }if(type=="hour"){
			  	var hour = Math.floor(times / (60 * 60) % 24)
			  	return hour
			  }else if(type=="minute"){
			  	var minute = Math.floor(times / 60 % 60)
			  	return minute
			  }else if(type=="second"){
			  	var second = Math.floor(times % 60)
			  	return second
			  }
			}
		}
	}
</script>

<style>

</style>
