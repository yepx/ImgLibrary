<template>
	<view >
		<image class="a-full-fixed" mode="aspectFill" :src="globalData.imgUrl+'images/bg-logins.png'"></image>
		<view class="autoFixed transitionBackgroundColor">
			<view class="a-w-750" :style="'height:'+globalData.statusBar+'px;'"></view>
			<view class="a-mx-4 a-flex a-align-center a-justify-between" :style="[{height:globalData.navbar+'px',paddingRight: isMP ? globalData.capsuleWidth+'px' :'0px'}]">
				<view class="">
					<text class="a-font-max-three a-text-white">{{$t('登录')}}</text>
				</view>
				<view @click="$navTo('pages/mine/language')" class="a-flex a-align-center">
					<image class="a-w-50 a-h-50 a-mr" :src="globalData.imgUrl+getLanguageIcon()"></image>
					<text class="iconfonts icon-xiajiantou a-text-white"></text>
				</view>
			</view>
		</view>
		<view class="a-position-relative" style="z-index:99;">
			
			<view class="a-flex-column a-align-center a-justify-center a-w-750 a-py-10">
				<image class="a-w-300 a-h-300 a-rounded-2" src="/static/logo.png"></image>
				<text class="a-font-max-three a-text-white a-mt-1">{{globalData.name}}</text>
			</view>
			
			<view class="a-mx-3">
				<view class="a-flex a-align-center">
					<view @click="changeType(1)" class="a-px-3 a-h-60 a-flex a-align-center a-justify-center a-rounded a-mr-2" :class="type == 1?'a-bg-primary':'a-bg-white'">
						<text class="a-font-sm" :class="type == 1?'a-text-white':''">{{$t('邮箱')}}</text>
					</view>
					<view @click="changeType(2)" class="a-px-3 a-h-60 a-flex a-align-center a-justify-center a-rounded" :class="type == 2?'a-bg-primary':'a-bg-white'">
						<text class="a-font-sm" :class="type == 2?'a-text-white':''">{{$t('手机号')}}</text>
					</view>
				</view>
				
				<view>
					<view v-if="type==1" class="a-mt-4">
						<view class="a-mb-2">
							<text class="a-font-sm a-text-white a-opacity-8">{{$t('邮箱')}}</text>
						</view>
						<view class="a-border-3 a-border-white a-rounded a-h-90 a-flex a-align-center a-px-2 ">
							<input class="a-text-white a-font a-flex-1" type="text" v-model="form.email" :placeholder="$t('请输入')+$t('邮箱')" placeholder-class="a-text-white "/>
						</view>
					</view>
					<view v-else class="a-mt-4">
						<view class="a-mb-2">
							<text class="a-font-sm a-text-white a-opacity-8">{{$t('手机号')}}</text>
						</view>
						<view class="a-border-3 a-border-white a-rounded a-h-90 a-flex a-align-center a-px-2 ">
							<view @click="openAreaCode" class="a-flex a-align-center a-mr-2">
								<text class="a-font a-text-white a-mr-1">+{{form.areaCode}}</text>
								<text class="iconfonts icon-ai-arrow-down a-text-white a-font-sm a-transform-90"></text>
							</view>
							<input class="a-text-white a-font a-flex-1" type="text" v-model="form.mobile" :placeholder="$t('请输入')+$t('手机号')" placeholder-class="a-text-white "/>
						</view>
					</view>
					<view class="a-mt-4">
						<view class="a-mb-2">
							<text class="a-font-sm a-text-white a-opacity-8">{{$t('密码')}}</text>
						</view>
						<view class="a-border-3 a-border-white a-rounded a-h-90 a-flex a-align-center a-px-2 ">
							<input class="a-text-white a-font a-flex-1" type="text" :password="passwordHide" v-model="form.password" :placeholder="$t('请输入')+$t('密码')" placeholder-class="a-text-white "/>
							<view @click="changePasswordHide" class="a-flex a-align-center">
								<text class="iconfonts  a-text-white a-font-max" :class="passwordHide?'icon-eye-disable':'icon-eye'"></text>
							</view>
						</view>
					</view>
					<view class="a-flex a-justify-between a-mt-2">
						<view class=" a-flex-1">
							<text class="a-text-white a-font-sm">{{$t('如果您没有账号')}},</text>
							<text @click="windowOpen(globalData.mobileUrl+'promote/#/')" class="a-text-primary a-font-sm">{{$t('点击注册')}}</text>
						</view>
						<view v-if="false" @click="$navTo('pages/customerService/index?notoken=1')" class="a-flex a-ml-5">
							<text class="a-text-primary a-font-sm">{{$t('忘记密码')}}</text>
						</view>
					</view>
					<view v-if="isLoading"  class="a-mt-4 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center a-mb-4">
											<view class="loader"></view>
										</view>
										<view v-else @click="open()" class="a-mt-4 a-bg-primary a-rounded a-h-90 a-flex-1 a-flex a-align-center a-justify-center a-mb-4">

						<text class="a-font-lg a-text-white">{{$t('登录')}}</text>
					</view>
				</view>
			</view>
			
		</view>
		<tf-verify-img @succeed="chenggong" @close="showVerify = false" v-if="showVerify" :verifyImgs="imgs"></tf-verify-img>
		<AREACODE ref="areaCode" :title="$t('选择区域码')" isMode="bottom" @setAreaCode="setAreaCode"></AREACODE>
	</view>
</template>

<script>
	const App = getApp();
	import * as Api from '@/api/common'
	import { checkLogin } from '@/core/app'
	import * as utils from "@/utils/util";
	import store from '@/store'
	import AREACODE from '@/components/areaCode'
	import Vcode from '@/components/tf-verify-img/tf-verify-img.vue';
	export default {
		components: {
		  AREACODE,
		  Vcode
		},
		data() {
			return {
				globalData:App.globalData,
				isMP:false,
				isLogin:false,
				
				//
				showVerify:false,
				imgs:[{
					src:'/static/images/vcode/01.png',
					color:'#38a7b7'
				},{
					src:'/static/images/vcode/02.png',
					color:'#38a7b7'
				},{
					src:'/static/images/vcode/03.png',
					color:'#38a7b7'
				},{
					src:'/static/images/vcode/04.png',
					color:'#38a7b7'
				},{
					src:'/static/images/vcode/05.png',
					color:'#38a7b7'
				}],
				
				type:1,
				passwordHide:true,
				form:{
					areaCode: uni.getStorageSync("areaCode")||44,
					mail:'',
					mobile:'',
					username:'',
					password:''
				},
				isLoading:false,
			}
		},
		onShow() {
		},
		methods: {
			open(){
				if(this.form.email && this.form.password || this.form.mobile && this.form.password ){
					this.showVerify = true;
				}
			},
			chenggong(){
				this.showVerify = false;
				this.submitLogin()
			},
			
			getLanguageIcon(){
				return utils.languageIcon()
			},
			changeType(type){
				this.type = type
			},
			changePasswordHide(){
				this.passwordHide = !this.passwordHide
			},
			openAreaCode() {
			    this.$refs.areaCode.open();
			},
			setAreaCode(number) {
			    this.form.areaCode = number
			    uni.setStorageSync("areaCode", this.form.areaCode)
			},
			// 点击登录
			submitLogin() {
				const that = this
			//	that.isLoading = true
				store.dispatch('Login', {
					username: that.type==1?that.form.email:that.form.areaCode+' '+that.form.mobile,
					password: that.form.password
			    })
			    .then(result => {
					// 显示登录成功
					// 跳转回原页面
					if(result.code==0){
						
												that.getSellerInfo()

					//	that.$toast(that.$t('登录')+that.$t('成功'))
					//	setTimeout(() => {
					//		that.$navTo('pages/main/home')
					//	}, 2000)
					}else{
						that.$toast(that.$t(result.msg))
												that.isLoading = false

					}
			      
			    })
			    .catch(err => {
					// 跳转回原页面
			    })
			    
			},
			getSellerInfo() {
							var that = this;
							
							that.isLoading = true
							Api.sellerInfo().then(result => {
								if(result.code==0){
									that.$toast(that.$t('登录')+that.$t('成功'))
									setTimeout(() => {
										that.$navTo('pages/main/home')
									}, 100)
								}else{
									that.$toast(that.$t(result.msg))
								}
								
											})
											.catch(err => {
												// 跳转回原页面
											})
											.finally(() => that.isLoading = false)

						},

			windowOpen(url2){
				let url=window.location.protocol + "//" + window.location.host + '/promote/'
				window.open(url, "_blank");
				
			}
			
			
		}
	}
</script>

<style lang="scss">
page{
	.loader {
	  border: 4px solid rgba(0, 0, 0, 0.1); /* 轻颜色的边框 */
	  border-radius: 50%; /* 圆形 */
	  border-top: 4px solid #ffffff; /* 蓝色边框 */
	  width: 30px; /* 加载器宽度 */
	  height: 30px; /* 加载器高度 */
	  animation: spin 2s linear infinite; /* 动画效果 */
	}
	 
	@keyframes spin {
	  0% { transform: rotate(0deg); }
	  100% { transform: rotate(360deg); }
	}

	background-color: #1e1e1e;
}
</style>
