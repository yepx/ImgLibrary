import request from '@/utils/request'

// 当前登录的用户信息
export const info = (param, option) => {
  const options = {
    isPrompt: true, //（默认 true 说明：本接口抛出的错误是否提示）
    load: true, //（默认 true 说明：本接口是否提示加载动画）
    ...option
  }
  return request.get('wap/api/localuser!get.action', param, options)
}
/* ---- 循环体 ---- */
//在线客服未读消息
export function chatNumber(data) {
  return request.get('wap/api/newOnlinechat!unread.action', data, { load: false })
}
//
export function userNumber(data) {
  return request.get('wap/public/userOnlineChatController!unread.action', data, { load: false })
}
//消息中心未读消息数
export function messageNumber(data) {
  return request.get('wap/api/notification!count.unread', data, { load: false })
}
//消息列表
export function messageList(data) {
  return request.get('wap/public/userOnlineChatController!userlist.action', data, { load: false })
}
//系统消息
export function notificationList(data) {
  return request.get('wap/api/notification!message.slidelist', data, { load: false })
}
//系统消息详情
export function notificationDetail(data) {
  return request.get('wap/api/notification!message.detail', data, { load: false })
}
//设置已读
export function notificationRead(data) {
  return request.post('wap/api/notification!message.read', data, { load: false })
}
//获取未处理订单数
export function orderNoPushNum(data) {
  return request.post('wap/seller/orders!noPushNum.action', data, { load: false })
}
/* ---- 首页 ---- */
//获取钱包信息
export function walletInfo(data) {
  return request.get('wap/api/wallet!getUsdt.action', data, { load: false })
}

//获取
export function currentActivity(data) {
  return request.get('wap/api/activity/lottery!getCurrentActivity.action', data, { load: false })
}
//获取
export function cmsGet(data) {
  return request.get('wap/api/cms!get.action', data, { load: false })
}
//卖家信息
export function sellerInfo(data) {
  return request.post('wap/seller/seller!info.action', data, { load: false })
}
//卖家类别
export function sellerCate(data) {
  return request.post('wap/api/sellerGoods!categoryGoodCount.action', data, { load: false })
}
//卖家
export function sellerHead(data) {
  return request.post('wap/seller/instrument-panel!head.action', data, { load: false })
}
//订单状态数
export function sellerStats(data) {
  return request.post('wap/seller/instrument-panel!stats.action', data, { load: false })
}
//卖家线
export function sellerLine(data) {
  return request.post('wap/seller/instrument-panel!line.action', data, { load: false })
}
//获取销售数据
export function sellerReport(data) {
  return request.post('wap/seller/report!head.action', data, { load: false })
}

/* ---- 商品 ---- */
//商品列表
export function sellerGoods(data) {
  return request.post('wap/seller/goods!list.action', data, { load: false })
}
//商品添加
export function sellerGoodsAdd(data) {
  return request.post('wap/seller/goods!addOrUpdate.action', data, { load: false })
}
//商品编辑
export function sellerGoodsEdit(data) {
  return request.post('wap/seller/goods!update.action', data, { load: false })
}
//商品删除
export function sellerGoodsDelete(data) {
  return request.post('wap/seller/goods!delete.action', data, { load: false })
}
//商品折扣
export function sellerSysParaProduct(data) {
  return request.post('wap/api/sysParaProduct!info.action', data, { load: false })
}
//评论列表
export function sellerComment(data) {
  return request.post('wap/seller/evaluation!list.action', data, { load: false })
}
//商品库
export function sellerGoodsSys(data) {
  return request.post('wap/seller/systemGoods!list.action', data, { load: false })
}
//商品分类
export function sellerGoodsCate(data) {
  return request.get('wap/api/category!tree.action', data, { load: false })
}
//商品分类
export function sellerGoodsSearch(data) {
  return request.post('wap/seller/goods!search-goods.action', data, { load: false })
}

/* ---- 订单 ---- */
//列表
export function orderList(data) {
  return request.post('wap/seller/orders!list.action', data, { load: false })
}
//列表
export function orderDetailGoods(data) {
  return request.post('wap/api/order!listGoods.action', data, { load: false })
}
//列表
export function orderDetailInfo(data) {
  return request.post('wap/api/order!info.action', data, { load: false })
}
//订单付款
export function orderBuy(data) {
  return request.post('wap/seller/orders!push.action', data, { load: false })
}
//物流
export function orderLog(data) {
  return request.post('wap/api/orderLog!list.action', data, { load: false })
}

/* ---- 获取卖家等级列表 ---- */
//
export function sellerLevelList(data) {
  return request.get('wap/api/malllevel!levelList.action', data, { load: false })
}
//获取客服地址配置
export function getSysParaService(data) {
  return request.get('wap/api/syspara!getSyspara.action', data, { load: false })
}




/* ---- 用户 ---- */
export function beforeReceiveBonus(data) {
  return request.post('wap/seller/seller!beforeReceiveBonus.action', data, { load: false })
}
//国家
export function country(data) {
  return request.post('wap/api/address!listCountry.action', data, { load: false })
}
//币种
export function selectPaymentChannel(data) {
  return request.post('wap/api/channelBlockchain!list.action', data, { load: false })
}
//汇率
export function getCurrencyFee(data) {
  return request.post('wap/api/rechargeBlockchain!fee.action', data, { load: false })
}
//手续费
export function getWithdrawFee(data) {
  return request.post('wap/api/withdraw!fee.action', data, { load: false })
}
//是否绑定地址
export function getWithdrawOpen(data) {
  return request.get('wap/api/withdraw!withdraw_open.action', data, { load: false })
}
//提现
export function withdraw(data) {
  return request.get('wap/api/withdraw!apply.action', data, { load: false })
}
//提现记录
export function withdrawRecord(data) {
  return request.post('wap/api/withdraw!list.action', data, { load: false })
}
//提现记录
export function withdrawDetail(data) {
  return request.post('wap/api/withdraw!get.action', data, { load: false })
}
//充值记录
export function rechargeRecord(data) {
  return request.post('wap/api/rechargeBlockchain!list.action', data, { load: false })
}
//充值记录
export function rechargeDetail(data) {
  return request.post('wap/api/rechargeBlockchain!get.action', data, { load: false })
}
//修改头像
export function refreshAvatar(data) {
  return request.post('wap/api/localuser!refreshAvatar.action', data, { load: false })
}
//认证信息
export function kycInfo(data) {
  return request.post('wap/api/kyc!get.action', data, { load: false })
}
//认证提交
export function kycApply(data) {
  return request.get('wap/api/kyc!apply.action', data, { load: false })
}
//手机邮箱认证验证
export function authCheck(data) {
  return request.post('wap/api/localuser!checkEmailOrPhone.action', data, { load: false })
}
//手机邮箱核验
export function beforeBind(data) {
  return request.post('wap/api/localuser!beforeBind.action', data, { load: false })
}
//手机邮箱认证验证码
export function sendSmsCaptcha(data) {
  return request.post('wap/api/idcode!execute.action', data, { load: false })
}
//手机邮箱绑定
export function bindEmailOrPhone(data) {
  return request.post('wap/api/localuser!bindEmailOrPhone.action', data, { load: false })
}
//设置资金密码
export function setSafewordReg(data) {
  return request.post('wap/api/user!setSafewordReg.action', data, { load: false })
}
//修改资金密码
export function updateOldAndNewSafeword(data) {
  return request.post('wap/api/user!updateOldAndNewSafeword.action', data, { load: false })
}
//修改登录密码
export function updateOldAndNewPsw(data) {
  return request.post('wap/api/user!updateOldAndNewPsw.action', data, { load: false })
}

//退款记录
export function orderRefund(data) {
  return request.post('wap/seller/orders!list-returns.action', data, { load: false })
}
//退款记录
export function orderRefundDetail(data) {
  return request.post('wap/seller/orders!details-returns.action', data, { load: false })
}
//资金记录
export function fundsRecord(data) {
  return request.post('wap/api/moneylog!list.action', data, { load: false })
}
//财务报表
export function financeReport(data) {
  return request.post('wap/seller/report!list.action', data, { load: false })
}
//直通车列表
export function promotional(data) {
  return request.post('wap/seller/promotional!view.action', data, { load: false })
}
//直通车购买
export function promotionalBuy(data) {
  return request.post('wap/seller/promotional!buy.action', data, { load: false })
}
//直通车记录
export function promotionalRecord(data) {
  return request.post('wap/seller/promotional!listBuy.action', data, { load: false })
}
//店铺信息修改
export function sellerUpdate(data) {
  return request.post('wap/seller/seller!update.action', data, { load: false })
}

//创业联盟
export function alliance(data) {
  return request.post('wap/seller/promotional!my.action', data, { load: false })
}
//创业联盟
export function allianceLevel(data) {
  return request.post('api/promote/level', data, { load: false })
}

/* ---- 聊天 ---- */
//获取客服消息列表
export function serviceChatList(data) {
  return request.get('wap/api/newOnlinechat!list.action', data, { load: false })
}
//发送客服消息
export function sendServiceChatMsg(data) {
  return request.get('wap/api/newOnlinechat!send.action', data, { load: false })
}
//获取用户消息列表
export function userChatList(data) {
  return request.get('wap/public/userOnlineChatController!list.action', data, { load: false })
}
//发宋用户消息
export function sendUserChatMsg(data) {
  return request.get('wap/public/userOnlineChatController!send.action', data, { load: false })
}
//
export function addProAll(data) {
  return request.post('/wap/seller/goods!batchShelvesGoods.action', data, { load: true })
}




