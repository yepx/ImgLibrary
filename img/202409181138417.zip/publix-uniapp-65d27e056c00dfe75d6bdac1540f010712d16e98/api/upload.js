import request from '@/utils/request'

// api地址
const api = {
  image: 'wap/api/uploadimg!execute.action'
}

// 图片上传
export const image = (files,moduleName) => {
  // 文件上传大小, 2M
  const maxSize = 1024 * 1024 * 2
  // 执行上传
  return new Promise((resolve, reject) => {
    request.urlFileUpload({ files, maxSize ,moduleName})
      .then(result => {
		const image = result.map(item => {
		  return item.data
		})
		resolve(image, result)
      })
      .catch(reject)
  })
}
