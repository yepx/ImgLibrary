import request from '@/utils/request'

// api地址
const api = {
  login: 'wap/api/user!newlogin.action',
}

// 用户登录
export function login(data) {
  return request.post(api.login, data)
}