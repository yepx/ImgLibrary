<template>
    <view class="nationList">
        <u-popup v-model="isShow" height="80%" :mode="isMode" :safe-area-inset-bottom="true" :closeable="false" :border-radius="26" :maskCloseAble="isClose">
			<view class="a-bg-white a-rounded-top-3 a-flex-column a-w-750" style="height:100%">
				<view class="a-flex a-align-center a-justify-center a-py-3 ">
					<text class="a-font-lg">{{title}}</text>
				</view>
				<view class="a-bg-gray a-h-90 a-rounded-circle a-flex a-align-center a-px-3 a-mx-3">
					<input class="a-flex-1" v-model="val" @input="onSearch(val)" :placeholder="$t('请输入要搜索的国家名称')">
				</view>
				<scroll-view class="a-flex-1 a-overflow-hidden" scroll-y>
					<view class="nation-item" v-for="(item, index) in countriesFind" :key="index" @click="selectItem(item)">
						<!-- <view class="iti-flag img" :class="key"></view> -->
						<view class="name">{{ item.countryName }}</view>
						<text v-if="isCode == item.id"  class="iconfonts icon-dagou a-font-tiny a-text-primary" ></text>
					</view>
				</scroll-view>
				
				<view class="a-flex a-align-center a-justify-center a-h-300" v-if="Object.keys(countriesFind).length === 0">
					<text class="a-font">{{$t('暂无数据')}}</text>
				</view>
			</view>
        </u-popup>
    </view>
</template>

<script>
// import countries from './countryList';
import * as Api from '@/api/common'
export default {
    name: 'Country',
    props: {
        title: {
            type: String,
            default: ""
        },
        isCode: {
            type: String,
            default: ''
        },
        isInit: {
            type: Boolean,
            default: true
        },
		isMode: {
            type: String,
            default: "bottom"
        },
		isClose: {
		    type: Boolean,
		    default: true
		},
    },
    data() {
        return {
            language: "en",
            isShow: false,
            //搜索值
            val: '',
            //国籍列表
            list: [],
            countries:[],
            countriesFind: [],
            selectIndex: 0,
        }
    },
    mounted() {
		console.log(this.isCode)
        this.getCountry()
    },
    watch: {
        val(newVal) {
            this.onSearch(newVal)
        }
    },
    methods: {
        //自定义打开方法
        open() {
            this.isShow = true
        },
		getCountry() {
			var that = this;
			Api.country().then(res => {
				const {status,message,data} = res;
				that.countries = res.data.data
				this.countriesFind = res.data.data
			});
		},
        //选择国家
        selectItem(item, key) {
            this.selectIndex = item.code;
            this.$emit('setCountry', item)
            this.isShow = false
        },
        //搜索国家
        onSearch(val) {
            if (!val) {
                this.countriesFind = this.countries
                return
            }
            this.countriesFind = []
            this.countriesFind = this.countries.filter(item => item.countryName.indexOf(val) > -1)
        },
    }
}
</script>
<style lang="scss" scoped>
@import "intl.css";

.nationList .van-action-sheet {
    height: 80%;
}

.nation-item {
    box-sizing: border-box;
    width: 100%;
    padding: 0 12px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 12px;

    >.img {
        width: 20px;
        height: 12px;
    }

    >.name {
        flex: 1;
        margin: 0 10px;
    }
}
</style>
