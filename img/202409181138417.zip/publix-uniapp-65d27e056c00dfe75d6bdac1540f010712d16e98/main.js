import Vue from 'vue'
import uView from 'uview-ui'
import App from './App'
import store from './store'
import VueI18n from 'vue-i18n'
import messages from './locale/index'
import bootstrap from './core/bootstrap'
import mixin from './core/mixins/app'
import BigDecimal from 'js-big-decimal'
import './js_sdk/ican-H5Api/ican-H5Api'
import {
  navTo,
  showToast,
  showSuccess,
  showError,
  getShareUrlParams,
  cache,
  countdown
} from './core/app'

Vue.config.productionTip = false

App.mpType = 'app'

// 载入uView库
Vue.use(uView)
//载入语言
let i18nConfig = {
  locale: 'en',
  messages
}
console.log(i18nConfig)
Vue.use(VueI18n)
const i18n = new VueI18n(i18nConfig)

// 全局mixin
Vue.mixin(mixin)

// 挂载全局函数
Vue.prototype.$toast = showToast
Vue.prototype.$success = showSuccess
Vue.prototype.$error = showError
Vue.prototype.$navTo = navTo
Vue.prototype.$getShareUrlParams = getShareUrlParams
Vue.prototype.$cache = cache
Vue.prototype.$countdown = countdown
Vue.prototype.$bigDecimal = BigDecimal //全局注册，使用方法为:this.$bigDecimal
// 加 this.$bigDecimal.add(1, 2)
// 减 this.$bigDecimal.subtract(1, 2)
// 乘 this.$bigDecimal.multiply(1, 2)
// 除 this.$bigDecimal.divide(1, 2)
// 比较大小 this.$bigDecimal.compare(1, 2)

// 实例化应用
const app = new Vue({
  ...App,
  i18n,
  store,
  created: bootstrap
})
app.$mount()
