import { pathToBase64,base64ToPath } from 'image-tools'
/**
 * 格式化日期格式 (用于兼容ios Date对象)
 */
export const formatDate = (time) => {
  // 将xxxx-xx-xx的时间格式，转换为 xxxx/xx/xx的格式 
  return time.replace(/\-/g, "/");
}

/**
 * 对象转URL
 * @param {object} obj
 */
export const urlEncode = (obj = {}) => {
  const result = []
  for (const key in obj) {
    const item = obj[key]
    // if (!item) {
    //   continue
    // }
    if (isArray(item)) {
      item.forEach(val => {
        result.push(key + '=' + val)
      })
    } else {
      result.push(key + '=' + item)
    }
  }
  return result.join('&')
}

/**
 * 遍历对象
 */
export const objForEach = (obj, callback) => {
  Object.keys(obj).forEach((key) => {
    callback(obj[key], key)
  });
}

/**
 * 是否在数组内
 */
export const inArray = (search, array) => {
  for (var i in array) {
    if (array[i] == search) return true
  }
  return false
}

/**
 * 对Date的扩展，将 Date 转化为指定格式的String
 * 月(Y)、月(m)、日(d)、小时(H)、分(M)、秒(S) 可以用 1-2 个占位符，
 * 例子：
 * dateFormat('YYYY-mm-dd HH:MM:SS', new Date()) ==> 2020-01-01 08:00:00
 */
export const dateFormat = (fmt, date) => {
  const opt = {
    "Y+": date.getFullYear().toString(), // 年
    "m+": (date.getMonth() + 1).toString(), // 月
    "d+": date.getDate().toString(), // 日
    "H+": date.getHours().toString(), // 时
    "M+": date.getMinutes().toString(), // 分
    "S+": date.getSeconds().toString() // 秒
    // 有其他格式化字符需求可以继续添加，必须转化成字符串
  };
  let ret
  for (let k in opt) {
    ret = new RegExp("(" + k + ")").exec(fmt)
    if (ret) {
      fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
    };
  };
  return fmt
}

/**
 * 判断是否为空对象
 * @param {*} object 源对象
 */
export const isEmptyObject = (object) => {
  return Object.keys(object).length === 0
}

/**
 * 判断是否为对象
 * @param {*} object
 */
export const isObject = (object) => {
  return Object.prototype.toString.call(object) === '[object Object]'
}

/**
 * 判断是否为数组
 * @param {*} array
 */
export const isArray = (array) => {
  return Object.prototype.toString.call(array) === '[object Array]'
}

/**
 * 判断是否为空
 * @param {*} object 源对象
 */
export const isEmpty = (value) => {
  if (isArray(value)) {
    return value.length === 0
  }
  if (isObject(value)) {
    return isEmptyObject(value)
  }
  return !value
}

/**
 * 对象深拷贝
 * @param {*} obj 源对象
 */
export const cloneObj = (obj) => {
  let newObj = isArray(obj) ? [] : {};
  if (typeof obj !== 'object') {
    return;
  }
  for (let i in obj) {
    newObj[i] = typeof obj[i] === 'object' ? cloneObj(obj[i]) : obj[i];
  }
  return newObj
}

// 节流函数
// 思路： 第一次先设定一个变量true，
// 第二次执行这个函数时，会判断变量是否true，
// 是则返回。当第一次的定时器执行完函数最后会设定变量为flase。
// 那么下次判断变量时则为flase，函数会依次运行。
export function throttle(fn, delay = 100) {
  // 首先设定一个变量，在没有执行我们的定时器时为null
  var timer = null
  return function() {
    // 当我们发现这个定时器存在时，则表示定时器已经在运行中，需要返回
    if (timer) return
    timer = setTimeout(() => {
      fn.apply(this, arguments)
      timer = null
    }, delay)
  }
}

// 防抖函数
// 首次运行时把定时器赋值给一个变量， 第二次执行时，
// 如果间隔没超过定时器设定的时间则会清除掉定时器，
// 重新设定定时器， 依次反复， 当我们停止下来时，
// 没有执行清除定时器， 超过一定时间后触发回调函数。
// 参考文档：https://segmentfault.com/q/1010000021145192
export function debounce(fn, delay = 100) {
  let timer
  return function() {
    const that = this
    const _args = arguments // 存一下传入的参数
    if (timer) {
      clearTimeout(timer)
    }
    timer = setTimeout(function() {
      fn.apply(that, _args)
    }, delay)
  }
}

/**
 * 数组交集
 * @param {Array} 数组1
 * @param {Array} 数组2
 * @return {Array}
 */
export const arrayIntersect = (array1, array2) => {
  return array1.filter(val => array2.indexOf(val) > -1)
}

/**
 * 获取当前客户端的rpx比值
 * @return {Number}
 */
export const rpx = () => {
  const { windowWidth } = uni.getSystemInfoSync()
  // #ifdef H5
  // 与pages.json文件中的 rpxCalcMaxDeviceWidth参数对应, 请勿修改
  const rpxCalcMaxDeviceWidth = 750
  // 与pages.json文件中的 rpxCalcBaseDeviceWidth参数对应, 请勿修改
  const rpxCalcBaseDeviceWidth = 560
  const calcWindowWidth = windowWidth > rpxCalcMaxDeviceWidth ? rpxCalcBaseDeviceWidth : windowWidth
  return calcWindowWidth / 750
  // #endif
  // #ifndef H5
  return windowWidth / 750
  // #endif
}

/**
 * 获取当前客户端的rpx比值
 * @return {Number}
 */
export const rpx2px = (num) => {
  return num * rpx()
}

/*
 * 版本号比较方法
 * 传入两个字符串，当前版本号：curV；比较版本号：reqV
 * 调用方法举例：compare("5.12.3","5.12.2")，将返回false
 */
export const compare = (curV,reqV) => {
	let arr1=curV.split('.');
	let arr2=reqV.split('.');
	//将两个版本号拆成数字 
	let minL= Math.min(arr1.length,arr2.length);  
	let pos=0;        //当前比较位
	let diff=0;        //当前为位比较是否相等
	console.log(arr1,arr2,minL)
	//逐个比较如果当前位相等则继续比较下一位
	while(pos<minL){
		diff=parseInt(arr1[pos])-parseInt(arr2[pos]);  
		if(diff!=0){  
			break;  
		} 
		pos++;
	}
	  console.log(diff,parseInt(arr1[pos]),parseInt(arr2[pos]))                
	if (diff>0) {
		//稳定版，不需要更新
		return false;
	}else{
		//版本过低，需要更新
		return true;
	}
}


/**
 * BASE64转图片
 */
export const base64ToImg = async function(data){
	return new Promise((resolve,reject)=>{
			base64ToPath(data).then(base64 => {
				resolve(base64)
			 }).catch(error => {
				console.error(error)
				reject(error)
			})		
	})			
}
/**
 * 语言图标
 */
export const languageIcon = function(){
	const language = uni.getLocale() || "en";
	
	if (language == 'en-US' || language == '"en-US"') {
		language = 'en'
	} else if (language == 'zh-CN' || language == "'zh-CN'") {
		language = 'cn'
	} else if (language == 'zh-TW' || language == "'zh-TW'") {
		language = 'tw'
	}
	const icon = {
		cn: "images/language/cn.png",
		en: "images/language/usa.png",
		tw: "images/language/tw.png",
		de: "images/language/de.png",
		ja: "images/language/ja.png",
		ms: "images/language/ms.png",
		th: "images/language/th.png",
		pt: "images/language/pt.png",
		es: "images/language/es.png",
		ru: "images/language/ru.png",
		el: "images/language/el.png",
		it: "images/language/it.png",
		tr: "images/language/tr.png",
		af: "images/language/af.png",
		fr: "images/language/fr.png",
		ko: "images/language/ko.png",
		ph: "images/language/ph.png",
		ar: "images/language/ar.png",
		vi: "images/language/vi.png",
		hi: "images/language/hi.png",
		id: "images/language/id.png",
	};
	return language ? icon[language] : icon['cn'];
}
//时间戳转字符串
export const getTime = function(time){
	let date = new Date(time);
	 //时间戳为10位需*1000，时间戳为13位的话不需乘1000
	let y = date.getFullYear();
	let MM = date.getMonth() + 1;
	MM = MM < 10 ? ('0' + MM) : MM;//月补0
	let d = date.getDate();
	d = d < 10 ? ('0' + d) : d;//天补0
	let h = date.getHours();
	h = h < 10 ? ('0' + h) : h;//小时补0
	let m = date.getMinutes();
	m = m < 10 ? ('0' + m) : m;//分钟补0
	let s = date.getSeconds();
	s = s < 10 ? ('0' + s) : s;//秒补0
	let nowTime = y + '-' + MM + '-' + d + ' ' + h + ':' + m+ ':' + s;
	return nowTime;
}

// 手机号做脱敏处理
export const phoneHide = function(phone){
	let reg = /^(1[3-9][0-9])\d{4}(\d{4}$)/; // 定义手机号正则表达式
	phone = phone.replace(reg, '$1****$2');
	return phone; // 输出为131****1234
}
export const emailHide = function(email){
	var avg;
	var splitted;
	var email1;
	var email2;
	splitted = email.split('@');
	email1 = splitted[0];
	avg = email1.length / 2;
	email1 = email1.substring(0, email1.length - avg);
	email2 = splitted[1];
	return email1 + '***@' + email2; // 输出为11223***@qq.com
}
