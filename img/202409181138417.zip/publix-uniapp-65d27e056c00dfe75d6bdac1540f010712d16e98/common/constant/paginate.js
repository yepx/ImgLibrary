export default {
  data: [], // 列表数据
  current_page: 1, // 当前页码
  last_page: 1, // 最大页码
  per_page: 15, // 每页记录数
  total: 0, // 总记录数
}
