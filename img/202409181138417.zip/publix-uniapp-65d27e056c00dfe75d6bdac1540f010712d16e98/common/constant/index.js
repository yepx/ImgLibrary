import paginate from './paginate'

export { paginate }
