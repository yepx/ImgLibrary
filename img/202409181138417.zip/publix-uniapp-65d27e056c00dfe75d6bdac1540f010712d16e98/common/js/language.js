const data = [
	{
		title: "English",
		key: "en",
		icon: "images/language/usa.png",
		checked:false,
	},
	{
		title: "Deutsch",
		key: "de",
		icon: "images/language/de.png",
		checked:false,
	},
	{
		title: "français",
		key: "fr",
		icon: "images/language/fr.png",
		checked:false,
	},
	{
		title: "Русский",
		key: "ru",
		icon: "images/language/ru.png",
		checked:false,
	},
	{
		title: "Español",
		key: "es",
		icon: "images/language/es.png",
		checked:false,
	},
	{
		title: "Português",
		key: "pt",
		icon: "images/language/pt.png",
		checked:false,
	},
	{
		title: "Italiano",
		key: "it",
		icon: "images/language/it.png",
		checked:false,
	},
	{
		title: "Melayu",
		key: "ms",
		icon: "images/language/ms.png",
		checked:false,
	},
	{
		title: "Afrikaans",
		key: "af",
		icon: "images/language/af.png",
		checked:false,
	},
	{
		title: "Ελληνικά",
		key: "el",
		icon: "images/language/el.png",
		checked:false,
	},
	{
		title: "繁體中文",
		key: "tw",
		icon: "images/language/tw.png",
		checked:false,
	},
	{
		title: "简体中文",
		key: "cn",
		icon: "images/language/cn.png",
		checked:false,
	},
	{
		title: "Türkçe",
		key: "tr",
		icon: "images/language/tr.png",
		checked:false,
	},
	
	{
		title: "日本語",
		key: "ja",
		icon: "images/language/ja.png",
		checked:false,
	},
	{
		title: "한국어",
		key: "ko",
		icon: "images/language/ko.png",
		checked:false,
	},
	{
		title: "ภาษาไทย",
		key: "th",
		icon: "images/language/th.png",
		checked:false,
	},
	{
		title: "Filipino",
		key: "ph",
		icon: "images/language/ph.png",
		checked:false,
	},
	{
		title: "عربي",
		key: "ar",
		icon: "images/language/ar.png",
		checked:false,
	},
	{
		title: "Tiếng Việt",
		key: "vi",
		icon: "images/language/vi.png",
		checked:false,
	},
	{
		title: "हिंदी",
		key: "hi",
		icon: "images/language/hi.png",
		checked:false,
	},
	{
		title: "bahasa Indonesia",
		key: "id",
		icon: "images/language/id.png",
		checked:false,
	}
]

export default data