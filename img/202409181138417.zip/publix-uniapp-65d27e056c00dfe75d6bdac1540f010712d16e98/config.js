let URL = window.location.hostname

// const URL ='www.taskking.org'
if(URL=='localhost'){
	
	URL ='www.taskking.shop'
}
module.exports = {
  // 系统名称
  name: "Publix",//no
  apiUrl: 'https://' + URL + '/',
  socketUrl:'wss://' + URL + '/ws1',
  mobileUrl: 'https://' + URL + '/',
  imgUrl: "/static/",
}
